import LoginForm from "@/components/login-form"
import LanguageSwitcher from "@/components/language-switcher"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-400 to-sky-200 dark:from-sky-900 dark:to-gray-900">
      <div className="container mx-auto px-4 py-16">
        <div className="flex justify-end mb-4">
          <LanguageSwitcher />
        </div>
        <div className="max-w-md mx-auto bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
          <div className="p-8">
            <div className="flex justify-center mb-6">
              <div className="flex items-center">
                <div className="h-12 w-12 bg-yellow-400 rounded-full flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-white"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <circle cx="12" cy="12" r="5" />
                    <line x1="12" y1="1" x2="12" y2="3" />
                    <line x1="12" y1="21" x2="12" y2="23" />
                    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
                    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
                    <line x1="1" y1="12" x2="3" y2="12" />
                    <line x1="21" y1="12" x2="23" y2="12" />
                    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
                    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
                  </svg>
                </div>
                <h1 className="ml-3 text-2xl font-bold text-sky-600 dark:text-sky-400">D SOLARMIND</h1>
              </div>
            </div>
            <LoginForm />
          </div>
        </div>
      </div>
    </div>
  )
}

