"use client"

import { useState } from "react"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, TrendingUp, DollarSign, Leaf } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"

export default function AnalyticsPage() {
  const { t } = useLanguage()
  const { theme } = useTheme()
  const [activeTab, setActiveTab] = useState("daily")

  // Simulated data
  const dailyData = Array.from({ length: 24 }, (_, i) => ({
    hour: i,
    value: Math.floor(Math.random() * 5) + (i > 6 && i < 18 ? 3 : 0),
  }))

  const monthlyData = Array.from({ length: 30 }, (_, i) => ({
    day: i + 1,
    value: Math.floor(Math.random() * 30) + 10,
  }))

  const yearlyData = Array.from({ length: 12 }, (_, i) => ({
    month: new Date(0, i).toLocaleString("default", { month: "short" }),
    value: Math.floor(Math.random() * 300) + 100,
    lastYear: Math.floor(Math.random() * 250) + 100,
  }))

  const totalSavings = 1247.85
  const carbonOffset = 3.2
  const systemEfficiency = 78

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">{t("analytics.title")}</h1>
        <p className="text-gray-500 dark:text-gray-400">{t("analytics.subtitle")}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
          <CardHeader className={`pb-2 ${theme === "dark" ? "bg-gray-700" : "bg-green-100"}`}>
            <CardTitle className={theme === "dark" ? "text-green-400" : "text-green-700"}>
              <div className="flex items-center">
                <DollarSign className="mr-2 h-5 w-5" />
                {t("analytics.savings")}
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="text-3xl font-bold dark:text-white">${totalSavings.toFixed(2)}</div>
            <p className="text-sm text-gray-500 dark:text-gray-400">This year</p>
          </CardContent>
        </Card>

        <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
          <CardHeader className={`pb-2 ${theme === "dark" ? "bg-gray-700" : "bg-sky-100"}`}>
            <CardTitle className={theme === "dark" ? "text-sky-400" : "text-sky-700"}>
              <div className="flex items-center">
                <Leaf className="mr-2 h-5 w-5" />
                {t("analytics.carbon")}
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="text-3xl font-bold dark:text-white">{carbonOffset} tons</div>
            <p className="text-sm text-gray-500 dark:text-gray-400">CO₂ emissions avoided</p>
          </CardContent>
        </Card>

        <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
          <CardHeader className={`pb-2 ${theme === "dark" ? "bg-gray-700" : "bg-yellow-100"}`}>
            <CardTitle className={theme === "dark" ? "text-yellow-400" : "text-yellow-700"}>
              <div className="flex items-center">
                <TrendingUp className="mr-2 h-5 w-5" />
                {t("analytics.efficiency")}
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="text-3xl font-bold dark:text-white">{systemEfficiency}%</div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mt-2">
              <div className="bg-yellow-400 h-2.5 rounded-full" style={{ width: `${systemEfficiency}%` }}></div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className={`mb-6 ${theme === "dark" ? "bg-gray-800 border-gray-700" : ""}`}>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="dark:text-white">{t("analytics.comparison")}</CardTitle>
          <Button variant="outline" size="sm" className="dark:border-gray-600 dark:text-gray-300">
            <Download className="mr-2 h-4 w-4" />
            {t("analytics.download")}
          </Button>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="daily" onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="daily">{t("analytics.daily")}</TabsTrigger>
              <TabsTrigger value="monthly">{t("analytics.monthly")}</TabsTrigger>
              <TabsTrigger value="yearly">{t("analytics.yearly")}</TabsTrigger>
            </TabsList>

            <TabsContent value="daily" className="h-80">
              <div className="h-full flex items-end space-x-1">
                {dailyData.map((hour) => (
                  <div key={hour.hour} className="flex flex-col items-center flex-1">
                    <div
                      className="w-full bg-yellow-400 dark:bg-yellow-600 rounded-t"
                      style={{ height: `${hour.value * 10}%` }}
                    ></div>
                    <div className="text-xs mt-1 text-gray-500 dark:text-gray-400">{hour.hour}:00</div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="monthly" className="h-80">
              <div className="h-full flex items-end space-x-1">
                {monthlyData.map((day) => (
                  <div key={day.day} className="flex flex-col items-center flex-1">
                    <div
                      className="w-full bg-yellow-400 dark:bg-yellow-600 rounded-t"
                      style={{ height: `${(day.value / 40) * 100}%` }}
                    ></div>
                    <div className="text-xs mt-1 text-gray-500 dark:text-gray-400">{day.day}</div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="yearly" className="h-80">
              <div className="h-full flex items-end space-x-2">
                {yearlyData.map((month) => (
                  <div key={month.month} className="flex flex-col items-center flex-1">
                    <div className="w-full flex space-x-1">
                      <div
                        className="w-1/2 bg-yellow-400 dark:bg-yellow-600 rounded-t"
                        style={{ height: `${(month.value / 400) * 100}%` }}
                      ></div>
                      <div
                        className="w-1/2 bg-gray-300 dark:bg-gray-600 rounded-t"
                        style={{ height: `${(month.lastYear / 400) * 100}%` }}
                      ></div>
                    </div>
                    <div className="text-xs mt-1 text-gray-500 dark:text-gray-400">{month.month}</div>
                  </div>
                ))}
              </div>
              <div className="flex justify-center mt-4 space-x-6">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-yellow-400 dark:bg-yellow-600 rounded-full mr-1"></div>
                  <span className="text-sm text-gray-500 dark:text-gray-400">2023</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-gray-300 dark:bg-gray-600 rounded-full mr-1"></div>
                  <span className="text-sm text-gray-500 dark:text-gray-400">2022</span>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
          <CardHeader>
            <CardTitle className="dark:text-white">Energy Production Forecast</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm dark:text-gray-300">Tomorrow</span>
                <div className="flex items-center">
                  <span className="font-medium dark:text-white">28.4 kWh</span>
                  <span className="ml-2 text-xs text-green-500">+12%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm dark:text-gray-300">Next Week (avg/day)</span>
                <div className="flex items-center">
                  <span className="font-medium dark:text-white">26.1 kWh</span>
                  <span className="ml-2 text-xs text-green-500">+8%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm dark:text-gray-300">Next Month (avg/day)</span>
                <div className="flex items-center">
                  <span className="font-medium dark:text-white">24.7 kWh</span>
                  <span className="ml-2 text-xs text-red-500">-3%</span>
                </div>
              </div>
              <div className="pt-4 border-t dark:border-gray-700">
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Forecast based on historical data and weather predictions. Accuracy: 92%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
          <CardHeader>
            <CardTitle className="dark:text-white">Optimization Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 bg-yellow-50 dark:bg-yellow-900/30 rounded-lg border border-yellow-100 dark:border-yellow-800">
                <h3 className="font-medium text-yellow-800 dark:text-yellow-400">Panel Cleaning</h3>
                <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                  Dust accumulation detected. Cleaning could improve efficiency by 8-12%.
                </p>
                <div className="mt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-yellow-600 border-yellow-300 dark:text-yellow-400 dark:border-yellow-800"
                  >
                    Schedule Cleaning
                  </Button>
                </div>
              </div>

              <div className="p-3 bg-sky-50 dark:bg-sky-900/30 rounded-lg border border-sky-100 dark:border-sky-800">
                <h3 className="font-medium text-sky-800 dark:text-sky-400">Tilt Angle Adjustment</h3>
                <p className="text-sm text-sky-700 dark:text-sky-300 mt-1">
                  Seasonal adjustment recommended. Changing tilt angle to 32° could improve daily output by 5%.
                </p>
                <div className="mt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-sky-600 border-sky-300 dark:text-sky-400 dark:border-sky-800"
                  >
                    Apply Recommendation
                  </Button>
                </div>
              </div>

              <div className="p-3 bg-green-50 dark:bg-green-900/30 rounded-lg border border-green-100 dark:border-green-800">
                <h3 className="font-medium text-green-800 dark:text-green-400">Inverter Upgrade</h3>
                <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                  Your current inverter is operating at 92% efficiency. A newer model could improve overall system
                  efficiency.
                </p>
                <div className="mt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-green-600 border-green-300 dark:text-green-400 dark:border-green-800"
                  >
                    View Options
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

