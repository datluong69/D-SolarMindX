import DashboardLayout from "@/components/dashboard-layout"
import EnvironmentalData from "@/components/environmental-data"
import PowerGeneration from "@/components/power-generation"
import PanelControls from "@/components/panel-controls"
import WeatherMap from "@/components/weather-map"
import ChatbotWidget from "@/components/chatbot-widget"

export default function Dashboard() {
  return (
    <DashboardLayout>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <EnvironmentalData />
        <WeatherMap />
        <PowerGeneration />
        <PanelControls />
      </div>
      <ChatbotWidget />
    </DashboardLayout>
  )
}

