"use client"

import { useState } from "react"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Info, Calendar, CheckCircle, Clock, X } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { useTheme } from "@/hooks/use-theme"

export default function NotificationsPage() {
  const { theme } = useTheme()
  const { toast } = useToast()
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: "error",
      title: "Panel Connection Issue",
      message: "Connection to panel #3 has been lost. This may affect power generation.",
      time: "2 hours ago",
      action: "Schedule Repair",
      price: "$120",
      icon: AlertTriangle,
      color: "text-red-500",
      bgColor: "bg-red-100",
      darkBgColor: "bg-red-900/30",
      darkColor: "text-red-400",
      darkBorderColor: "border-red-800",
      scheduled: false,
    },
    {
      id: 2,
      type: "warning",
      title: "Dust Accumulation Detected",
      message: "Dust levels on your panels are higher than normal. This may reduce efficiency.",
      time: "1 day ago",
      action: "Schedule Cleaning",
      price: "$80",
      icon: Info,
      color: "text-amber-500",
      bgColor: "bg-amber-100",
      darkBgColor: "bg-amber-900/30",
      darkColor: "text-amber-400",
      darkBorderColor: "border-amber-800",
      scheduled: false,
    },
    {
      id: 3,
      type: "info",
      title: "Maintenance Reminder",
      message: "Your quarterly maintenance check is due in 5 days.",
      time: "3 days ago",
      action: "Schedule Maintenance",
      price: "$150",
      icon: Calendar,
      color: "text-blue-500",
      bgColor: "bg-blue-100",
      darkBgColor: "bg-blue-900/30",
      darkColor: "text-blue-400",
      darkBorderColor: "border-blue-800",
      scheduled: false,
    },
    {
      id: 4,
      type: "success",
      title: "Optimization Complete",
      message: "AI optimization has improved your panel efficiency by 12% this month.",
      time: "1 week ago",
      icon: CheckCircle,
      color: "text-green-500",
      bgColor: "bg-green-100",
      darkBgColor: "bg-green-900/30",
      darkColor: "text-green-400",
      darkBorderColor: "border-green-800",
    },
  ])

  // Schedule dialog state
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false)
  const [selectedNotification, setSelectedNotification] = useState<any>(null)
  const [scheduleDate, setScheduleDate] = useState("")
  const [scheduleTime, setScheduleTime] = useState("")
  const [paymentMethod, setPaymentMethod] = useState("credit")

  // Payment dialog state
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false)
  const [cardNumber, setCardNumber] = useState("")
  const [cardName, setCardName] = useState("")
  const [cardExpiry, setCardExpiry] = useState("")
  const [cardCvc, setCardCvc] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const handleSchedule = (notification: any) => {
    setSelectedNotification(notification)
    setScheduleDialogOpen(true)

    // Set default date to tomorrow
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    setScheduleDate(tomorrow.toISOString().split("T")[0])

    // Set default time to 10:00 AM
    setScheduleTime("10:00")
  }

  const handleScheduleSubmit = () => {
    if (!scheduleDate || !scheduleTime) {
      toast({
        title: "Missing information",
        description: "Please select both date and time",
        variant: "destructive",
      })
      return
    }

    setScheduleDialogOpen(false)
    setPaymentDialogOpen(true)
  }

  const handlePaymentSubmit = () => {
    if (!cardNumber || !cardName || !cardExpiry || !cardCvc) {
      toast({
        title: "Missing payment information",
        description: "Please fill in all payment details",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false)
      setPaymentDialogOpen(false)

      // Update notification to show it's scheduled
      setNotifications(
        notifications.map((notif) =>
          notif.id === selectedNotification.id
            ? { ...notif, scheduled: true, scheduledDate: scheduleDate, scheduledTime: scheduleTime }
            : notif,
        ),
      )

      toast({
        title: "Service scheduled successfully",
        description: `Your ${selectedNotification.action.toLowerCase()} has been scheduled for ${scheduleDate} at ${scheduleTime}`,
      })

      // Reset form fields
      setCardNumber("")
      setCardName("")
      setCardExpiry("")
      setCardCvc("")
    }, 2000)
  }

  const handleDismissNotification = (id: number) => {
    setNotifications(notifications.filter((notification) => notification.id !== id))

    toast({
      title: "Notification dismissed",
      description: "The notification has been removed from your list",
    })
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Notifications</h1>
        <p className="text-gray-500 dark:text-gray-400">Stay updated with your solar panel system</p>
      </div>

      <div className="space-y-4">
        {notifications.length === 0 ? (
          <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
            <CardContent className="flex flex-col items-center justify-center p-8">
              <div className="rounded-full bg-gray-100 dark:bg-gray-700 p-3 mb-4">
                <CheckCircle className="h-8 w-8 text-gray-400 dark:text-gray-500" />
              </div>
              <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">No notifications</h3>
              <p className="text-gray-500 dark:text-gray-400 text-center mt-2">
                You're all caught up! We'll notify you when there's something new.
              </p>
            </CardContent>
          </Card>
        ) : (
          notifications.map((notification) => (
            <Card
              key={notification.id}
              className={`overflow-hidden ${theme === "dark" ? "bg-gray-800 border-gray-700" : ""}`}
            >
              <div className="flex">
                <div
                  className={`${theme === "dark" ? notification.darkBgColor : notification.bgColor} p-4 flex items-start justify-center`}
                >
                  <notification.icon
                    className={`h-6 w-6 ${theme === "dark" ? notification.darkColor : notification.color}`}
                  />
                </div>
                <div className="flex-1 relative">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-2 h-6 w-6 rounded-full opacity-70 hover:opacity-100"
                    onClick={() => handleDismissNotification(notification.id)}
                  >
                    <X className="h-4 w-4" />
                  </Button>

                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center pr-8">
                      <CardTitle className="text-lg dark:text-white">{notification.title}</CardTitle>
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <Clock className="h-3 w-3 mr-1" />
                        {notification.time}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{notification.message}</p>

                    {notification.scheduled ? (
                      <div
                        className={`p-3 rounded-lg ${theme === "dark" ? "bg-green-900/20 border border-green-800" : "bg-green-50 border border-green-100"}`}
                      >
                        <p className={`text-sm font-medium ${theme === "dark" ? "text-green-400" : "text-green-700"}`}>
                          {notification.action.replace("Schedule ", "")} scheduled for {notification.scheduledDate} at{" "}
                          {notification.scheduledTime}
                        </p>
                      </div>
                    ) : (
                      notification.action && (
                        <div className="flex justify-between items-center">
                          <div>
                            {notification.price && (
                              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                                Estimated cost: {notification.price}
                              </span>
                            )}
                          </div>
                          <Button
                            size="sm"
                            className="bg-yellow-400 hover:bg-yellow-500 text-white dark:bg-yellow-600 dark:hover:bg-yellow-700"
                            onClick={() => handleSchedule(notification)}
                          >
                            {notification.action}
                          </Button>
                        </div>
                      )
                    )}
                  </CardContent>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Schedule Dialog */}
      <Dialog open={scheduleDialogOpen} onOpenChange={setScheduleDialogOpen}>
        <DialogContent className={theme === "dark" ? "bg-gray-800 border-gray-700 text-white" : ""}>
          <DialogHeader>
            <DialogTitle>{selectedNotification?.action}</DialogTitle>
            <DialogDescription className={theme === "dark" ? "text-gray-400" : ""}>
              Schedule a time for your {selectedNotification?.action.toLowerCase().replace("schedule ", "")}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="schedule-date" className={theme === "dark" ? "text-white" : ""}>
                Date
              </Label>
              <Input
                id="schedule-date"
                type="date"
                value={scheduleDate}
                onChange={(e) => setScheduleDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
                className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="schedule-time" className={theme === "dark" ? "text-white" : ""}>
                Time
              </Label>
              <Input
                id="schedule-time"
                type="time"
                value={scheduleTime}
                onChange={(e) => setScheduleTime(e.target.value)}
                className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="payment-method" className={theme === "dark" ? "text-white" : ""}>
                Payment Method
              </Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger
                  id="payment-method"
                  className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
                >
                  <SelectValue placeholder="Select payment method" />
                </SelectTrigger>
                <SelectContent className={theme === "dark" ? "bg-gray-800 border-gray-700 text-white" : ""}>
                  <SelectItem value="credit">Credit Card</SelectItem>
                  <SelectItem value="paypal">PayPal</SelectItem>
                  <SelectItem value="invoice">Invoice (Pay Later)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {selectedNotification?.price && (
              <div className={`p-3 rounded-lg ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"}`}>
                <p className="text-sm">
                  Estimated cost: <span className="font-bold">{selectedNotification.price}</span>
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Final price may vary based on service requirements
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setScheduleDialogOpen(false)}
              className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
            >
              Cancel
            </Button>
            <Button
              onClick={handleScheduleSubmit}
              className="bg-yellow-400 hover:bg-yellow-500 text-white dark:bg-yellow-600 dark:hover:bg-yellow-700"
            >
              Continue to Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent className={theme === "dark" ? "bg-gray-800 border-gray-700 text-white" : ""}>
          <DialogHeader>
            <DialogTitle>Payment Details</DialogTitle>
            <DialogDescription className={theme === "dark" ? "text-gray-400" : ""}>
              Enter your payment information to complete scheduling
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="card-number" className={theme === "dark" ? "text-white" : ""}>
                Card Number
              </Label>
              <Input
                id="card-number"
                placeholder="1234 5678 9012 3456"
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
                className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="card-name" className={theme === "dark" ? "text-white" : ""}>
                Cardholder Name
              </Label>
              <Input
                id="card-name"
                placeholder="John Doe"
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
                className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="card-expiry" className={theme === "dark" ? "text-white" : ""}>
                  Expiry Date
                </Label>
                <Input
                  id="card-expiry"
                  placeholder="MM/YY"
                  value={cardExpiry}
                  onChange={(e) => setCardExpiry(e.target.value)}
                  className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="card-cvc" className={theme === "dark" ? "text-white" : ""}>
                  CVC
                </Label>
                <Input
                  id="card-cvc"
                  placeholder="123"
                  value={cardCvc}
                  onChange={(e) => setCardCvc(e.target.value)}
                  className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
                />
              </div>
            </div>

            <div className={`p-3 rounded-lg ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"}`}>
              <p className="text-sm">
                Total: <span className="font-bold">{selectedNotification?.price}</span>
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Your card will be charged after service completion
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setPaymentDialogOpen(false)}
              className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
            >
              Cancel
            </Button>
            <Button
              onClick={handlePaymentSubmit}
              className="bg-yellow-400 hover:bg-yellow-500 text-white dark:bg-yellow-600 dark:hover:bg-yellow-700"
              disabled={isProcessing}
            >
              {isProcessing ? "Processing..." : "Complete Payment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}

