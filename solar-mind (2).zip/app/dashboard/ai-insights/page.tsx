"use client"

import type React from "react"

import { useState, useEffect } from "react"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"
import { ArrowUpRight, ArrowDownRight, Minus, RefreshCw, Camera, Zap } from "lucide-react"
import type { AIAnalysisResult, PanelIssue } from "@/lib/ai-service"

export default function AIInsightsPage() {
  const { t, language } = useLanguage()
  const { theme } = useTheme()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("performance")
  const [timeframe, setTimeframe] = useState<"day" | "week" | "month">("week")
  const [loading, setLoading] = useState(true)
  const [imageLoading, setImageLoading] = useState(false)
  const [optimizationLoading, setOptimizationLoading] = useState(false)
  const [analysis, setAnalysis] = useState<AIAnalysisResult | null>(null)
  const [panelIssues, setPanelIssues] = useState<PanelIssue[]>([])
  const [optimizationPlan, setOptimizationPlan] = useState<any>(null)
  const [selectedImage, setSelectedImage] = useState<string | null>(null)

  // Fetch AI analysis
  const fetchAnalysis = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/ai/analyze?timeframe=${timeframe}&language=${language}`)
      const data = await response.json()

      if (data.success) {
        setAnalysis(data.data)
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to fetch AI analysis",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching AI analysis:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Fetch optimization plan
  const fetchOptimizationPlan = async () => {
    try {
      setOptimizationLoading(true)
      const response = await fetch(`/api/ai/optimize?language=${language}`)
      const data = await response.json()

      if (data.success) {
        setOptimizationPlan(data.data)
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to generate optimization plan",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching optimization plan:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setOptimizationLoading(false)
    }
  }

  // Handle image upload
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = async (e) => {
      const base64Image = e.target?.result as string
      setSelectedImage(base64Image)

      try {
        setImageLoading(true)
        const response = await fetch("/api/ai/image-analysis", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            image: base64Image,
            language,
          }),
        })

        const data = await response.json()

        if (data.success) {
          setPanelIssues(data.data)
        } else {
          toast({
            title: "Error",
            description: data.message || "Failed to analyze image",
            variant: "destructive",
          })
        }
      } catch (error) {
        console.error("Error analyzing image:", error)
        toast({
          title: "Error",
          description: "An unexpected error occurred",
          variant: "destructive",
        })
      } finally {
        setImageLoading(false)
      }
    }

    reader.readAsDataURL(file)
  }

  // Initial data fetch
  useEffect(() => {
    fetchAnalysis()
    fetchOptimizationPlan()
  }, [timeframe, language])

  // Get icon for trend
  const getTrendIcon = (trend?: string) => {
    switch (trend) {
      case "increasing":
        return <ArrowUpRight className="h-4 w-4 text-green-500" />
      case "decreasing":
        return <ArrowDownRight className="h-4 w-4 text-red-500" />
      default:
        return <Minus className="h-4 w-4 text-gray-500" />
    }
  }

  // Get color for impact
  const getImpactColor = (impact?: string) => {
    switch (impact) {
      case "positive":
        return theme === "dark" ? "text-green-400" : "text-green-600"
      case "negative":
        return theme === "dark" ? "text-red-400" : "text-red-600"
      default:
        return theme === "dark" ? "text-gray-400" : "text-gray-600"
    }
  }

  // Get color for priority
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return theme === "dark" ? "bg-red-900/30 text-red-400 border-red-800" : "bg-red-100 text-red-700 border-red-200"
      case "medium":
        return theme === "dark"
          ? "bg-yellow-900/30 text-yellow-400 border-yellow-800"
          : "bg-yellow-100 text-yellow-700 border-yellow-200"
      case "low":
        return theme === "dark"
          ? "bg-green-900/30 text-green-400 border-green-800"
          : "bg-green-100 text-green-700 border-green-200"
      default:
        return theme === "dark"
          ? "bg-gray-800 text-gray-300 border-gray-700"
          : "bg-gray-100 text-gray-700 border-gray-200"
    }
  }

  // Get color for issue type
  const getIssueTypeColor = (type: string) => {
    switch (type) {
      case "dust":
        return theme === "dark"
          ? "bg-yellow-900/30 text-yellow-400 border-yellow-800"
          : "bg-yellow-100 text-yellow-700 border-yellow-200"
      case "damage":
      case "hotspot":
        return theme === "dark" ? "bg-red-900/30 text-red-400 border-red-800" : "bg-red-100 text-red-700 border-red-200"
      case "shading":
        return theme === "dark"
          ? "bg-blue-900/30 text-blue-400 border-blue-800"
          : 'bg-blue-100 text-blue-700 border-blue-200"er-blue-200'
      case "degradation":
        return theme === "dark"
          ? "bg-purple-900/30 text-purple-400 border-purple-800"
          : "bg-purple-100 text-purple-700 border-purple-200"
      default:
        return theme === "dark"
          ? "bg-gray-800 text-gray-300 border-gray-700"
          : "bg-gray-100 text-gray-700 border-gray-200"
    }
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">AI Insights & Analysis</h1>
        <p className="text-gray-500 dark:text-gray-400">Advanced AI analysis of your solar panel system</p>
      </div>

      <Tabs defaultValue="performance" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="performance">Performance Analysis</TabsTrigger>
          <TabsTrigger value="image">Image Analysis</TabsTrigger>
          <TabsTrigger value="optimization">Optimization Plan</TabsTrigger>
        </TabsList>

        {/* Performance Analysis Tab */}
        <TabsContent value="performance">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <Card className={`col-span-3 ${theme === "dark" ? "bg-gray-800 border-gray-700" : ""}`}>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="dark:text-white">AI Performance Analysis</CardTitle>
                  <CardDescription className="dark:text-gray-400">
                    Insights based on your system's historical data
                  </CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <Select value={timeframe} onValueChange={(value: "day" | "week" | "month") => setTimeframe(value)}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Select timeframe" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="day">Last 24 Hours</SelectItem>
                      <SelectItem value="week">Last Week</SelectItem>
                      <SelectItem value="month">Last Month</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="icon" onClick={fetchAnalysis} disabled={loading}>
                    <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600 dark:border-sky-400"></div>
                  </div>
                ) : analysis ? (
                  <div className="space-y-6">
                    <div className={`p-4 rounded-lg ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"}`}>
                      <h3 className="text-lg font-medium dark:text-white mb-2">Summary</h3>
                      <p className="dark:text-gray-300">{analysis.summary}</p>
                      {analysis.forecastAccuracy && (
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                          Analysis accuracy: {analysis.forecastAccuracy}%
                        </p>
                      )}
                    </div>

                    <div>
                      <h3 className="text-lg font-medium dark:text-white mb-3">Key Insights</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {analysis.insights.map((insight, index) => (
                          <div
                            key={index}
                            className={`p-4 rounded-lg border ${theme === "dark" ? "bg-gray-700 border-gray-600" : "bg-white border-gray-200"}`}
                          >
                            <div className="flex items-center mb-2">
                              {getTrendIcon(insight.trend)}
                              <h4 className="font-medium ml-2 dark:text-white">{insight.title}</h4>
                            </div>
                            <p className={`text-sm ${getImpactColor(insight.impact)}`}>{insight.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-medium dark:text-white mb-3">Recommendations</h3>
                      <div className="space-y-3">
                        {analysis.recommendations.map((rec, index) => (
                          <div key={index} className={`p-4 rounded-lg border ${getPriorityColor(rec.priority)}`}>
                            <h4 className="font-medium mb-1">{rec.title}</h4>
                            <p className="text-sm mb-2">{rec.description}</p>
                            <div className="flex flex-wrap gap-2 text-xs">
                              {rec.potentialSavings && (
                                <span
                                  className={`px-2 py-1 rounded-full ${theme === "dark" ? "bg-gray-700" : "bg-gray-200"}`}
                                >
                                  Potential savings: {rec.potentialSavings}
                                </span>
                              )}
                              {rec.implementationDifficulty && (
                                <span
                                  className={`px-2 py-1 rounded-full ${theme === "dark" ? "bg-gray-700" : "bg-gray-200"}`}
                                >
                                  Difficulty: {rec.implementationDifficulty}
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8">
                    <p className="dark:text-gray-300">
                      No analysis data available. Click refresh to analyze your system.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Image Analysis Tab */}
        <TabsContent value="image">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className={`md:col-span-1 ${theme === "dark" ? "bg-gray-800 border-gray-700" : ""}`}>
              <CardHeader>
                <CardTitle className="dark:text-white">Panel Image Analysis</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Upload an image of your solar panel for AI analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div
                    className={`border-2 border-dashed rounded-lg p-6 text-center ${
                      theme === "dark"
                        ? "border-gray-600 hover:border-gray-500"
                        : "border-gray-300 hover:border-gray-400"
                    } transition-colors cursor-pointer`}
                    onClick={() => document.getElementById("panel-image-upload")?.click()}
                  >
                    <Camera className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Click to upload an image of your solar panel
                    </p>
                    <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">Supports JPG, PNG (max 5MB)</p>
                    <input
                      type="file"
                      id="panel-image-upload"
                      className="hidden"
                      accept="image/jpeg,image/png"
                      onChange={handleImageUpload}
                    />
                  </div>

                  {selectedImage && (
                    <div className="mt-4">
                      <p className="text-sm font-medium mb-2 dark:text-white">Selected Image:</p>
                      <div className="relative rounded-lg overflow-hidden">
                        <img src={selectedImage || "/placeholder.svg"} alt="Selected panel" className="w-full h-auto" />
                        {imageLoading && (
                          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className={`md:col-span-2 ${theme === "dark" ? "bg-gray-800 border-gray-700" : ""}`}>
              <CardHeader>
                <CardTitle className="dark:text-white">Analysis Results</CardTitle>
                <CardDescription className="dark:text-gray-400">AI-detected issues and recommendations</CardDescription>
              </CardHeader>
              <CardContent>
                {imageLoading ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600 dark:border-sky-400"></div>
                  </div>
                ) : panelIssues.length > 0 ? (
                  <div className="space-y-4">
                    {panelIssues.map((issue, index) => (
                      <div key={index} className={`p-4 rounded-lg border ${getIssueTypeColor(issue.type)}`}>
                        <div className="flex justify-between">
                          <h3 className="font-medium">
                            {issue.type.charAt(0).toUpperCase() + issue.type.slice(1)} Issue
                          </h3>
                          <span
                            className={`px-2 py-0.5 text-xs rounded-full ${
                              issue.severity === "high"
                                ? "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300"
                                : issue.severity === "medium"
                                  ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300"
                                  : "bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300"
                            }`}
                          >
                            {issue.severity.charAt(0).toUpperCase() + issue.severity.slice(1)} Severity
                          </span>
                        </div>

                        <div className="mt-2 space-y-2">
                          <p className="text-sm">
                            <span className="font-medium">Location:</span> {issue.location}
                          </p>
                          <p className="text-sm">
                            <span className="font-medium">Description:</span> {issue.description}
                          </p>
                          <p className="text-sm">
                            <span className="font-medium">Recommended Action:</span> {issue.recommendedAction}
                          </p>
                          <p className="text-sm">
                            <span className="font-medium">Estimated Impact:</span> {issue.estimatedImpact}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : selectedImage ? (
                  <div className="text-center p-8">
                    <p className="dark:text-gray-300">No issues detected in the uploaded image.</p>
                  </div>
                ) : (
                  <div className="text-center p-8">
                    <p className="dark:text-gray-300">Upload an image to see analysis results.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Optimization Plan Tab */}
        <TabsContent value="optimization">
          <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="dark:text-white">AI Optimization Plan</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Personalized plan to improve your system's performance
                </CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={fetchOptimizationPlan} disabled={optimizationLoading}>
                <RefreshCw className={`h-4 w-4 mr-2 ${optimizationLoading ? "animate-spin" : ""}`} />
                Regenerate Plan
              </Button>
            </CardHeader>
            <CardContent>
              {optimizationLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600 dark:border-sky-400"></div>
                </div>
              ) : optimizationPlan ? (
                <div className="space-y-6">
                  <div
                    className={`p-4 rounded-lg ${theme === "dark" ? "bg-sky-900/30 border border-sky-800" : "bg-sky-50 border border-sky-100"}`}
                  >
                    <h3 className={`text-lg font-medium ${theme === "dark" ? "text-sky-400" : "text-sky-700"}`}>
                      {optimizationPlan.plan}
                    </h3>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <div
                        className={`px-3 py-1 rounded-full text-sm ${
                          theme === "dark" ? "bg-green-900/30 text-green-400" : "bg-green-100 text-green-700"
                        }`}
                      >
                        <Zap className="h-4 w-4 inline mr-1" />
                        Estimated Improvement: {optimizationPlan.estimatedImprovement}
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-sm ${
                          theme === "dark" ? "bg-blue-900/30 text-blue-400" : "bg-blue-100 text-blue-700"
                        }`}
                      >
                        Time to Implement: {optimizationPlan.timeToImplement}
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium dark:text-white mb-3">Implementation Steps</h3>
                    <div className="space-y-3">
                      {optimizationPlan.steps.map((step: string, index: number) => (
                        <div
                          key={index}
                          className={`p-4 rounded-lg ${theme === "dark" ? "bg-gray-700" : "bg-white border border-gray-200"}`}
                        >
                          <div className="flex">
                            <div
                              className={`flex-shrink-0 h-6 w-6 rounded-full flex items-center justify-center mr-3 ${
                                theme === "dark" ? "bg-sky-900 text-sky-400" : "bg-sky-100 text-sky-700"
                              }`}
                            >
                              {index + 1}
                            </div>
                            <p className="dark:text-white">{step}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-center mt-6">
                    <Button className="bg-yellow-400 hover:bg-yellow-500 text-white dark:bg-yellow-600 dark:hover:bg-yellow-700">
                      Apply Optimization Plan
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center p-8">
                  <p className="dark:text-gray-300">
                    No optimization plan available. Click regenerate to create a plan.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  )
}

