"use client"

import { useState, useEffect } from "react"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"
import {
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  Leaf,
  BadgeCheck,
  ShoppingCart,
  DollarSign,
  TrendingUp,
} from "lucide-react"

// Mô phỏng dữ liệu tín chỉ carbon
const mockCarbonData = {
  userCredits: 12.5,
  totalSaved: 3.2, // tấn CO2
  estimatedValue: 187.5, // EUR
  marketPrice: 15.0, // EUR per credit
  priceChange: 2.3, // % change
  priceDirection: "up", // "up" or "down"
  transactions: [
    {
      id: 1,
      date: "2023-03-15",
      type: "sell",
      amount: 2.5,
      price: 14.2,
      total: 35.5,
      status: "completed",
      buyer: "Green Energy Co.",
    },
    {
      id: 2,
      date: "2023-02-28",
      type: "buy",
      amount: 1.0,
      price: 13.8,
      total: 13.8,
      status: "completed",
      seller: "Solar Community Pool",
    },
    {
      id: 3,
      date: "2023-01-10",
      type: "sell",
      amount: 5.0,
      price: 12.9,
      total: 64.5,
      status: "completed",
      buyer: "Carbon Neutral Ltd.",
    },
  ],
  marketOffers: [
    { id: 101, seller: "EcoSolar Finland", amount: 50.0, price: 14.9, total: 745.0, rating: 4.8 },
    { id: 102, seller: "Helsinki Green", amount: 25.0, price: 15.1, total: 377.5, rating: 4.6 },
    { id: 103, seller: "Nordic Sun Power", amount: 100.0, price: 14.85, total: 1485.0, rating: 4.9 },
    { id: 104, seller: "Tampere Solar Coop", amount: 15.0, price: 15.0, total: 225.0, rating: 4.7 },
  ],
  historicalPrices: [
    { date: "2023-01", price: 12.5 },
    { date: "2023-02", price: 13.2 },
    { date: "2023-03", price: 13.8 },
    { date: "2023-04", price: 14.1 },
    { date: "2023-05", price: 14.5 },
    { date: "2023-06", price: 14.3 },
    { date: "2023-07", price: 14.7 },
    { date: "2023-08", price: 15.0 },
  ],
}

export default function CarbonMarketPage() {
  const { t } = useLanguage()
  const { theme } = useTheme()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("overview")
  const [loading, setLoading] = useState(false)
  const [carbonData, setCarbonData] = useState(mockCarbonData)
  const [sellAmount, setSellAmount] = useState("")
  const [buyAmount, setBuyAmount] = useState("")
  const [selectedOffer, setSelectedOffer] = useState<number | null>(null)

  // Mô phỏng tải dữ liệu
  const fetchCarbonData = () => {
    setLoading(true)
    // Trong ứng dụng thực, đây sẽ là một cuộc gọi API
    setTimeout(() => {
      setCarbonData({
        ...mockCarbonData,
        marketPrice: mockCarbonData.marketPrice + (Math.random() * 0.5 - 0.25),
        priceChange: Math.random() * 4 - 2,
        priceDirection: Math.random() > 0.5 ? "up" : "down",
      })
      setLoading(false)
    }, 1000)
  }

  useEffect(() => {
    fetchCarbonData()
  }, [])

  // Xử lý bán tín chỉ carbon
  const handleSell = () => {
    const amount = Number.parseFloat(sellAmount)
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount to sell",
        variant: "destructive",
      })
      return
    }

    if (amount > carbonData.userCredits) {
      toast({
        title: "Insufficient credits",
        description: "You don't have enough carbon credits to sell",
        variant: "destructive",
      })
      return
    }

    // Mô phỏng giao dịch
    setLoading(true)
    setTimeout(() => {
      setCarbonData({
        ...carbonData,
        userCredits: carbonData.userCredits - amount,
        estimatedValue: carbonData.estimatedValue - amount * carbonData.marketPrice,
        transactions: [
          {
            id: Date.now(),
            date: new Date().toISOString().split("T")[0],
            type: "sell",
            amount: amount,
            price: carbonData.marketPrice,
            total: amount * carbonData.marketPrice,
            status: "completed",
            buyer: "Carbon Market",
          },
          ...carbonData.transactions,
        ],
      })

      toast({
        title: "Sale successful",
        description: `You sold ${amount} carbon credits for €${(amount * carbonData.marketPrice).toFixed(2)}`,
      })

      setSellAmount("")
      setLoading(false)
    }, 1500)
  }

  // Xử lý mua tín chỉ carbon
  const handleBuy = (offerId?: number) => {
    let amount = Number.parseFloat(buyAmount)
    let offer = null

    if (offerId) {
      offer = carbonData.marketOffers.find((o) => o.id === offerId)
      if (!offer) return
      amount = offer.amount
    }

    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount to buy",
        variant: "destructive",
      })
      return
    }

    const price = offer ? offer.price : carbonData.marketPrice
    const total = amount * price

    // Mô phỏng giao dịch
    setLoading(true)
    setTimeout(() => {
      setCarbonData({
        ...carbonData,
        userCredits: carbonData.userCredits + amount,
        estimatedValue: carbonData.estimatedValue + total,
        transactions: [
          {
            id: Date.now(),
            date: new Date().toISOString().split("T")[0],
            type: "buy",
            amount: amount,
            price: price,
            total: total,
            status: "completed",
            seller: offer ? offer.seller : "Carbon Market",
          },
          ...carbonData.transactions,
        ],
        marketOffers: offer ? carbonData.marketOffers.filter((o) => o.id !== offerId) : carbonData.marketOffers,
      })

      toast({
        title: "Purchase successful",
        description: `You bought ${amount} carbon credits for €${total.toFixed(2)}`,
      })

      setBuyAmount("")
      setSelectedOffer(null)
      setLoading(false)
    }, 1500)
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Carbon Credit Market</h1>
        <p className="text-gray-500 dark:text-gray-400">Trade carbon credits and contribute to a greener future</p>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="market">Market</TabsTrigger>
          <TabsTrigger value="portfolio">My Portfolio</TabsTrigger>
          <TabsTrigger value="history">Transaction History</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center dark:text-white">
                  <Wallet className="mr-2 h-5 w-5 text-green-500" />
                  Your Carbon Credits
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold dark:text-white">{carbonData.userCredits.toFixed(2)}</div>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Estimated value: €{carbonData.estimatedValue.toFixed(2)}
                </p>
              </CardContent>
            </Card>

            <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center dark:text-white">
                  <Leaf className="mr-2 h-5 w-5 text-green-500" />
                  CO₂ Emissions Avoided
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold dark:text-white">{carbonData.totalSaved.toFixed(1)} tons</div>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Equivalent to planting {Math.round(carbonData.totalSaved * 50)} trees
                </p>
              </CardContent>
            </Card>

            <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center dark:text-white">
                  <TrendingUp className="mr-2 h-5 w-5 text-green-500" />
                  Current Market Price
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <div className="text-3xl font-bold dark:text-white">€{carbonData.marketPrice.toFixed(2)}</div>
                  <div
                    className={`ml-2 flex items-center ${
                      carbonData.priceDirection === "up" ? "text-green-500" : "text-red-500"
                    }`}
                  >
                    {carbonData.priceDirection === "up" ? (
                      <ArrowUpRight className="h-4 w-4" />
                    ) : (
                      <ArrowDownRight className="h-4 w-4" />
                    )}
                    <span className="text-sm">{Math.abs(carbonData.priceChange).toFixed(1)}%</span>
                  </div>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Per carbon credit</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="dark:text-white">Price History</CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={fetchCarbonData}
                    disabled={loading}
                    className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
                  >
                    <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
                    Refresh
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-64 relative">
                  {/* Simplified chart visualization */}
                  <div className="absolute inset-0 flex items-end">
                    {carbonData.historicalPrices.map((item, index) => (
                      <div key={index} className="flex-1 flex flex-col items-center">
                        <div
                          className="w-full bg-green-500 dark:bg-green-600 rounded-t"
                          style={{
                            height: `${(item.price / 20) * 100}%`,
                            maxHeight: "90%",
                          }}
                        ></div>
                        <span className="text-xs mt-1 text-gray-500 dark:text-gray-400">{item.date}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
              <CardHeader>
                <CardTitle className="dark:text-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label className="dark:text-white">Sell Carbon Credits</Label>
                    <div className="flex space-x-2">
                      <Input
                        type="number"
                        placeholder="Amount to sell"
                        value={sellAmount}
                        onChange={(e) => setSellAmount(e.target.value)}
                        className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
                      />
                      <Button
                        onClick={handleSell}
                        disabled={loading}
                        className="bg-green-500 hover:bg-green-600 text-white"
                      >
                        Sell
                      </Button>
                    </div>
                    {sellAmount && !isNaN(Number.parseFloat(sellAmount)) && (
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        You will receive approximately €
                        {(Number.parseFloat(sellAmount) * carbonData.marketPrice).toFixed(2)}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label className="dark:text-white">Buy Carbon Credits</Label>
                    <div className="flex space-x-2">
                      <Input
                        type="number"
                        placeholder="Amount to buy"
                        value={buyAmount}
                        onChange={(e) => setBuyAmount(e.target.value)}
                        className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
                      />
                      <Button
                        onClick={() => handleBuy()}
                        disabled={loading}
                        className="bg-blue-500 hover:bg-blue-600 text-white"
                      >
                        Buy
                      </Button>
                    </div>
                    {buyAmount && !isNaN(Number.parseFloat(buyAmount)) && (
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Total cost: €{(Number.parseFloat(buyAmount) * carbonData.marketPrice).toFixed(2)}
                      </p>
                    )}
                  </div>

                  <div className={`p-4 rounded-lg ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"}`}>
                    <h3 className="font-medium dark:text-white mb-2">Why Trade Carbon Credits?</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      By trading carbon credits, you're participating in a global effort to reduce carbon emissions.
                      Each credit represents one ton of CO₂ emissions avoided or removed from the atmosphere.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Market Tab */}
        <TabsContent value="market">
          <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="dark:text-white">Available Carbon Credits</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={fetchCarbonData}
                  disabled={loading}
                  className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
                >
                  <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
                  Refresh Market
                </Button>
              </div>
              <CardDescription className="dark:text-gray-400">
                Browse and purchase carbon credits from verified sellers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {carbonData.marketOffers.map((offer) => (
                  <div
                    key={offer.id}
                    className={`p-4 rounded-lg border ${
                      selectedOffer === offer.id
                        ? theme === "dark"
                          ? "bg-green-900/20 border-green-800"
                          : "bg-green-50 border-green-200"
                        : theme === "dark"
                          ? "bg-gray-700 border-gray-600"
                          : "bg-white border-gray-200"
                    } transition-colors cursor-pointer`}
                    onClick={() => setSelectedOffer(selectedOffer === offer.id ? null : offer.id)}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center">
                          <h3 className="font-medium dark:text-white">{offer.seller}</h3>
                          <BadgeCheck className="ml-1 h-4 w-4 text-green-500" />
                          <div className="ml-2 text-sm text-yellow-500">
                            {"★".repeat(Math.floor(offer.rating))}
                            <span className="text-gray-400 dark:text-gray-500">
                              {"★".repeat(5 - Math.floor(offer.rating))}
                            </span>
                          </div>
                        </div>
                        <div className="mt-2 flex items-center">
                          <div className="mr-4">
                            <span className="text-sm text-gray-500 dark:text-gray-400">Amount:</span>
                            <span className="ml-1 font-medium dark:text-white">{offer.amount.toFixed(1)} credits</span>
                          </div>
                          <div>
                            <span className="text-sm text-gray-500 dark:text-gray-400">Price:</span>
                            <span className="ml-1 font-medium dark:text-white">€{offer.price.toFixed(2)}/credit</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-lg dark:text-white">€{offer.total.toFixed(2)}</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">Total value</div>
                      </div>
                    </div>

                    {selectedOffer === offer.id && (
                      <div className="mt-4 flex justify-end">
                        <Button
                          onClick={() => handleBuy(offer.id)}
                          disabled={loading}
                          className="bg-green-500 hover:bg-green-600 text-white"
                        >
                          <ShoppingCart className="mr-2 h-4 w-4" />
                          Purchase Credits
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Portfolio Tab */}
        <TabsContent value="portfolio">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
              <CardHeader>
                <CardTitle className="dark:text-white">Your Carbon Portfolio</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className={`p-6 rounded-lg ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"}`}>
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-medium dark:text-white">Current Holdings</h3>
                      <div className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 px-3 py-1 rounded-full text-sm">
                        Active
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-500 dark:text-gray-400">Total Credits:</span>
                        <span className="font-medium dark:text-white">{carbonData.userCredits.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500 dark:text-gray-400">Market Value:</span>
                        <span className="font-medium dark:text-white">€{carbonData.estimatedValue.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500 dark:text-gray-400">Average Price:</span>
                        <span className="font-medium dark:text-white">
                          €{(carbonData.estimatedValue / carbonData.userCredits).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="dark:text-white">Sell All Credits</Label>
                    <div className="flex items-center space-x-2">
                      <div className="flex-1">
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Current market value: €{(carbonData.userCredits * carbonData.marketPrice).toFixed(2)}
                        </p>
                      </div>
                      <Button
                        onClick={() => {
                          setSellAmount(carbonData.userCredits.toString())
                          handleSell()
                        }}
                        disabled={loading || carbonData.userCredits <= 0}
                        className="bg-green-500 hover:bg-green-600 text-white"
                      >
                        <DollarSign className="mr-2 h-4 w-4" />
                        Sell All
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
              <CardHeader>
                <CardTitle className="dark:text-white">Environmental Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div
                    className={`p-6 rounded-lg ${theme === "dark" ? "bg-green-900/20 border border-green-800" : "bg-green-50 border border-green-100"}`}
                  >
                    <h3 className="text-lg font-medium text-green-700 dark:text-green-400 mb-4">Your Contribution</h3>

                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-green-600 dark:text-green-300">CO₂ Emissions Avoided</span>
                          <span className="text-sm font-medium text-green-700 dark:text-green-400">
                            {carbonData.totalSaved.toFixed(1)} tons
                          </span>
                        </div>
                        <div className="w-full bg-green-200 dark:bg-green-800 rounded-full h-2">
                          <div
                            className="bg-green-500 h-2 rounded-full"
                            style={{ width: `${Math.min(100, carbonData.totalSaved * 10)}%` }}
                          ></div>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-green-600 dark:text-green-300">Equivalent Trees Planted</span>
                          <span className="text-sm font-medium text-green-700 dark:text-green-400">
                            {Math.round(carbonData.totalSaved * 50)} trees
                          </span>
                        </div>
                        <div className="w-full bg-green-200 dark:bg-green-800 rounded-full h-2">
                          <div
                            className="bg-green-500 h-2 rounded-full"
                            style={{ width: `${Math.min(100, carbonData.totalSaved * 5)}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className={`p-4 rounded-lg ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"}`}>
                    <h3 className="font-medium dark:text-white mb-2">Carbon Offset Certificate</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                      Generate an official certificate for your carbon offsets to share with others or use for
                      reporting.
                    </p>
                    <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white">Generate Certificate</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Transaction History Tab */}
        <TabsContent value="history">
          <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
            <CardHeader>
              <CardTitle className="dark:text-white">Transaction History</CardTitle>
              <CardDescription className="dark:text-gray-400">
                View your past carbon credit transactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {carbonData.transactions.length > 0 ? (
                  carbonData.transactions.map((transaction) => (
                    <div
                      key={transaction.id}
                      className={`p-4 rounded-lg border ${
                        transaction.type === "buy"
                          ? theme === "dark"
                            ? "bg-blue-900/20 border-blue-800"
                            : "bg-blue-50 border-blue-100"
                          : theme === "dark"
                            ? "bg-green-900/20 border-green-800"
                            : "bg-green-50 border-green-100"
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3
                            className={`font-medium ${
                              transaction.type === "buy"
                                ? "text-blue-700 dark:text-blue-400"
                                : "text-green-700 dark:text-green-400"
                            }`}
                          >
                            {transaction.type === "buy" ? "Purchased" : "Sold"} {transaction.amount.toFixed(1)} Credits
                          </h3>
                          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                            {transaction.date} • €{transaction.price.toFixed(2)}/credit
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                            {transaction.type === "buy" ? `From: ${transaction.seller}` : `To: ${transaction.buyer}`}
                          </p>
                        </div>
                        <div className="text-right">
                          <div
                            className={`font-bold ${
                              transaction.type === "buy"
                                ? "text-blue-700 dark:text-blue-400"
                                : "text-green-700 dark:text-green-400"
                            }`}
                          >
                            {transaction.type === "buy" ? "-" : "+"} €{transaction.total.toFixed(2)}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            Status: {transaction.status}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center p-6">
                    <p className="text-gray-500 dark:text-gray-400">No transaction history available</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  )
}

