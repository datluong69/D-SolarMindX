"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import DashboardLayout from "@/components/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar } from "@/components/ui/avatar"
import { Paperclip, Send, Mic, Calendar, FileText } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"
import { useRouter } from "next/navigation"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"

// Backend simulation
import { simulateExpertResponse } from "@/lib/expert-backend"

export default function ChatPage() {
  const { t } = useLanguage()
  const { theme } = useTheme()
  const router = useRouter()
  const { toast } = useToast()
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: "expert",
      name: "Jasmine Luong",
      role: "Solar Engineer",
      avatar: "/placeholder.svg?height=40&width=40",
      content:
        "Hello! I'm Jasmine, your dedicated solar engineer. How can I assist you with your solar panel system today?",
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ])

  const [input, setInput] = useState("")
  const [uploading, setUploading] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [selectedExpert, setSelectedExpert] = useState("jasmine") // Default expert
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false)
  const [scheduleDate, setScheduleDate] = useState("")
  const [scheduleTime, setScheduleTime] = useState("")
  const [scheduleType, setScheduleType] = useState("consultation")

  const experts = {
    jasmine: {
      name: "Jasmine Luong",
      role: "Solar Engineer",
      avatar: "/placeholder.svg?height=40&width=40",
      expertise: ["Panel installation", "System optimization", "Technical troubleshooting"],
    },
    tram: {
      name: "Trâm LA",
      role: "Technical Support",
      avatar: "/placeholder.svg?height=40&width=40",
      expertise: ["Maintenance scheduling", "Software support", "Customer service"],
    },
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() && !uploading) return

    // Add user message
    const newUserMessage = {
      id: messages.length + 1,
      sender: "user",
      name: "You",
      content: uploading ? "Here's a photo of the issue with my solar panel." : input,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      hasImage: uploading,
    }

    setMessages((prev) => [...prev, newUserMessage])
    setInput("")
    setUploading(false)
    setIsTyping(true)

    try {
      // Simulate expert response
      const currentExpert = selectedExpert === "jasmine" ? experts.jasmine : experts.tram
      const expertResponse = await simulateExpertResponse(
        newUserMessage.content,
        messages,
        currentExpert.name,
        currentExpert.role,
      )

      // Add expert response after a delay to simulate typing
      setTimeout(() => {
        const response = {
          id: messages.length + 2,
          sender: "expert",
          name: currentExpert.name,
          role: currentExpert.role,
          avatar: currentExpert.avatar,
          content: expertResponse,
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        }

        setMessages((prev) => [...prev, response])
        setIsTyping(false)
      }, 2000)
    } catch (error) {
      console.error("Error getting expert response:", error)
      setIsTyping(false)
    }
  }

  const handleFileUpload = () => {
    setUploading(true)
  }

  const handleVoiceInput = () => {
    setIsRecording(!isRecording)

    if (!isRecording) {
      // Simulate voice recording
      setTimeout(() => {
        const voiceCommands = [
          "I'm having issues with my inverter, it keeps showing error code E-14",
          "My solar production seems lower than expected this month",
          "Can you help me understand my energy consumption patterns?",
          "I noticed some discoloration on one of my panels",
          "When would be the best time to schedule panel cleaning?",
        ]
        const randomCommand = voiceCommands[Math.floor(Math.random() * voiceCommands.length)]
        setInput(randomCommand)
        setIsRecording(false)
      }, 2000)
    }
  }

  const handleScheduleConsultation = () => {
    setScheduleDialogOpen(true)

    // Set default date to tomorrow
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    setScheduleDate(tomorrow.toISOString().split("T")[0])

    // Set default time to 10:00 AM
    setScheduleTime("10:00")
  }

  const handleScheduleSubmit = () => {
    if (!scheduleDate || !scheduleTime) {
      toast({
        title: "Missing information",
        description: "Please select both date and time",
        variant: "destructive",
      })
      return
    }

    setScheduleDialogOpen(false)

    // Add system message about scheduled consultation
    const systemMessage = {
      id: messages.length + 1,
      sender: "system",
      content: `You've scheduled a ${scheduleType} with ${selectedExpert === "jasmine" ? "Jasmine Luong" : "Trâm LA"} on ${scheduleDate} at ${scheduleTime}.`,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages((prev) => [...prev, systemMessage])

    toast({
      title: "Consultation scheduled",
      description: `Your ${scheduleType} has been scheduled for ${scheduleDate} at ${scheduleTime}`,
    })
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">{t("chat.title")}</h1>
        <p className="text-gray-500 dark:text-gray-400">{t("chat.subtitle")}</p>
      </div>

      <div className="mb-4 flex space-x-4">
        <Button
          variant={selectedExpert === "jasmine" ? "default" : "outline"}
          className={selectedExpert === "jasmine" ? "bg-sky-500" : ""}
          onClick={() => setSelectedExpert("jasmine")}
        >
          Chat with Jasmine Luong
        </Button>
        <Button
          variant={selectedExpert === "tram" ? "default" : "outline"}
          className={selectedExpert === "tram" ? "bg-sky-500" : ""}
          onClick={() => setSelectedExpert("tram")}
        >
          Chat with Trâm LA
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
        <div className="md:col-span-3">
          <Card
            className={`h-[calc(100vh-280px)] flex flex-col ${theme === "dark" ? "bg-gray-800 border-gray-700" : ""}`}
          >
            <CardContent className="flex-1 p-4 overflow-y-auto flex flex-col gap-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === "user" ? "justify-end" : message.sender === "system" ? "justify-center" : "justify-start"}`}
                >
                  {message.sender === "system" ? (
                    <div
                      className={`px-4 py-2 rounded-lg ${theme === "dark" ? "bg-gray-700 text-gray-300" : "bg-gray-100 text-gray-700"} text-sm`}
                    >
                      {message.content}
                    </div>
                  ) : (
                    <div
                      className={`max-w-[80%] rounded-lg p-4 ${
                        message.sender === "user"
                          ? theme === "dark"
                            ? "bg-yellow-800 text-yellow-100"
                            : "bg-yellow-100 text-yellow-900"
                          : theme === "dark"
                            ? "bg-sky-900 text-sky-100"
                            : "bg-sky-100 text-sky-900"
                      }`}
                    >
                      {message.sender === "expert" && (
                        <div className="flex items-center mb-2">
                          <Avatar className="h-8 w-8 mr-2">
                            <img src={message.avatar || "/placeholder.svg"} alt={message.name} />
                          </Avatar>
                          <div>
                            <p className="font-medium text-sm">{message.name}</p>
                            <p className={`text-xs ${theme === "dark" ? "text-gray-300" : "text-gray-500"}`}>
                              {message.role}
                            </p>
                          </div>
                        </div>
                      )}

                      <div>
                        {message.content}

                        {message.hasImage && (
                          <div className="mt-2">
                            <div className="relative rounded-lg overflow-hidden">
                              <img
                                src="/placeholder.svg?height=200&width=300"
                                alt="Uploaded solar panel"
                                className="w-full h-auto"
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="text-right mt-1">
                        <span className={`text-xs ${theme === "dark" ? "text-gray-300" : "text-gray-500"}`}>
                          {message.time}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div
                    className={`max-w-[80%] rounded-lg p-4 ${theme === "dark" ? "bg-sky-900 text-sky-100" : "bg-sky-100 text-sky-900"}`}
                  >
                    <div className="flex items-center mb-2">
                      <Avatar className="h-8 w-8 mr-2">
                        <img
                          src={selectedExpert === "jasmine" ? experts.jasmine.avatar : experts.tram.avatar}
                          alt={selectedExpert === "jasmine" ? experts.jasmine.name : experts.tram.name}
                        />
                      </Avatar>
                      <div>
                        <p className="font-medium text-sm">
                          {selectedExpert === "jasmine" ? experts.jasmine.name : experts.tram.name}
                        </p>
                        <p className={`text-xs ${theme === "dark" ? "text-gray-300" : "text-gray-500"}`}>
                          {selectedExpert === "jasmine" ? experts.jasmine.role : experts.tram.role}
                        </p>
                      </div>
                    </div>
                    <div className="flex space-x-1">
                      <div className="h-2 w-2 rounded-full bg-current animate-bounce"></div>
                      <div
                        className="h-2 w-2 rounded-full bg-current animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                      <div
                        className="h-2 w-2 rounded-full bg-current animate-bounce"
                        style={{ animationDelay: "0.4s" }}
                      ></div>
                    </div>
                  </div>
                </div>
              )}

              {isRecording && (
                <div className="self-center p-2 bg-red-100 dark:bg-red-900 rounded-lg text-red-600 dark:text-red-300 flex items-center">
                  <span className="animate-pulse mr-2 h-2 w-2 rounded-full bg-red-500"></span>
                  Recording...
                </div>
              )}

              <div ref={messagesEndRef} />
            </CardContent>

            <div className={`p-4 border-t ${theme === "dark" ? "border-gray-700" : ""}`}>
              <div className="flex flex-wrap gap-1 mb-2">
                <Button variant="outline" size="sm" className="text-xs h-7 px-2" onClick={handleScheduleConsultation}>
                  <Calendar className="h-3 w-3 mr-1" />
                  Schedule consultation
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs h-7 px-2"
                  onClick={() => {
                    router.push("/dashboard/schedule")
                  }}
                >
                  Schedule maintenance
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs h-7 px-2"
                  onClick={() => {
                    setInput("Can you explain my latest energy report?")
                    setTimeout(() => {
                      const form = document.getElementById("expert-chat-form") as HTMLFormElement
                      form?.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }))
                    }, 100)
                  }}
                >
                  <FileText className="h-3 w-3 mr-1" />
                  Energy report
                </Button>
              </div>

              <form id="expert-chat-form" onSubmit={handleSendMessage} className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={handleFileUpload}
                  className={uploading ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300" : ""}
                >
                  <Paperclip className="h-4 w-4" />
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className={isRecording ? "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300" : ""}
                  onClick={handleVoiceInput}
                >
                  <Mic className="h-4 w-4" />
                </Button>
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={uploading ? t("chat.image") : t("chat.placeholder")}
                  className={`flex-1 ${theme === "dark" ? "bg-gray-700 text-white border-gray-600" : ""}`}
                />
                <Button
                  type="submit"
                  className="bg-yellow-400 hover:bg-yellow-500 text-white dark:bg-yellow-600 dark:hover:bg-yellow-700"
                >
                  <Send className="h-4 w-4 mr-2" />
                  {t("chat.send")}
                </Button>
              </form>
            </div>
          </Card>
        </div>

        <div className="hidden md:block">
          <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
            <CardContent className="p-4">
              <div className="flex flex-col items-center mb-4">
                <Avatar className="h-16 w-16 mb-2">
                  <img
                    src={selectedExpert === "jasmine" ? experts.jasmine.avatar : experts.tram.avatar}
                    alt={selectedExpert === "jasmine" ? experts.jasmine.name : experts.tram.name}
                    className="h-full w-full object-cover"
                  />
                </Avatar>
                <h3 className="font-medium text-lg dark:text-white">
                  {selectedExpert === "jasmine" ? experts.jasmine.name : experts.tram.name}
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {selectedExpert === "jasmine" ? experts.jasmine.role : experts.tram.role}
                </p>
              </div>

              <div className="mb-4">
                <h4 className="text-sm font-medium mb-2 dark:text-gray-300">Expertise</h4>
                <ul className="space-y-1">
                  {(selectedExpert === "jasmine" ? experts.jasmine.expertise : experts.tram.expertise).map(
                    (item, index) => (
                      <li key={index} className="text-sm flex items-center">
                        <span className="h-1.5 w-1.5 rounded-full bg-yellow-400 mr-2"></span>
                        <span className="dark:text-gray-300">{item}</span>
                      </li>
                    ),
                  )}
                </ul>
              </div>

              <div className="mb-4">
                <h4 className="text-sm font-medium mb-2 dark:text-gray-300">Availability</h4>
                <p className="text-sm dark:text-gray-300">
                  <span className="inline-block h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                  Online now
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Typical response time: &lt;5 minutes</p>
              </div>

              <Button
                className="w-full bg-yellow-400 hover:bg-yellow-500 text-white dark:bg-yellow-600 dark:hover:bg-yellow-700"
                onClick={handleScheduleConsultation}
              >
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Consultation
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Schedule Dialog */}
      <Dialog open={scheduleDialogOpen} onOpenChange={setScheduleDialogOpen}>
        <DialogContent className={theme === "dark" ? "bg-gray-800 border-gray-700 text-white" : ""}>
          <DialogHeader>
            <DialogTitle>Schedule a Consultation</DialogTitle>
            <DialogDescription className={theme === "dark" ? "text-gray-400" : ""}>
              Book a time to speak with {selectedExpert === "jasmine" ? "Jasmine Luong" : "Trâm LA"}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="consultation-type" className={theme === "dark" ? "text-white" : ""}>
                Consultation Type
              </Label>
              <Select value={scheduleType} onValueChange={setScheduleType}>
                <SelectTrigger
                  id="consultation-type"
                  className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
                >
                  <SelectValue placeholder="Select consultation type" />
                </SelectTrigger>
                <SelectContent className={theme === "dark" ? "bg-gray-800 border-gray-700 text-white" : ""}>
                  <SelectItem value="consultation">General Consultation</SelectItem>
                  <SelectItem value="troubleshooting">Technical Troubleshooting</SelectItem>
                  <SelectItem value="optimization">System Optimization</SelectItem>
                  <SelectItem value="expansion">System Expansion Planning</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="schedule-date" className={theme === "dark" ? "text-white" : ""}>
                Date
              </Label>
              <Input
                id="schedule-date"
                type="date"
                value={scheduleDate}
                onChange={(e) => setScheduleDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
                className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="schedule-time" className={theme === "dark" ? "text-white" : ""}>
                Time
              </Label>
              <Input
                id="schedule-time"
                type="time"
                value={scheduleTime}
                onChange={(e) => setScheduleTime(e.target.value)}
                className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
              />
            </div>

            <div className={`p-3 rounded-lg ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"}`}>
              <p className="text-sm">
                Consultation with{" "}
                <span className="font-bold">{selectedExpert === "jasmine" ? "Jasmine Luong" : "Trâm LA"}</span>
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {scheduleType === "consultation" && "General discussion about your solar system"}
                {scheduleType === "troubleshooting" && "Technical assistance with system issues"}
                {scheduleType === "optimization" && "Advice on improving system performance"}
                {scheduleType === "expansion" && "Planning for adding more panels or storage"}
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setScheduleDialogOpen(false)}
              className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
            >
              Cancel
            </Button>
            <Button
              onClick={handleScheduleSubmit}
              className="bg-yellow-400 hover:bg-yellow-500 text-white dark:bg-yellow-600 dark:hover:bg-yellow-700"
            >
              Schedule
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}

