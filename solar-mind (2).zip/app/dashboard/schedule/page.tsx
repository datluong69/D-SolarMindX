"use client"

import { useState } from "react"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"

export default function SchedulePage() {
  const { t } = useLanguage()
  const { theme } = useTheme()
  const { toast } = useToast()
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [time, setTime] = useState("09:00")
  const [taskType, setTaskType] = useState("cleaning")
  const [description, setDescription] = useState("")
  const [schedules, setSchedules] = useState([
    {
      id: 1,
      date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      time: "10:00",
      type: "cleaning",
      description: "Regular panel cleaning",
      status: "scheduled",
    },
    {
      id: 2,
      date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
      time: "14:30",
      type: "maintenance",
      description: "Quarterly system check",
      status: "scheduled",
    },
  ])

  const handleSchedule = () => {
    if (!date || !time || !taskType) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    const newSchedule = {
      id: schedules.length + 1,
      date: date,
      time: time,
      type: taskType,
      description: description,
      status: "scheduled",
    }

    setSchedules([...schedules, newSchedule])

    toast({
      title: "Task scheduled",
      description: `Your ${taskType} task has been scheduled for ${date.toLocaleDateString()} at ${time}`,
    })

    // Reset form
    setDescription("")
  }

  const handleCancel = (id: number) => {
    setSchedules(schedules.map((schedule) => (schedule.id === id ? { ...schedule, status: "cancelled" } : schedule)))

    toast({
      title: "Task cancelled",
      description: "The scheduled task has been cancelled",
    })
  }

  const getTaskTypeLabel = (type: string) => {
    switch (type) {
      case "cleaning":
        return "Panel Cleaning"
      case "maintenance":
        return "System Maintenance"
      case "repair":
        return "Repair Service"
      case "inspection":
        return "System Inspection"
      default:
        return type
    }
  }

  const getTaskTypeColor = (type: string) => {
    switch (type) {
      case "cleaning":
        return theme === "dark"
          ? "bg-blue-900/30 text-blue-400 border-blue-800"
          : "bg-blue-100 text-blue-700 border-blue-200"
      case "maintenance":
        return theme === "dark"
          ? "bg-green-900/30 text-green-400 border-green-800"
          : "bg-green-100 text-green-700 border-green-200"
      case "repair":
        return theme === "dark" ? "bg-red-900/30 text-red-400 border-red-800" : "bg-red-100 text-red-700 border-red-200"
      case "inspection":
        return theme === "dark"
          ? "bg-yellow-900/30 text-yellow-400 border-yellow-800"
          : "bg-yellow-100 text-yellow-700 border-yellow-200"
      default:
        return theme === "dark"
          ? "bg-gray-800 text-gray-300 border-gray-700"
          : "bg-gray-100 text-gray-700 border-gray-200"
    }
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Maintenance Schedule</h1>
        <p className="text-gray-500 dark:text-gray-400">Schedule maintenance and cleaning for your solar panels</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className={`md:col-span-1 ${theme === "dark" ? "bg-gray-800 border-gray-700" : ""}`}>
          <CardHeader>
            <CardTitle className="dark:text-white">Schedule New Task</CardTitle>
            <CardDescription className="dark:text-gray-400">Set up maintenance or cleaning</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="task-type" className="dark:text-white">
                Task Type
              </Label>
              <Select value={taskType} onValueChange={setTaskType}>
                <SelectTrigger
                  id="task-type"
                  className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
                >
                  <SelectValue placeholder="Select task type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cleaning">Panel Cleaning</SelectItem>
                  <SelectItem value="maintenance">System Maintenance</SelectItem>
                  <SelectItem value="repair">Repair Service</SelectItem>
                  <SelectItem value="inspection">System Inspection</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="dark:text-white">Date</Label>
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                className={`border rounded-md p-3 ${theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}`}
                disabled={(date) => date < new Date()}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="time" className="dark:text-white">
                Time
              </Label>
              <Input
                id="time"
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="dark:text-white">
                Description (Optional)
              </Label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Add notes or special instructions"
                className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
              />
            </div>

            <Button
              onClick={handleSchedule}
              className="w-full bg-yellow-400 hover:bg-yellow-500 text-white dark:bg-yellow-600 dark:hover:bg-yellow-700"
            >
              Schedule Task
            </Button>
          </CardContent>
        </Card>

        <Card className={`md:col-span-2 ${theme === "dark" ? "bg-gray-800 border-gray-700" : ""}`}>
          <CardHeader>
            <CardTitle className="dark:text-white">Upcoming Tasks</CardTitle>
            <CardDescription className="dark:text-gray-400">View and manage your scheduled maintenance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {schedules.length === 0 ? (
                <div
                  className={`p-4 text-center rounded-lg border ${theme === "dark" ? "border-gray-700 text-gray-400" : "border-gray-200 text-gray-500"}`}
                >
                  No scheduled tasks. Use the form to schedule maintenance or cleaning.
                </div>
              ) : (
                schedules.map((schedule) => (
                  <div
                    key={schedule.id}
                    className={`p-4 rounded-lg border ${
                      schedule.status === "cancelled"
                        ? theme === "dark"
                          ? "bg-gray-700/50 border-gray-700 opacity-60"
                          : "bg-gray-100 border-gray-200 opacity-60"
                        : getTaskTypeColor(schedule.type)
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">{getTaskTypeLabel(schedule.type)}</h3>
                        <p className="text-sm mt-1">
                          {schedule.date.toLocaleDateString()} at {schedule.time}
                        </p>
                        {schedule.description && <p className="text-sm mt-2">{schedule.description}</p>}
                      </div>
                      <div>
                        {schedule.status === "scheduled" ? (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleCancel(schedule.id)}
                            className={theme === "dark" ? "border-gray-600 text-gray-300 hover:bg-gray-700" : ""}
                          >
                            Cancel
                          </Button>
                        ) : (
                          <span className="text-xs px-2 py-1 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400">
                            Cancelled
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

