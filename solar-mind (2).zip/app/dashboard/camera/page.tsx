"use client"

import DashboardLayout from "@/components/dashboard-layout"
import CameraAccess from "@/components/camera-access"

export default function CameraPage() {
  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Camera Access</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Take photos of your solar panels for analysis and troubleshooting
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="md:col-span-2">
          <CameraAccess />
        </div>
      </div>
    </DashboardLayout>
  )
}

