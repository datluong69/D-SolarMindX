"use client"

import { useState } from "react"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"

export default function SettingsPage() {
  const { t, language, setLanguage } = useLanguage()
  const { theme, toggleTheme } = useTheme()

  const [name, setName] = useState("John Doe")
  const [email, setEmail] = useState("john.doe@example.com")
  const [phone, setPhone] = useState("+1 (555) 123-4567")
  const [units, setUnits] = useState("metric")
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
    maintenance: true,
    performance: true,
    weather: false,
  })

  const handleSave = () => {
    // Simulate saving settings
    alert("Settings saved successfully!")
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">{t("settings.title")}</h1>
        <p className="text-gray-500 dark:text-gray-400">{t("settings.subtitle")}</p>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList>
          <TabsTrigger value="profile">{t("settings.profile")}</TabsTrigger>
          <TabsTrigger value="system">{t("settings.system")}</TabsTrigger>
          <TabsTrigger value="notifications">{t("settings.notifications")}</TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
            <CardHeader>
              <CardTitle className="dark:text-white">{t("settings.profile")}</CardTitle>
              <CardDescription className="dark:text-gray-400">Manage your personal information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="dark:text-white">
                  Name
                </Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="dark:text-white">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone" className="dark:text-white">
                  Phone
                </Label>
                <Input
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}
                />
              </div>

              <div className="pt-4">
                <Button onClick={handleSave} className="bg-yellow-400 hover:bg-yellow-500 text-white">
                  {t("settings.save")}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="system">
          <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
            <CardHeader>
              <CardTitle className="dark:text-white">{t("settings.system")}</CardTitle>
              <CardDescription className="dark:text-gray-400">Configure system preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="language" className="dark:text-white">
                  {t("settings.language")}
                </Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}>
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="vi">Tiếng Việt</SelectItem>
                    <SelectItem value="zh">中文</SelectItem>
                    <SelectItem value="fr">Français</SelectItem>
                    <SelectItem value="es">Español</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="units" className="dark:text-white">
                  {t("settings.units")}
                </Label>
                <Select value={units} onValueChange={setUnits}>
                  <SelectTrigger className={theme === "dark" ? "bg-gray-700 border-gray-600 text-white" : ""}>
                    <SelectValue placeholder="Select units" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="metric">Metric (°C, km/h)</SelectItem>
                    <SelectItem value="imperial">Imperial (°F, mph)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="dark:text-white">{t("settings.theme")}</Label>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {theme === "dark" ? "Dark mode enabled" : "Light mode enabled"}
                  </p>
                </div>
                <Switch checked={theme === "dark"} onCheckedChange={toggleTheme} />
              </div>

              <div className="pt-4">
                <Button onClick={handleSave} className="bg-yellow-400 hover:bg-yellow-500 text-white">
                  {t("settings.save")}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
            <CardHeader>
              <CardTitle className="dark:text-white">{t("settings.notifications")}</CardTitle>
              <CardDescription className="dark:text-gray-400">Configure how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4 dark:text-white">Notification Channels</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="dark:text-white">Email Notifications</Label>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Receive notifications via email</p>
                      </div>
                      <Switch
                        checked={notifications.email}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, email: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="dark:text-white">Push Notifications</Label>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Receive notifications on your device</p>
                      </div>
                      <Switch
                        checked={notifications.push}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, push: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="dark:text-white">SMS Notifications</Label>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Receive notifications via SMS</p>
                      </div>
                      <Switch
                        checked={notifications.sms}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, sms: checked })}
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t dark:border-gray-700">
                  <h3 className="text-lg font-medium mb-4 dark:text-white">Notification Types</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="dark:text-white">Maintenance Alerts</Label>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Notifications about system maintenance
                        </p>
                      </div>
                      <Switch
                        checked={notifications.maintenance}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, maintenance: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="dark:text-white">Performance Reports</Label>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Weekly and monthly performance summaries
                        </p>
                      </div>
                      <Switch
                        checked={notifications.performance}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, performance: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="dark:text-white">Weather Alerts</Label>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Notifications about weather conditions affecting your system
                        </p>
                      </div>
                      <Switch
                        checked={notifications.weather}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, weather: checked })}
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <Button onClick={handleSave} className="bg-yellow-400 hover:bg-yellow-500 text-white">
                    {t("settings.save")}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  )
}

