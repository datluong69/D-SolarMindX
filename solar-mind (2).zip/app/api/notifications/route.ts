import { NextResponse } from "next/server"

// Simulated notifications database
let notifications: Array<{
  id: string
  type: string
  title: string
  message: string
  time: string
  action?: string
  price?: string
  userId: string
  read: boolean
  scheduled?: boolean
  scheduledDate?: string
  scheduledTime?: string
}> = []

// Generate some initial notifications
function generateInitialNotifications(userId: string) {
  return [
    {
      id: "1",
      type: "error",
      title: "Panel Connection Issue",
      message: "Connection to panel #3 has been lost. This may affect power generation.",
      time: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      action: "Schedule Repair",
      price: "$120",
      userId,
      read: false,
    },
    {
      id: "2",
      type: "warning",
      title: "Dust Accumulation Detected",
      message: "Dust levels on your panels are higher than normal. This may reduce efficiency.",
      time: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      action: "Schedule Cleaning",
      price: "$80",
      userId,
      read: false,
    },
    {
      id: "3",
      type: "info",
      title: "Maintenance Reminder",
      message: "Your quarterly maintenance check is due in 5 days.",
      time: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      action: "Schedule Maintenance",
      price: "$150",
      userId,
      read: false,
    },
    {
      id: "4",
      type: "success",
      title: "Optimization Complete",
      message: "AI optimization has improved your panel efficiency by 12% this month.",
      time: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      userId,
      read: true,
    },
  ]
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId") || "default-user"

    // If no notifications exist for this user, generate some
    if (!notifications.some((n) => n.userId === userId)) {
      notifications = [...notifications, ...generateInitialNotifications(userId)]
    }

    // Get notifications for the user
    const userNotifications = notifications
      .filter((notification) => notification.userId === userId)
      .sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime())

    return NextResponse.json({
      success: true,
      notifications: userNotifications,
    })
  } catch (error) {
    console.error("Error fetching notifications:", error)
    return NextResponse.json({ success: false, message: "Failed to fetch notifications" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.type || !data.title || !data.message || !data.userId) {
      return NextResponse.json({ success: false, message: "Missing required notification fields" }, { status: 400 })
    }

    // Create notification
    const notification = {
      id: Math.random().toString(36).substring(2, 15),
      type: data.type,
      title: data.title,
      message: data.message,
      time: new Date().toISOString(),
      action: data.action,
      price: data.price,
      userId: data.userId,
      read: false,
      scheduled: data.scheduled || false,
      scheduledDate: data.scheduledDate,
      scheduledTime: data.scheduledTime,
    }

    // Save notification
    notifications.push(notification)

    return NextResponse.json({
      success: true,
      message: "Notification created successfully",
      notification,
    })
  } catch (error) {
    console.error("Error creating notification:", error)
    return NextResponse.json({ success: false, message: "Failed to create notification" }, { status: 500 })
  }
}

export async function PATCH(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.id) {
      return NextResponse.json({ success: false, message: "Notification ID is required" }, { status: 400 })
    }

    // Find the notification
    const notificationIndex = notifications.findIndex((n) => n.id === data.id)
    if (notificationIndex === -1) {
      return NextResponse.json({ success: false, message: "Notification not found" }, { status: 404 })
    }

    // Update notification
    notifications[notificationIndex] = {
      ...notifications[notificationIndex],
      ...data,
    }

    return NextResponse.json({
      success: true,
      message: "Notification updated successfully",
      notification: notifications[notificationIndex],
    })
  } catch (error) {
    console.error("Error updating notification:", error)
    return NextResponse.json({ success: false, message: "Failed to update notification" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ success: false, message: "Notification ID is required" }, { status: 400 })
    }

    // Find the notification
    const notificationIndex = notifications.findIndex((n) => n.id === id)
    if (notificationIndex === -1) {
      return NextResponse.json({ success: false, message: "Notification not found" }, { status: 404 })
    }

    // Remove the notification
    notifications.splice(notificationIndex, 1)

    return NextResponse.json({
      success: true,
      message: "Notification deleted successfully",
    })
  } catch (error) {
    console.error("Error deleting notification:", error)
    return NextResponse.json({ success: false, message: "Failed to delete notification" }, { status: 500 })
  }
}

