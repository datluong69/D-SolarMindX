import { NextResponse } from "next/server"
import { getWeatherForecast } from "@/lib/backend/weather-service"
import { UNITS, FINLAND_CITIES } from "@/lib/backend/config"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)

    // Lấy tham số từ URL
    const latParam = searchParams.get("lat")
    const lonParam = searchParams.get("lon")
    const units = searchParams.get("units") || UNITS.METRIC
    const lang = searchParams.get("lang") || "en"
    const days = searchParams.get("days") ? Number.parseInt(searchParams.get("days") as string) : 7

    // Nếu không có tọa độ, sử dụng Helsinki làm mặc định
    const lat = latParam ? Number.parseFloat(latParam) : FINLAND_CITIES[0].lat
    const lon = lonParam ? Number.parseFloat(lonParam) : FINLAND_CITIES[0].lon

    // Lấy dữ liệu dự báo thời tiết
    const forecastData = await getWeatherForecast(lat, lon, units, lang, days)

    return NextResponse.json({
      success: true,
      data: forecastData,
    })
  } catch (error) {
    console.error("Error in forecast API:", error)
    return NextResponse.json({ success: false, message: "Failed to fetch forecast data" }, { status: 500 })
  }
}

