import { NextResponse } from "next/server"
import { getFinlandWeatherData } from "@/lib/backend/weather-service"
import { UNITS } from "@/lib/backend/config"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)

    // Lấy tham số từ URL
    const units = searchParams.get("units") || UNITS.METRIC
    const lang = searchParams.get("lang") || "en"

    // Lấy dữ liệu thời tiết cho Phần Lan
    const finlandData = await getFinlandWeatherData(units, lang)

    return NextResponse.json({
      success: true,
      data: finlandData,
    })
  } catch (error) {
    console.error("Error in Finland weather API:", error)
    return NextResponse.json({ success: false, message: "Failed to fetch Finland weather data" }, { status: 500 })
  }
}

