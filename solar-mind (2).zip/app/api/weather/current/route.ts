import { NextResponse } from "next/server"
import { getCurrentWeather } from "@/lib/backend/weather-service"
import { UNITS, FINLAND_CITIES } from "@/lib/backend/config"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)

    // Lấy tham số từ URL
    const latParam = searchParams.get("lat")
    const lonParam = searchParams.get("lon")
    const units = searchParams.get("units") || UNITS.METRIC
    const lang = searchParams.get("lang") || "en"

    // Nếu không có tọa độ, sử dụng Helsinki làm mặc định
    const lat = latParam ? Number.parseFloat(latParam) : FINLAND_CITIES[0].lat
    const lon = lonParam ? Number.parseFloat(lonParam) : FINLAND_CITIES[0].lon

    // Lấy dữ liệu thời tiết hiện tại
    const weatherData = await getCurrentWeather(lat, lon, units, lang)

    return NextResponse.json({
      success: true,
      data: weatherData,
    })
  } catch (error) {
    console.error("Error in weather API:", error)
    return NextResponse.json({ success: false, message: "Failed to fetch weather data" }, { status: 500 })
  }
}

