import { NextResponse } from "next/server"

// Simulated database of available time slots
const availableSlots = [
  { date: "2023-12-15", times: ["09:00", "11:00", "14:00", "16:00"] },
  { date: "2023-12-16", times: ["10:00", "13:00", "15:00"] },
  { date: "2023-12-17", times: ["09:00", "12:00", "14:00"] },
  { date: "2023-12-18", times: ["11:00", "13:00", "16:00"] },
  { date: "2023-12-19", times: ["09:00", "10:00", "15:00"] },
]

// Simulated database of scheduled appointments
const scheduledAppointments: Array<{
  id: string
  date: string
  time: string
  type: string
  userId: string
  status: string
  createdAt: string
}> = []

export async function GET(request: Request) {
  // Get date from query params
  const { searchParams } = new URL(request.url)
  const date = searchParams.get("date")

  if (date) {
    // Return available times for the specified date
    const slot = availableSlots.find((slot) => slot.date === date)
    return NextResponse.json({
      success: true,
      availableTimes: slot ? slot.times : [],
    })
  } else {
    // Return all available dates
    return NextResponse.json({
      success: true,
      availableDates: availableSlots.map((slot) => slot.date),
    })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.date || !data.time || !data.type) {
      return NextResponse.json({ success: false, message: "Missing required fields" }, { status: 400 })
    }

    // Check if the slot is available
    const dateSlot = availableSlots.find((slot) => slot.date === data.date)
    if (!dateSlot || !dateSlot.times.includes(data.time)) {
      return NextResponse.json({ success: false, message: "Selected time slot is not available" }, { status: 400 })
    }

    // Create appointment
    const appointment = {
      id: Math.random().toString(36).substring(2, 15),
      date: data.date,
      time: data.time,
      type: data.type,
      userId: data.userId || "anonymous",
      status: "scheduled",
      createdAt: new Date().toISOString(),
    }

    // Save appointment
    scheduledAppointments.push(appointment)

    // Remove the time slot from available slots
    const slotIndex = availableSlots.findIndex((slot) => slot.date === data.date)
    if (slotIndex !== -1) {
      availableSlots[slotIndex].times = availableSlots[slotIndex].times.filter((time) => time !== data.time)
    }

    return NextResponse.json({
      success: true,
      message: "Appointment scheduled successfully",
      appointment,
    })
  } catch (error) {
    console.error("Error scheduling appointment:", error)
    return NextResponse.json({ success: false, message: "Failed to schedule appointment" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ success: false, message: "Appointment ID is required" }, { status: 400 })
    }

    // Find the appointment
    const appointmentIndex = scheduledAppointments.findIndex((apt) => apt.id === id)
    if (appointmentIndex === -1) {
      return NextResponse.json({ success: false, message: "Appointment not found" }, { status: 404 })
    }

    // Get the appointment details
    const appointment = scheduledAppointments[appointmentIndex]

    // Add the time slot back to available slots
    const slotIndex = availableSlots.findIndex((slot) => slot.date === appointment.date)
    if (slotIndex !== -1) {
      availableSlots[slotIndex].times.push(appointment.time)
      // Sort times for consistency
      availableSlots[slotIndex].times.sort()
    }

    // Remove the appointment
    scheduledAppointments.splice(appointmentIndex, 1)

    return NextResponse.json({
      success: true,
      message: "Appointment cancelled successfully",
    })
  } catch (error) {
    console.error("Error cancelling appointment:", error)
    return NextResponse.json({ success: false, message: "Failed to cancel appointment" }, { status: 500 })
  }
}

