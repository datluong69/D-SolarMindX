import { NextResponse } from "next/server"

// Simulated payment processing
const payments: Array<{
  id: string
  amount: number
  currency: string
  status: string
  method: string
  description: string
  createdAt: string
  userId: string
}> = []

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.amount || !data.method || !data.description) {
      return NextResponse.json({ success: false, message: "Missing required payment information" }, { status: 400 })
    }

    // Simulate payment processing
    // In a real application, this would integrate with a payment gateway
    const isSuccessful = Math.random() > 0.1 // 90% success rate for simulation

    if (!isSuccessful) {
      return NextResponse.json(
        { success: false, message: "Payment processing failed. Please try again." },
        { status: 400 },
      )
    }

    // Create payment record
    const payment = {
      id: Math.random().toString(36).substring(2, 15),
      amount: data.amount,
      currency: data.currency || "USD",
      status: "completed",
      method: data.method,
      description: data.description,
      createdAt: new Date().toISOString(),
      userId: data.userId || "anonymous",
    }

    // Save payment record
    payments.push(payment)

    return NextResponse.json({
      success: true,
      message: "Payment processed successfully",
      payment,
    })
  } catch (error) {
    console.error("Error processing payment:", error)
    return NextResponse.json({ success: false, message: "Failed to process payment" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ success: false, message: "User ID is required" }, { status: 400 })
    }

    // Get payment history for the user
    const userPayments = payments.filter((payment) => payment.userId === userId)

    return NextResponse.json({
      success: true,
      payments: userPayments,
    })
  } catch (error) {
    console.error("Error fetching payment history:", error)
    return NextResponse.json({ success: false, message: "Failed to fetch payment history" }, { status: 500 })
  }
}

