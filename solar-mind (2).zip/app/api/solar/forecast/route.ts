import { NextResponse } from "next/server"
import { getSolarForecast } from "@/lib/backend/solar-service"
import { FINLAND_CITIES } from "@/lib/backend/config"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)

    // Lấy tham số từ URL
    const latParam = searchParams.get("lat")
    const lonParam = searchParams.get("lon")
    const capacityParam = searchParams.get("capacity")
    const daysParam = searchParams.get("days")

    // Nếu không có tọa độ, sử dụng Helsinki làm mặc định
    const lat = latParam ? Number.parseFloat(latParam) : FINLAND_CITIES[0].lat
    const lon = lonParam ? Number.parseFloat(lonParam) : FINLAND_CITIES[0].lon
    const capacity = capacityParam ? Number.parseFloat(capacityParam) : undefined
    const days = daysParam ? Number.parseInt(daysParam) : 7

    // Lấy dữ liệu dự báo sản xuất năng lượng mặt trời
    const forecastData = await getSolarForecast(lat, lon, capacity, days)

    return NextResponse.json({
      success: true,
      data: forecastData,
    })
  } catch (error) {
    console.error("Error in solar forecast API:", error)
    return NextResponse.json({ success: false, message: "Failed to fetch solar forecast data" }, { status: 500 })
  }
}

