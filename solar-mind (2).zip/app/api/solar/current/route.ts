import { NextResponse } from "next/server"
import { getCurrentSolarProduction } from "@/lib/backend/solar-service"
import { FINLAND_CITIES } from "@/lib/backend/config"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)

    // Lấy tham số từ URL
    const latParam = searchParams.get("lat")
    const lonParam = searchParams.get("lon")
    const capacityParam = searchParams.get("capacity")

    // Nếu không có tọa độ, sử dụng Helsinki làm mặc định
    const lat = latParam ? Number.parseFloat(latParam) : FINLAND_CITIES[0].lat
    const lon = lonParam ? Number.parseFloat(lonParam) : FINLAND_CITIES[0].lon
    const capacity = capacityParam ? Number.parseFloat(capacityParam) : undefined

    // Lấy dữ liệu sản xuất năng lượng mặt trời hiện tại
    const solarData = await getCurrentSolarProduction(lat, lon, capacity)

    return NextResponse.json({
      success: true,
      data: solarData,
    })
  } catch (error) {
    console.error("Error in solar production API:", error)
    return NextResponse.json({ success: false, message: "Failed to fetch solar production data" }, { status: 500 })
  }
}

