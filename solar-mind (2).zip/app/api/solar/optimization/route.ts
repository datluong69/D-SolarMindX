import { NextResponse } from "next/server"
import { getSolarOptimization } from "@/lib/backend/solar-service"
import { FINLAND_CITIES } from "@/lib/backend/config"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)

    // Lấy tham số từ URL
    const latParam = searchParams.get("lat")
    const lonParam = searchParams.get("lon")

    // Nếu không có tọa độ, sử dụng Helsinki làm mặc định
    const lat = latParam ? Number.parseFloat(latParam) : FINLAND_CITIES[0].lat
    const lon = lonParam ? Number.parseFloat(lonParam) : FINLAND_CITIES[0].lon

    // Lấy dữ liệu tối ưu hóa hệ thống năng lượng mặt trời
    const optimizationData = await getSolarOptimization(lat, lon)

    return NextResponse.json({
      success: true,
      data: optimizationData,
    })
  } catch (error) {
    console.error("Error in solar optimization API:", error)
    return NextResponse.json({ success: false, message: "Failed to fetch solar optimization data" }, { status: 500 })
  }
}

