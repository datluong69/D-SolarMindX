import { NextResponse } from "next/server"
import { analyzeSystemPerformance } from "@/lib/ai-service"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const timeframe = (searchParams.get("timeframe") as "day" | "week" | "month") || "week"
    const language = searchParams.get("language") || "en"

    const analysis = await analyzeSystemPerformance(timeframe, language)

    return NextResponse.json({
      success: true,
      data: analysis,
    })
  } catch (error) {
    console.error("Error in AI analysis API:", error)
    return NextResponse.json({ success: false, message: "Failed to analyze system performance" }, { status: 500 })
  }
}

