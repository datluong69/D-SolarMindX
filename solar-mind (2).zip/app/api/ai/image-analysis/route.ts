import { NextResponse } from "next/server"
import { analyzePanelImage } from "@/lib/ai-service"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    if (!data.image) {
      return NextResponse.json({ success: false, message: "Image data is required" }, { status: 400 })
    }

    const language = data.language || "en"
    const issues = await analyzePanelImage(data.image, language)

    return NextResponse.json({
      success: true,
      data: issues,
    })
  } catch (error) {
    console.error("Error in AI image analysis API:", error)
    return NextResponse.json({ success: false, message: "Failed to analyze panel image" }, { status: 500 })
  }
}

