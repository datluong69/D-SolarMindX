import { NextResponse } from "next/server"
import { generateOptimizationPlan } from "@/lib/ai-service"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const language = searchParams.get("language") || "en"

    const plan = await generateOptimizationPlan(language)

    return NextResponse.json({
      success: true,
      data: plan,
    })
  } catch (error) {
    console.error("Error in AI optimization API:", error)
    return NextResponse.json({ success: false, message: "Failed to generate optimization plan" }, { status: 500 })
  }
}

