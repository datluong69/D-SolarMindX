import { WEATHER_API_URL, CACHE_EXPIRY, UNITS, FINLAND_CITIES } from "./config"
import cacheManager from "./cache"

// Kiểm tra xem chúng ta có đang chạy trên server hay không
const isServer = typeof window === "undefined"

// Lấy API key từ biến môi trường
const getApiKey = () => {
  // Trên server, sử dụng biến môi trường server
  if (isServer) {
    return process.env.OPENWEATHER_API_KEY
  }

  // Trên client, sử dụng biến môi trường public
  return process.env.NEXT_PUBLIC_API_URL ? "simulated_key" : null
}

// Kiểm tra xem API key có tồn tại không
const validateApiKey = () => {
  const apiKey = getApiKey()
  if (!apiKey) {
    throw new Error("OpenWeatherMap API key is missing. Please set the OPENWEATHER_API_KEY environment variable.")
  }
  return apiKey
}

// Định dạng dữ liệu thời tiết hiện tại
export type CurrentWeatherData = {
  location: {
    name: string
    country: string
    lat: number
    lon: number
  }
  current: {
    temp: number
    feels_like: number
    humidity: number
    pressure: number
    wind_speed: number
    wind_deg: number
    weather: {
      id: number
      main: string
      description: string
      icon: string
    }
    clouds: number
    visibility: number
    uvi: number
    dt: number // timestamp
  }
  solar?: {
    radiation: number // W/m²
    angle: number // Góc mặt trời
  }
  air_quality?: {
    aqi: number // Chỉ số chất lượng không khí
    pm2_5: number // Nồng độ PM2.5
    pm10: number // Nồng độ PM10
  }
}

// Định dạng dữ liệu dự báo thời tiết
export type ForecastData = {
  location: {
    name: string
    country: string
    lat: number
    lon: number
  }
  daily: Array<{
    dt: number // timestamp
    temp: {
      day: number
      min: number
      max: number
    }
    humidity: number
    wind_speed: number
    weather: {
      id: number
      main: string
      description: string
      icon: string
    }
    clouds: number
    pop: number // Xác suất mưa
    uvi: number
    sunrise: number
    sunset: number
    solar_radiation?: number // W/m²
  }>
}

// Lấy dữ liệu thời tiết hiện tại cho một vị trí
export async function getCurrentWeather(
  lat: number,
  lon: number,
  units: string = UNITS.METRIC,
  lang = "en",
): Promise<CurrentWeatherData> {
  try {
    // Tạo khóa bộ nhớ đệm
    const cacheKey = `weather_current_${lat}_${lon}_${units}_${lang}`

    // Kiểm tra bộ nhớ đệm
    const cachedData = cacheManager.get<CurrentWeatherData>(cacheKey)
    if (cachedData) {
      return cachedData
    }

    // Nếu chúng ta đang sử dụng API URL mô phỏng, trả về dữ liệu mô phỏng
    if (process.env.NEXT_PUBLIC_API_URL) {
      const simulatedData = generateSimulatedWeatherData(lat, lon)
      cacheManager.set(cacheKey, simulatedData, CACHE_EXPIRY.WEATHER)
      return simulatedData
    }

    // Lấy API key
    const apiKey = validateApiKey()

    // Gọi API OpenWeatherMap
    const response = await fetch(
      `${WEATHER_API_URL}/weather?lat=${lat}&lon=${lon}&units=${units}&lang=${lang}&appid=${apiKey}`,
    )

    if (!response.ok) {
      throw new Error(`Weather API error: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()

    // Định dạng dữ liệu phản hồi
    const formattedData: CurrentWeatherData = {
      location: {
        name: data.name,
        country: data.sys.country,
        lat: data.coord.lat,
        lon: data.coord.lon,
      },
      current: {
        temp: data.main.temp,
        feels_like: data.main.feels_like,
        humidity: data.main.humidity,
        pressure: data.main.pressure,
        wind_speed: data.wind.speed,
        wind_deg: data.wind.deg,
        weather: data.weather[0],
        clouds: data.clouds.all,
        visibility: data.visibility,
        uvi: 0, // OpenWeatherMap không cung cấp UV trong API thời tiết cơ bản
        dt: data.dt,
      },
    }

    // Lưu vào bộ nhớ đệm
    cacheManager.set(cacheKey, formattedData, CACHE_EXPIRY.WEATHER)

    return formattedData
  } catch (error) {
    console.error("Error fetching current weather:", error)
    throw error
  }
}

// Lấy dữ liệu dự báo thời tiết cho một vị trí
export async function getWeatherForecast(
  lat: number,
  lon: number,
  units: string = UNITS.METRIC,
  lang = "en",
  days = 7,
): Promise<ForecastData> {
  try {
    // Tạo khóa bộ nhớ đệm
    const cacheKey = `weather_forecast_${lat}_${lon}_${units}_${lang}_${days}`

    // Kiểm tra bộ nhớ đệm
    const cachedData = cacheManager.get<ForecastData>(cacheKey)
    if (cachedData) {
      return cachedData
    }

    // Nếu chúng ta đang sử dụng API URL mô phỏng, trả về dữ liệu mô phỏng
    if (process.env.NEXT_PUBLIC_API_URL) {
      const simulatedData = generateSimulatedForecastData(lat, lon, days)
      cacheManager.set(cacheKey, simulatedData, CACHE_EXPIRY.FORECAST)
      return simulatedData
    }

    // Lấy API key
    const apiKey = validateApiKey()

    // Gọi API OpenWeatherMap
    const response = await fetch(
      `${WEATHER_API_URL}/onecall?lat=${lat}&lon=${lon}&units=${units}&lang=${lang}&exclude=current,minutely,hourly,alerts&appid=${apiKey}`,
    )

    if (!response.ok) {
      throw new Error(`Weather API error: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()

    // Lấy tên thành phố từ tọa độ
    const cityResponse = await fetch(`${WEATHER_API_URL}/weather?lat=${lat}&lon=${lon}&appid=${apiKey}`)

    const cityData = await cityResponse.json()

    // Định dạng dữ liệu phản hồi
    const formattedData: ForecastData = {
      location: {
        name: cityData.name,
        country: cityData.sys.country,
        lat: data.lat,
        lon: data.lon,
      },
      daily: data.daily.slice(0, days).map((day: any) => ({
        dt: day.dt,
        temp: {
          day: day.temp.day,
          min: day.temp.min,
          max: day.temp.max,
        },
        humidity: day.humidity,
        wind_speed: day.wind_speed,
        weather: day.weather[0],
        clouds: day.clouds,
        pop: day.pop,
        uvi: day.uvi,
        sunrise: day.sunrise,
        sunset: day.sunset,
      })),
    }

    // Lưu vào bộ nhớ đệm
    cacheManager.set(cacheKey, formattedData, CACHE_EXPIRY.FORECAST)

    return formattedData
  } catch (error) {
    console.error("Error fetching weather forecast:", error)
    throw error
  }
}

// Lấy dữ liệu bức xạ mặt trời cho một vị trí
export async function getSolarRadiation(lat: number, lon: number): Promise<number> {
  try {
    // Tạo khóa bộ nhớ đệm
    const cacheKey = `solar_radiation_${lat}_${lon}`

    // Kiểm tra bộ nhớ đệm
    const cachedData = cacheManager.get<number>(cacheKey)
    if (cachedData !== null) {
      return cachedData
    }

    // Nếu chúng ta đang sử dụng API URL mô phỏng, trả về dữ liệu mô phỏng
    if (process.env.NEXT_PUBLIC_API_URL) {
      // Mô phỏng dữ liệu bức xạ mặt trời dựa trên vĩ độ và thời gian trong ngày
      const now = new Date()
      const hour = now.getHours()

      // Bức xạ cao hơn vào giữa ngày, thấp hơn vào sáng sớm và chiều tối
      let baseRadiation = 0
      if (hour >= 6 && hour <= 18) {
        // Đỉnh vào trưa (giờ 12)
        baseRadiation = 1000 * Math.sin(((hour - 6) * Math.PI) / 12)
      }

      // Điều chỉnh theo vĩ độ (bức xạ thấp hơn ở vĩ độ cao hơn)
      const latitudeFactor = Math.max(0.5, 1 - Math.abs(lat) / 90)
      const radiation = baseRadiation * latitudeFactor

      // Thêm một chút ngẫu nhiên
      const finalRadiation = Math.max(0, radiation * (0.8 + Math.random() * 0.4))

      cacheManager.set(cacheKey, finalRadiation, CACHE_EXPIRY.SOLAR_DATA)
      return finalRadiation
    }

    // Lấy API key
    const apiKey = validateApiKey()

    // Gọi API OpenWeatherMap
    // Lưu ý: OpenWeatherMap không có API bức xạ mặt trời trực tiếp, đây là mô phỏng
    // Trong thực tế, bạn có thể cần sử dụng một API chuyên dụng cho dữ liệu bức xạ mặt trời

    // Sử dụng API thời tiết hiện tại để ước tính bức xạ mặt trời
    const response = await fetch(`${WEATHER_API_URL}/weather?lat=${lat}&lon=${lon}&appid=${apiKey}`)

    if (!response.ok) {
      throw new Error(`Weather API error: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()

    // Ước tính bức xạ mặt trời dựa trên độ che phủ của mây
    // Công thức đơn giản: 1000 W/m² * (1 - cloudiness/100) * daytime_factor
    const cloudiness = data.clouds.all / 100
    const dt = new Date(data.dt * 1000)
    const hour = dt.getHours()

    let daytimeFactor = 0
    if (hour >= 6 && hour <= 18) {
      // Đỉnh vào trưa (giờ 12)
      daytimeFactor = Math.sin(((hour - 6) * Math.PI) / 12)
    }

    const radiation = 1000 * (1 - cloudiness) * daytimeFactor

    // Lưu vào bộ nhớ đệm
    cacheManager.set(cacheKey, radiation, CACHE_EXPIRY.SOLAR_DATA)

    return radiation
  } catch (error) {
    console.error("Error fetching solar radiation:", error)
    throw error
  }
}

// Lấy dữ liệu chất lượng không khí cho một vị trí
export async function getAirQuality(lat: number, lon: number): Promise<{ aqi: number; pm2_5: number; pm10: number }> {
  try {
    // Tạo khóa bộ nhớ đệm
    const cacheKey = `air_quality_${lat}_${lon}`

    // Kiểm tra bộ nhớ đệm
    const cachedData = cacheManager.get<{ aqi: number; pm2_5: number; pm10: number }>(cacheKey)
    if (cachedData) {
      return cachedData
    }

    // Nếu chúng ta đang sử dụng API URL mô phỏng, trả về dữ liệu mô phỏng
    if (process.env.NEXT_PUBLIC_API_URL) {
      // Mô phỏng dữ liệu chất lượng không khí
      const aqi = Math.floor(Math.random() * 5) + 1 // 1-5, 1 là tốt nhất
      const pm2_5 = Math.random() * 25 // 0-25 µg/m³
      const pm10 = Math.random() * 50 // 0-50 µg/m³

      const data = { aqi, pm2_5, pm10 }
      cacheManager.set(cacheKey, data, CACHE_EXPIRY.WEATHER)
      return data
    }

    // Lấy API key
    const apiKey = validateApiKey()

    // Gọi API OpenWeatherMap
    const response = await fetch(`${WEATHER_API_URL}/air_pollution?lat=${lat}&lon=${lon}&appid=${apiKey}`)

    if (!response.ok) {
      throw new Error(`Air quality API error: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()

    // Định dạng dữ liệu phản hồi
    const formattedData = {
      aqi: data.list[0].main.aqi,
      pm2_5: data.list[0].components.pm2_5,
      pm10: data.list[0].components.pm10,
    }

    // Lưu vào bộ nhớ đệm
    cacheManager.set(cacheKey, formattedData, CACHE_EXPIRY.WEATHER)

    return formattedData
  } catch (error) {
    console.error("Error fetching air quality:", error)
    throw error
  }
}

// Lấy tất cả dữ liệu thời tiết cho một vị trí
export async function getAllWeatherData(
  lat: number,
  lon: number,
  units: string = UNITS.METRIC,
  lang = "en",
): Promise<{
  current: CurrentWeatherData
  forecast: ForecastData
}> {
  try {
    // Lấy dữ liệu thời tiết hiện tại và dự báo song song
    const [currentData, forecastData, solarRadiation, airQuality] = await Promise.all([
      getCurrentWeather(lat, lon, units, lang),
      getWeatherForecast(lat, lon, units, lang),
      getSolarRadiation(lat, lon),
      getAirQuality(lat, lon),
    ])

    // Thêm dữ liệu bức xạ mặt trời vào dữ liệu hiện tại
    currentData.solar = {
      radiation: solarRadiation,
      angle: calculateSolarAngle(lat, lon),
    }

    // Thêm dữ liệu chất lượng không khí
    currentData.air_quality = airQuality

    // Thêm dữ liệu bức xạ mặt trời vào dự báo
    forecastData.daily.forEach((day, index) => {
      // Mô phỏng bức xạ mặt trời cho các ngày trong tương lai
      day.solar_radiation = solarRadiation * (0.8 + Math.random() * 0.4)
    })

    return {
      current: currentData,
      forecast: forecastData,
    }
  } catch (error) {
    console.error("Error fetching all weather data:", error)
    throw error
  }
}

// Lấy dữ liệu thời tiết cho tất cả các thành phố ở Phần Lan
export async function getFinlandWeatherData(
  units: string = UNITS.METRIC,
  lang = "en",
): Promise<{
  cities: Array<{
    name: string
    current: CurrentWeatherData
  }>
}> {
  try {
    // Tạo khóa bộ nhớ đệm
    const cacheKey = `finland_weather_${units}_${lang}`

    // Kiểm tra bộ nhớ đệm
    const cachedData = cacheManager.get<{
      cities: Array<{
        name: string
        current: CurrentWeatherData
      }>
    }>(cacheKey)

    if (cachedData) {
      return cachedData
    }

    // Lấy dữ liệu thời tiết cho mỗi thành phố
    const citiesData = await Promise.all(
      FINLAND_CITIES.map(async (city) => {
        const weatherData = await getCurrentWeather(city.lat, city.lon, units, lang)
        return {
          name: city.name,
          current: weatherData,
        }
      }),
    )

    const result = {
      cities: citiesData,
    }

    // Lưu vào bộ nhớ đệm
    cacheManager.set(cacheKey, result, CACHE_EXPIRY.WEATHER)

    return result
  } catch (error) {
    console.error("Error fetching Finland weather data:", error)
    throw error
  }
}

// Tính góc mặt trời dựa trên vĩ độ, kinh độ và thời gian
function calculateSolarAngle(lat: number, lon: number): number {
  const now = new Date()
  const dayOfYear = Math.floor((now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000)
  const declination = 23.45 * Math.sin((360 / 365) * (dayOfYear - 81) * (Math.PI / 180))
  const hourAngle = 15 * (now.getUTCHours() + now.getUTCMinutes() / 60 - 12)

  const altitude =
    Math.asin(
      Math.sin(lat * (Math.PI / 180)) * Math.sin(declination * (Math.PI / 180)) +
        Math.cos(lat * (Math.PI / 180)) *
          Math.cos(declination * (Math.PI / 180)) *
          Math.cos(hourAngle * (Math.PI / 180)),
    ) *
    (180 / Math.PI)

  return altitude
}

// Tạo dữ liệu thời tiết mô phỏng cho chế độ phát triển
function generateSimulatedWeatherData(lat: number, lon: number): CurrentWeatherData {
  const now = new Date()
  const hour = now.getHours()

  // Nhiệt độ thay đổi theo giờ trong ngày
  const baseTemp = 15 // Nhiệt độ cơ sở cho Phần Lan
  const tempVariation = Math.sin(((hour - 6) * Math.PI) / 12) * 10 // Biến thiên -10 đến +10
  const temp = baseTemp + tempVariation

  // Độ ẩm cao hơn vào buổi sáng và buổi tối
  const humidity = 60 + Math.sin(((hour + 6) * Math.PI) / 12) * 20

  // Tốc độ gió tăng vào buổi chiều
  const windSpeed = 3 + Math.sin(((hour - 3) * Math.PI) / 12) * 2

  // Độ che phủ của mây ngẫu nhiên
  const clouds = Math.floor(Math.random() * 100)

  // Xác định điều kiện thời tiết dựa trên độ che phủ của mây
  let weather
  if (clouds < 20) {
    weather = { id: 800, main: "Clear", description: "clear sky", icon: "01d" }
  } else if (clouds < 50) {
    weather = { id: 801, main: "Clouds", description: "few clouds", icon: "02d" }
  } else if (clouds < 80) {
    weather = { id: 802, main: "Clouds", description: "scattered clouds", icon: "03d" }
  } else {
    weather = { id: 804, main: "Clouds", description: "overcast clouds", icon: "04d" }
  }

  // Tìm thành phố gần nhất
  let cityName = "Helsinki"
  let minDistance = Number.MAX_VALUE

  for (const city of FINLAND_CITIES) {
    const distance = Math.sqrt(Math.pow(city.lat - lat, 2) + Math.pow(city.lon - lon, 2))
    if (distance < minDistance) {
      minDistance = distance
      cityName = city.name
    }
  }

  return {
    location: {
      name: cityName,
      country: "FI",
      lat,
      lon,
    },
    current: {
      temp,
      feels_like: temp - 2,
      humidity,
      pressure: 1013,
      wind_speed: windSpeed,
      wind_deg: Math.floor(Math.random() * 360),
      weather,
      clouds,
      visibility: 10000,
      uvi: Math.floor(Math.random() * 8),
      dt: Math.floor(Date.now() / 1000),
    },
    solar: {
      radiation: getSolarRadiationForHour(hour, clouds),
      angle: calculateSolarAngle(lat, lon),
    },
    air_quality: {
      aqi: Math.floor(Math.random() * 5) + 1,
      pm2_5: Math.random() * 25, // 0-25 µg/m³
      pm10: Math.random() * 50, // 0-50 µg/m³
    },
  }
}

// Tạo dữ liệu dự báo thời tiết mô phỏng
function generateSimulatedForecastData(lat: number, lon: number, days: number): ForecastData {
  // Tìm thành phố gần nhất
  let cityName = "Helsinki"
  let minDistance = Number.MAX_VALUE

  for (const city of FINLAND_CITIES) {
    const distance = Math.sqrt(Math.pow(city.lat - lat, 2) + Math.pow(city.lon - lon, 2))
    if (distance < minDistance) {
      minDistance = distance
      cityName = city.name
    }
  }

  const now = new Date()
  const dailyData = []

  for (let i = 0; i < days; i++) {
    const date = new Date(now)
    date.setDate(date.getDate() + i)

    // Nhiệt độ cơ sở với biến thiên theo ngày
    const baseTemp = 15 + Math.sin((i * Math.PI) / 7) * 5

    // Độ che phủ của mây ngẫu nhiên
    const clouds = Math.floor(Math.random() * 100)

    // Xác định điều kiện thời tiết dựa trên độ che phủ của mây
    let weather
    if (clouds < 20) {
      weather = { id: 800, main: "Clear", description: "clear sky", icon: "01d" }
    } else if (clouds < 50) {
      weather = { id: 801, main: "Clouds", description: "few clouds", icon: "02d" }
    } else if (clouds < 80) {
      weather = { id: 802, main: "Clouds", description: "scattered clouds", icon: "03d" }
    } else {
      weather = { id: 804, main: "Clouds", description: "overcast clouds", icon: "04d" }
    }

    dailyData.push({
      dt: Math.floor(date.getTime() / 1000),
      temp: {
        day: baseTemp,
        min: baseTemp - 5,
        max: baseTemp + 5,
      },
      humidity: 60 + Math.floor(Math.random() * 30),
      wind_speed: 3 + Math.random() * 5,
      weather,
      clouds,
      pop: Math.random(), // Xác suất mưa
      uvi: Math.floor(Math.random() * 8),
      sunrise: Math.floor(date.setHours(6, 0, 0, 0) / 1000),
      sunset: Math.floor(date.setHours(21, 0, 0, 0) / 1000),
      solar_radiation: 600 + Math.random() * 400, // W/m²
    })
  }

  return {
    location: {
      name: cityName,
      country: "FI",
      lat,
      lon,
    },
    daily: dailyData,
  }
}

// Tính bức xạ mặt trời dựa trên giờ và độ che phủ của mây
function getSolarRadiationForHour(hour: number, clouds: number): number {
  // Không có bức xạ vào ban đêm
  if (hour < 6 || hour > 18) {
    return 0
  }

  // Bức xạ cao nhất vào trưa
  const maxRadiation = 1000 // W/m²
  const timeOfDay = Math.sin(((hour - 6) * Math.PI) / 12)

  // Giảm bức xạ dựa trên độ che phủ của mây
  const cloudFactor = 1 - (clouds / 100) * 0.8

  return maxRadiation * timeOfDay * cloudFactor
}

