// Cấu hình backend

// API URLs
export const WEATHER_API_URL = "https://api.openweathermap.org/data/2.5"
export const SOLAR_RADIATION_API_URL = "https://api.openweathermap.org/data/2.5/solar_radiation"

// Các thành phố ở Phần Lan
export const FINLAND_CITIES = [
  { name: "Helsinki", lat: 60.1699, lon: 24.9384 },
  { name: "Espoo", lat: 60.2055, lon: 24.6559 },
  { name: "Tampere", lat: 61.4978, lon: 23.761 },
  { name: "Vantaa", lat: 60.2934, lon: 25.0378 },
  { name: "Oulu", lat: 65.0126, lon: 25.4715 },
  { name: "Turku", lat: 60.4518, lon: 22.2666 },
  { name: "Jyväskylä", lat: 62.2426, lon: 25.7473 },
  { name: "Lahti", lat: 60.9827, lon: 25.6612 },
  { name: "Kuopio", lat: 62.8924, lon: 27.6772 },
  { name: "Rovaniemi", lat: 66.5039, lon: 25.7294 },
]

// Thời gian hết hạn bộ nhớ đệm (ms)
export const CACHE_EXPIRY = {
  WEATHER: 30 * 60 * 1000, // 30 phút
  FORECAST: 60 * 60 * 1000, // 1 giờ
  SOLAR_DATA: 60 * 60 * 1000, // 1 giờ
}

// Đơn vị đo
export const UNITS = {
  METRIC: "metric", // Celsius, m/s
  IMPERIAL: "imperial", // Fahrenheit, mph
}

// Ngôn ngữ
export const LANGUAGES = {
  ENGLISH: "en",
  FINNISH: "fi",
  SWEDISH: "sv", // Tiếng Thụy Điển (ngôn ngữ chính thức thứ hai của Phần Lan)
  VIETNAMESE: "vi",
  CHINESE: "zh_cn",
  FRENCH: "fr",
  SPANISH: "es",
}

// Cấu hình bộ nhớ đệm
export const CACHE_CONFIG = {
  enabled: true,
  staleWhileRevalidate: true,
}

