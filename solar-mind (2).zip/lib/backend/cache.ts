// Hệ thống bộ nhớ đệm đơn giản cho backend

type CacheItem<T> = {
  data: T
  timestamp: number
  expiry: number
}

class CacheManager {
  private cache: Map<string, CacheItem<any>> = new Map()

  // Lấy dữ liệu từ bộ nhớ đệm
  get<T>(key: string): T | null {
    const item = this.cache.get(key)

    if (!item) {
      return null
    }

    // Kiểm tra xem dữ liệu có hết hạn không
    if (Date.now() - item.timestamp > item.expiry) {
      // Dữ liệu đã hết hạn
      this.cache.delete(key)
      return null
    }

    return item.data as T
  }

  // Lưu dữ liệu vào bộ nhớ đệm
  set<T>(key: string, data: T, expiry: number): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      expiry,
    })
  }

  // Xóa một mục khỏi bộ nhớ đệm
  delete(key: string): void {
    this.cache.delete(key)
  }

  // Xóa tất cả các mục đã hết hạn
  cleanup(): void {
    const now = Date.now()
    for (const [key, item] of this.cache.entries()) {
      if (now - item.timestamp > item.expiry) {
        this.cache.delete(key)
      }
    }
  }

  // Xóa toàn bộ bộ nhớ đệm
  clear(): void {
    this.cache.clear()
  }

  // Lấy kích thước bộ nhớ đệm
  size(): number {
    return this.cache.size
  }
}

// Tạo một phiên bản duy nhất của bộ nhớ đệm
const cacheInstance = new CacheManager()

// Thiết lập dọn dẹp tự động mỗi giờ
if (typeof window !== "undefined") {
  setInterval(
    () => {
      cacheInstance.cleanup()
    },
    60 * 60 * 1000,
  )
}

export default cacheInstance

