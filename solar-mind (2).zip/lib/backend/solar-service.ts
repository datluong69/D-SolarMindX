import { getSolarRadiation } from "./weather-service"
import { CACHE_EXPIRY } from "./config"
import cacheManager from "./cache"

// Định dạng dữ liệu sản xuất năng lượng mặt trời
export type SolarProductionData = {
  current: {
    power: number // kW
    efficiency: number // %
    temperature: number // °C
  }
  daily: {
    total: number // kWh
    peak: number // kW
    hours: number // Số giờ sản xuất hiệu quả
  }
  monthly: {
    total: number // kWh
    average: number // kWh/ngày
    savings: number // Tiết kiệm tiền
  }
  system: {
    capacity: number // kW
    panels: number // Số lượng tấm pin
    age: number // Tuổi hệ thống (năm)
    lastMaintenance: string // Ngày bảo trì cuối cùng
    health: number // % sức khỏe hệ thống
  }
}

// Định dạng dữ liệu dự báo sản xuất
export type SolarForecastData = {
  hourly: Array<{
    hour: number
    power: number // kW
    radiation: number // W/m²
  }>
  daily: Array<{
    date: string
    total: number // kWh
    peak: number // kW
    weather: string
  }>
  monthly: {
    total: number // kWh
    average: number // kWh/ngày
    comparison: number // % so với tháng trước
  }
}

// Định dạng dữ liệu tối ưu hóa
export type OptimizationData = {
  current: {
    tilt: number // Góc nghiêng hiện tại
    azimuth: number // Góc phương vị hiện tại
    efficiency: number // % hiệu suất hiện tại
  }
  optimal: {
    tilt: number // Góc nghiêng tối ưu
    azimuth: number // Góc phương vị tối ưu
    efficiency: number // % hiệu suất dự kiến
    gain: number // % cải thiện
  }
  recommendations: Array<{
    type: string
    description: string
    impact: number // % cải thiện
    difficulty: string
  }>
}

// Cấu hình hệ thống mặt trời mặc định
const DEFAULT_SYSTEM = {
  capacity: 5, // kW
  panels: 20, // Số lượng tấm pin
  efficiency: 0.85, // 85% hiệu suất
  age: 2, // 2 năm tuổi
  lastMaintenance: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // 90 ngày trước
  tilt: 35, // Góc nghiêng
  azimuth: 180, // Hướng nam
}

// Lấy dữ liệu sản xuất năng lượng mặt trời hiện tại
export async function getCurrentSolarProduction(
  lat: number,
  lon: number,
  systemCapacity: number = DEFAULT_SYSTEM.capacity,
): Promise<SolarProductionData> {
  try {
    // Tạo khóa bộ nhớ đệm
    const cacheKey = `solar_production_${lat}_${lon}_${systemCapacity}`

    // Kiểm tra bộ nhớ đệm
    const cachedData = cacheManager.get<SolarProductionData>(cacheKey)
    if (cachedData) {
      return cachedData
    }

    // Lấy dữ liệu bức xạ mặt trời
    const solarRadiation = await getSolarRadiation(lat, lon)

    // Tính toán sản lượng điện hiện tại
    const now = new Date()
    const hour = now.getHours()

    // Hiệu suất thay đổi theo nhiệt độ và tuổi hệ thống
    const baseEfficiency = DEFAULT_SYSTEM.efficiency
    const ageDerating = Math.min(0.1, DEFAULT_SYSTEM.age * 0.01) // Giảm 1% mỗi năm, tối đa 10%
    const temperatureDerating = hour > 10 && hour < 16 ? 0.05 : 0 // Giảm 5% vào giờ nóng nhất
    const efficiency = baseEfficiency - ageDerating - temperatureDerating

    // Tính công suất hiện tại (kW)
    const currentPower = (solarRadiation / 1000) * systemCapacity * efficiency

    // Tính tổng sản lượng hàng ngày (kWh)
    let dailyTotal = 0
    for (let h = 0; h < 24; h++) {
      if (h >= 6 && h <= 18) {
        // Giờ có ánh sáng mặt trời
        const hourlyRadiation = getSolarRadiationForHour(h, 30) // Giả sử độ che phủ của mây trung bình là 30%
        const hourlyPower = (hourlyRadiation / 1000) * systemCapacity * efficiency
        dailyTotal += hourlyPower
      }
    }

    // Tính tổng sản lượng hàng tháng (kWh)
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate()
    const monthlyTotal = dailyTotal * daysInMonth

    // Tính tiết kiệm tiền (giả sử 0.12 EUR/kWh)
    const electricityRate = 0.12
    const monthlySavings = monthlyTotal * electricityRate

    // Tính sức khỏe hệ thống
    const daysSinceLastMaintenance = Math.floor(
      (now.getTime() - new Date(DEFAULT_SYSTEM.lastMaintenance).getTime()) / (24 * 60 * 60 * 1000),
    )
    const maintenanceDerating = Math.min(0.1, daysSinceLastMaintenance / 365) // Giảm tối đa 10% nếu không bảo trì trong 1 năm
    const systemHealth = 100 - ageDerating * 100 - maintenanceDerating * 100

    // Tạo dữ liệu phản hồi
    const data: SolarProductionData = {
      current: {
        power: Number.parseFloat(currentPower.toFixed(2)),
        efficiency: Number.parseFloat((efficiency * 100).toFixed(1)),
        temperature: 25 + (hour > 10 && hour < 16 ? 10 : 0), // Giả sử nhiệt độ tấm pin
      },
      daily: {
        total: Number.parseFloat(dailyTotal.toFixed(2)),
        peak: Number.parseFloat((systemCapacity * efficiency).toFixed(2)),
        hours: 12, // Giả sử 12 giờ ánh sáng mặt trời
      },
      monthly: {
        total: Number.parseFloat(monthlyTotal.toFixed(2)),
        average: Number.parseFloat((monthlyTotal / daysInMonth).toFixed(2)),
        savings: Number.parseFloat(monthlySavings.toFixed(2)),
      },
      system: {
        capacity: systemCapacity,
        panels: DEFAULT_SYSTEM.panels,
        age: DEFAULT_SYSTEM.age,
        lastMaintenance: DEFAULT_SYSTEM.lastMaintenance,
        health: Number.parseFloat(systemHealth.toFixed(1)),
      },
    }

    // Lưu vào bộ nhớ đệm
    cacheManager.set(cacheKey, data, CACHE_EXPIRY.SOLAR_DATA)

    return data
  } catch (error) {
    console.error("Error calculating solar production:", error)
    throw error
  }
}

// Lấy dữ liệu dự báo sản xuất năng lượng mặt trời
export async function getSolarForecast(
  lat: number,
  lon: number,
  systemCapacity: number = DEFAULT_SYSTEM.capacity,
  days = 7,
): Promise<SolarForecastData> {
  try {
    // Tạo khóa bộ nhớ đệm
    const cacheKey = `solar_forecast_${lat}_${lon}_${systemCapacity}_${days}`

    // Kiểm tra bộ nhớ đệm
    const cachedData = cacheManager.get<SolarForecastData>(cacheKey)
    if (cachedData) {
      return cachedData
    }

    const now = new Date()
    const hourlyData = []
    const dailyData = []

    // Tạo dữ liệu dự báo theo giờ cho 24 giờ tới
    for (let i = 0; i < 24; i++) {
      const forecastHour = (now.getHours() + i) % 24
      const forecastDate = new Date(now)
      forecastDate.setHours(forecastHour)

      // Tính bức xạ mặt trời cho giờ này
      const cloudiness = Math.random() * 100 // Độ che phủ của mây ngẫu nhiên
      const radiation = getSolarRadiationForHour(forecastHour, cloudiness)

      // Tính công suất
      const baseEfficiency = DEFAULT_SYSTEM.efficiency
      const power = (radiation / 1000) * systemCapacity * baseEfficiency

      hourlyData.push({
        hour: forecastHour,
        power: Number.parseFloat(power.toFixed(2)),
        radiation: Number.parseFloat(radiation.toFixed(2)),
      })
    }

    // Tạo dữ liệu dự báo theo ngày
    let monthlyTotal = 0

    for (let i = 0; i < days; i++) {
      const forecastDate = new Date(now)
      forecastDate.setDate(forecastDate.getDate() + i)

      // Tính tổng sản lượng hàng ngày
      let dailyTotal = 0
      let peakPower = 0

      // Mô phỏng thời tiết
      const weatherTypes = ["sunny", "partly cloudy", "cloudy", "rainy"]
      const weatherWeights = [0.4, 0.3, 0.2, 0.1] // Trọng số cho mỗi loại thời tiết

      // Chọn loại thời tiết dựa trên trọng số
      let weatherIndex = 0
      const randomValue = Math.random()
      let cumulativeWeight = 0

      for (let j = 0; j < weatherWeights.length; j++) {
        cumulativeWeight += weatherWeights[j]
        if (randomValue <= cumulativeWeight) {
          weatherIndex = j
          break
        }
      }

      const weather = weatherTypes[weatherIndex]

      // Điều chỉnh sản lượng dựa trên thời tiết
      const weatherFactor = [1, 0.8, 0.5, 0.2][weatherIndex]

      for (let h = 0; h < 24; h++) {
        if (h >= 6 && h <= 18) {
          // Giờ có ánh sáng mặt trời
          const hourlyRadiation = getSolarRadiationForHour(h, 30) * weatherFactor
          const hourlyPower = (hourlyRadiation / 1000) * systemCapacity * DEFAULT_SYSTEM.efficiency

          dailyTotal += hourlyPower
          peakPower = Math.max(peakPower, hourlyPower)
        }
      }

      dailyData.push({
        date: forecastDate.toISOString().split("T")[0],
        total: Number.parseFloat(dailyTotal.toFixed(2)),
        peak: Number.parseFloat(peakPower.toFixed(2)),
        weather,
      })

      monthlyTotal += dailyTotal
    }

    // Tính trung bình hàng tháng
    const monthlyAverage = monthlyTotal / days

    // Tính so sánh với tháng trước (giả sử tăng/giảm ngẫu nhiên từ -10% đến +10%)
    const monthlyComparison = Math.random() * 20 - 10

    // Tạo dữ liệu phản hồi
    const data: SolarForecastData = {
      hourly: hourlyData,
      daily: dailyData,
      monthly: {
        total: Number.parseFloat(((monthlyTotal * 30) / days).toFixed(2)),
        average: Number.parseFloat(monthlyAverage.toFixed(2)),
        comparison: Number.parseFloat(monthlyComparison.toFixed(1)),
      },
    }

    // Lưu vào bộ nhớ đệm
    cacheManager.set(cacheKey, data, CACHE_EXPIRY.FORECAST)

    return data
  } catch (error) {
    console.error("Error calculating solar forecast:", error)
    throw error
  }
}

// Lấy dữ liệu tối ưu hóa hệ thống năng lượng mặt trời
export async function getSolarOptimization(lat: number, lon: number): Promise<OptimizationData> {
  try {
    // Tạo khóa bộ nhớ đệm
    const cacheKey = `solar_optimization_${lat}_${lon}`

    // Kiểm tra bộ nhớ đệm
    const cachedData = cacheManager.get<OptimizationData>(cacheKey)
    if (cachedData) {
      return cachedData
    }

    // Tính góc nghiêng tối ưu (gần bằng vĩ độ)
    const optimalTilt = Math.round(lat)

    // Góc phương vị tối ưu (180 = hướng nam ở bán cầu bắc)
    const optimalAzimuth = 180

    // Tính hiệu suất hiện tại và tối ưu
    const currentEfficiency = 85 // 85%

    // Tính cải thiện dựa trên sự khác biệt giữa góc hiện tại và tối ưu
    const tiltDifference = Math.abs(DEFAULT_SYSTEM.tilt - optimalTilt)
    const azimuthDifference = Math.abs(DEFAULT_SYSTEM.azimuth - optimalAzimuth)

    // Giả sử mỗi độ lệch làm giảm hiệu suất 0.1%
    const tiltLoss = tiltDifference * 0.1
    const azimuthLoss = azimuthDifference * 0.1

    // Hiệu suất tối ưu
    const optimalEfficiency = currentEfficiency + tiltLoss + azimuthLoss

    // Tính % cải thiện
    const efficiencyGain = ((optimalEfficiency - currentEfficiency) / currentEfficiency) * 100

    // Tạo các khuyến nghị
    const recommendations = []

    if (tiltDifference > 5) {
      recommendations.push({
        type: "tilt_adjustment",
        description: `Điều chỉnh góc nghiêng từ ${DEFAULT_SYSTEM.tilt}° đến ${optimalTilt}°`,
        impact: Number.parseFloat(((tiltLoss / currentEfficiency) * 100).toFixed(1)),
        difficulty: "medium",
      })
    }

    if (azimuthDifference > 10) {
      recommendations.push({
        type: "azimuth_adjustment",
        description: `Điều chỉnh góc phương vị từ ${DEFAULT_SYSTEM.azimuth}° đến ${optimalAzimuth}°`,
        impact: Number.parseFloat(((azimuthLoss / currentEfficiency) * 100).toFixed(1)),
        difficulty: "hard",
      })
    }

    // Thêm khuyến nghị về làm sạch tấm pin
    recommendations.push({
      type: "cleaning",
      description: "Làm sạch tấm pin để loại bỏ bụi bẩn và cặn bẩm",
      impact: 5.0, // 5% cải thiện
      difficulty: "easy",
    })

    // Thêm khuyến nghị về bảo trì
    const daysSinceLastMaintenance = Math.floor(
      (new Date().getTime() - new Date(DEFAULT_SYSTEM.lastMaintenance).getTime()) / (24 * 60 * 60 * 1000),
    )

    if (daysSinceLastMaintenance > 180) {
      // Hơn 6 tháng
      recommendations.push({
        type: "maintenance",
        description: "Thực hiện bảo trì định kỳ để đảm bảo hiệu suất tối ưu",
        impact: 3.0, // 3% cải thiện
        difficulty: "medium",
      })
    }

    // Tạo dữ liệu phản hồi
    const data: OptimizationData = {
      current: {
        tilt: DEFAULT_SYSTEM.tilt,
        azimuth: DEFAULT_SYSTEM.azimuth,
        efficiency: currentEfficiency,
      },
      optimal: {
        tilt: optimalTilt,
        azimuth: optimalAzimuth,
        efficiency: Number.parseFloat(optimalEfficiency.toFixed(1)),
        gain: Number.parseFloat(efficiencyGain.toFixed(1)),
      },
      recommendations,
    }

    // Lưu vào bộ nhớ đệm
    cacheManager.set(cacheKey, data, CACHE_EXPIRY.SOLAR_DATA)

    return data
  } catch (error) {
    console.error("Error calculating solar optimization:", error)
    throw error
  }
}

// Hàm trợ giúp để tính bức xạ mặt trời cho một giờ cụ thể
function getSolarRadiationForHour(hour: number, cloudiness: number): number {
  // Không có bức xạ vào ban đêm
  if (hour < 6 || hour > 18) {
    return 0
  }

  // Bức xạ cao nhất vào trưa
  const maxRadiation = 1000 // W/m²
  const timeOfDay = Math.sin(((hour - 6) * Math.PI) / 12)

  // Giảm bức xạ dựa trên độ che phủ của mây
  const cloudFactor = 1 - (cloudiness / 100) * 0.8

  return maxRadiation * timeOfDay * cloudFactor
}

