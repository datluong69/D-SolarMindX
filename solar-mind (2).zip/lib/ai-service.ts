import { environmentalService, powerService } from "./api-service"

// Lưu ý: API key nên được lưu trữ trong biến môi trường server-side
// và KHÔNG bao giờ được hiển thị trên client
// Đây là một service chỉ chạy trên server

export type AIAnalysisResult = {
  summary: string
  recommendations: Array<{
    title: string
    description: string
    priority: "high" | "medium" | "low"
    potentialSavings?: string
    implementationDifficulty?: "easy" | "moderate" | "complex"
  }>
  insights: Array<{
    title: string
    description: string
    trend?: "increasing" | "decreasing" | "stable"
    impact?: "positive" | "negative" | "neutral"
  }>
  forecastAccuracy?: number
}

export type PanelIssue = {
  type: "dust" | "damage" | "shading" | "hotspot" | "degradation" | "other"
  severity: "high" | "medium" | "low"
  location: string
  description: string
  recommendedAction: string
  estimatedImpact: string
}

// Phân tích dữ liệu môi trường và sản xuất điện
export async function analyzeSystemPerformance(
  timeframe: "day" | "week" | "month" = "week",
  language = "en",
): Promise<AIAnalysisResult> {
  try {
    // Lấy dữ liệu môi trường hiện tại
    const environmentalData = await environmentalService.getCurrentData(language)

    // Lấy dữ liệu sản xuất điện lịch sử
    const powerData = await powerService.getHistoricalGeneration(timeframe, language)

    // Lấy trạng thái hệ thống
    const systemStatus = await powerService.getSystemStatus(language)

    // Mô phỏng phân tích AI
    // Trong ứng dụng thực, đây là nơi bạn sẽ gọi API OpenAI

    // Tạo phân tích mô phỏng dựa trên dữ liệu thực
    const analysis = simulateAIAnalysis(environmentalData, powerData, systemStatus, timeframe)

    return analysis
  } catch (error) {
    console.error("Error analyzing system performance:", error)
    throw new Error("Failed to analyze system performance")
  }
}

// Phân tích hình ảnh tấm pin để phát hiện vấn đề
export async function analyzePanelImage(imageBase64: string, language = "en"): Promise<PanelIssue[]> {
  try {
    // Mô phỏng phân tích hình ảnh AI
    // Trong ứng dụng thực, đây là nơi bạn sẽ gọi API OpenAI Vision

    // Tạo kết quả mô phỏng
    const issues = simulateImageAnalysis(imageBase64)

    return issues
  } catch (error) {
    console.error("Error analyzing panel image:", error)
    throw new Error("Failed to analyze panel image")
  }
}

// Tạo kế hoạch tối ưu hóa dựa trên dữ liệu hiện tại
export async function generateOptimizationPlan(language = "en"): Promise<{
  plan: string
  estimatedImprovement: string
  steps: string[]
  timeToImplement: string
}> {
  try {
    // Lấy dữ liệu hiện tại
    const environmentalData = await environmentalService.getCurrentData(language)
    const systemStatus = await powerService.getSystemStatus(language)

    // Mô phỏng tạo kế hoạch tối ưu hóa
    // Trong ứng dụng thực, đây là nơi bạn sẽ gọi API OpenAI

    // Tạo kế hoạch mô phỏng
    const plan = simulateOptimizationPlan(environmentalData, systemStatus)

    return plan
  } catch (error) {
    console.error("Error generating optimization plan:", error)
    throw new Error("Failed to generate optimization plan")
  }
}

// Hàm mô phỏng để tạo phân tích AI
function simulateAIAnalysis(
  environmentalData: any,
  powerData: any,
  systemStatus: any,
  timeframe: string,
): AIAnalysisResult {
  // Xác định xu hướng từ dữ liệu điện
  const powerValues = powerData?.data?.map((item: any) => item.power) || []
  const avgPower = powerValues.length
    ? powerValues.reduce((sum: number, val: number) => sum + val, 0) / powerValues.length
    : 0

  // Xác định xu hướng (tăng, giảm hoặc ổn định)
  let trend: "increasing" | "decreasing" | "stable" = "stable"
  if (powerValues.length > 5) {
    const firstHalf = powerValues.slice(0, Math.floor(powerValues.length / 2))
    const secondHalf = powerValues.slice(Math.floor(powerValues.length / 2))

    const firstHalfAvg = firstHalf.reduce((sum: number, val: number) => sum + val, 0) / firstHalf.length
    const secondHalfAvg = secondHalf.reduce((sum: number, val: number) => sum + val, 0) / secondHalf.length

    if (secondHalfAvg > firstHalfAvg * 1.05) trend = "increasing"
    else if (secondHalfAvg < firstHalfAvg * 0.95) trend = "decreasing"
  }

  // Kiểm tra các vấn đề từ trạng thái hệ thống
  const hasIssues = systemStatus?.data?.panels?.issues > 0 || systemStatus?.data?.inverter?.status !== "optimal"

  // Kiểm tra mức độ bụi
  const dustLevel = environmentalData?.data?.dustLevel || 0
  const highDust = dustLevel > 30

  // Tạo phân tích dựa trên dữ liệu
  return {
    summary:
      trend === "increasing"
        ? "Hiệu suất hệ thống đang cải thiện trong khoảng thời gian này. Sản lượng điện cao hơn so với giai đoạn trước đó."
        : trend === "decreasing"
          ? "Hiệu suất hệ thống đang giảm trong khoảng thời gian này. Điều này có thể do điều kiện thời tiết hoặc vấn đề với hệ thống."
          : "Hiệu suất hệ thống ổn định trong khoảng thời gian này.",

    recommendations: [
      ...(highDust
        ? [
            {
              title: "Làm sạch tấm pin",
              description: "Mức độ bụi cao đã được phát hiện. Làm sạch tấm pin có thể cải thiện hiệu suất lên đến 15%.",
              priority: "high" as const,
              potentialSavings: "10-15% tăng sản lượng",
              implementationDifficulty: "easy" as const,
            },
          ]
        : []),

      ...(hasIssues
        ? [
            {
              title: "Kiểm tra hệ thống",
              description:
                "Phát hiện vấn đề với một hoặc nhiều tấm pin hoặc bộ biến tần. Khuyến nghị kiểm tra kỹ thuật.",
              priority: "high" as const,
              implementationDifficulty: "moderate" as const,
            },
          ]
        : []),

      {
        title: "Tối ưu hóa góc nghiêng theo mùa",
        description: "Điều chỉnh góc nghiêng tấm pin để tối ưu hóa cho mùa hiện tại có thể cải thiện hiệu suất.",
        priority: "medium" as const,
        potentialSavings: "5-8% tăng sản lượng",
        implementationDifficulty: "easy" as const,
      },

      {
        title: "Lập lịch bảo trì định kỳ",
        description: "Bảo trì định kỳ giúp duy trì hiệu suất tối ưu và kéo dài tuổi thọ hệ thống.",
        priority: "low" as const,
        implementationDifficulty: "easy" as const,
      },
    ],

    insights: [
      {
        title: "Xu hướng sản xuất",
        description: `Sản lượng điện đang ${
          trend === "increasing" ? "tăng" : trend === "decreasing" ? "giảm" : "ổn định"
        } trong ${timeframe === "day" ? "ngày" : timeframe === "week" ? "tuần" : "tháng"} qua.`,
        trend: trend,
        impact: trend === "increasing" ? "positive" : trend === "decreasing" ? "negative" : "neutral",
      },

      {
        title: "Hiệu suất hệ thống",
        description: `Hiệu suất hệ thống hiện tại là ${systemStatus?.data?.systemHealth || "85"}%, ${
          (systemStatus?.data?.systemHealth || 85) > 90
            ? "rất tốt"
            : (systemStatus?.data?.systemHealth || 85) > 80
              ? "tốt"
              : (systemStatus?.data?.systemHealth || 85) > 70
                ? "trung bình"
                : "cần cải thiện"
        }.`,
        impact:
          (systemStatus?.data?.systemHealth || 85) > 80
            ? "positive"
            : (systemStatus?.data?.systemHealth || 85) > 70
              ? "neutral"
              : "negative",
      },

      {
        title: "Ảnh hưởng của thời tiết",
        description: `Điều kiện thời tiết hiện tại ${
          environmentalData?.data?.temperature > 30
            ? "rất nóng"
            : environmentalData?.data?.temperature > 25
              ? "nóng"
              : environmentalData?.data?.temperature > 15
                ? "ôn hòa"
                : "mát"
        } với độ ẩm ${environmentalData?.data?.humidity || 50}%. ${
          environmentalData?.data?.temperature > 35
            ? "Nhiệt độ cao có thể giảm hiệu suất tấm pin."
            : environmentalData?.data?.temperature < 10
              ? "Nhiệt độ thấp có thể ảnh hưởng đến hiệu suất."
              : "Điều kiện này thuận lợi cho sản xuất năng lượng mặt trời."
        }`,
        impact:
          environmentalData?.data?.temperature > 35 || environmentalData?.data?.temperature < 10
            ? "negative"
            : "positive",
      },
    ],

    forecastAccuracy: 92,
  }
}

// Hàm mô phỏng để phân tích hình ảnh tấm pin
function simulateImageAnalysis(imageBase64: string): PanelIssue[] {
  // Trong ứng dụng thực, bạn sẽ gửi hình ảnh đến API Vision AI
  // Ở đây chúng ta tạo kết quả mô phỏng

  // Tạo một số vấn đề ngẫu nhiên
  const issues: PanelIssue[] = []

  // Xác định ngẫu nhiên nếu có vấn đề về bụi
  if (Math.random() > 0.3) {
    issues.push({
      type: "dust",
      severity: Math.random() > 0.5 ? "medium" : "low",
      location: "Toàn bộ bề mặt tấm pin",
      description: "Phát hiện lớp bụi trên bề mặt tấm pin.",
      recommendedAction: "Làm sạch tấm pin bằng nước sạch và dụng cụ làm sạch không gây trầy xước.",
      estimatedImpact: "Giảm hiệu suất 5-10%",
    })
  }

  // Xác định ngẫu nhiên nếu có vấn đề về bóng râm
  if (Math.random() > 0.7) {
    issues.push({
      type: "shading",
      severity: "medium",
      location: "Góc dưới bên phải của tấm pin",
      description: "Phát hiện bóng râm một phần trên tấm pin, có thể do cây cối hoặc cấu trúc gần đó.",
      recommendedAction: "Xem xét cắt tỉa cây cối hoặc điều chỉnh vị trí tấm pin để giảm bóng râm.",
      estimatedImpact: "Giảm hiệu suất 15-20% trong khu vực bị ảnh hưởng",
    })
  }

  // Xác định ngẫu nhiên nếu có điểm nóng
  if (Math.random() > 0.8) {
    issues.push({
      type: "hotspot",
      severity: "high",
      location: "Phần trên bên trái của tấm pin",
      description: "Phát hiện điểm nóng, có thể do lỗi kết nối hoặc tế bào bị hỏng.",
      recommendedAction: "Yêu cầu kiểm tra kỹ thuật ngay lập tức để đánh giá và sửa chữa.",
      estimatedImpact: "Giảm hiệu suất 20-30% và có thể gây hư hỏng vĩnh viễn nếu không xử lý",
    })
  }

  // Xác định ngẫu nhiên nếu có vấn đề về xuống cấp
  if (Math.random() > 0.9) {
    issues.push({
      type: "degradation",
      severity: "medium",
      location: "Rải rác trên bề mặt tấm pin",
      description: "Phát hiện dấu hiệu xuống cấp do thời gian, có thể là do tấm pin đã cũ.",
      recommendedAction: "Theo dõi hiệu suất và cân nhắc thay thế trong 1-2 năm tới.",
      estimatedImpact: "Giảm hiệu suất 10-15% so với tấm pin mới",
    })
  }

  // Nếu không phát hiện vấn đề, thêm một kết quả "không có vấn đề"
  if (issues.length === 0) {
    issues.push({
      type: "other",
      severity: "low",
      location: "Toàn bộ tấm pin",
      description: "Không phát hiện vấn đề đáng kể. Tấm pin có vẻ trong tình trạng tốt.",
      recommendedAction: "Tiếp tục bảo trì định kỳ theo lịch trình.",
      estimatedImpact: "Không có tác động tiêu cực đến hiệu suất",
    })
  }

  return issues
}

// Hàm mô phỏng để tạo kế hoạch tối ưu hóa
function simulateOptimizationPlan(
  environmentalData: any,
  systemStatus: any,
): {
  plan: string
  estimatedImprovement: string
  steps: string[]
  timeToImplement: string
} {
  // Tạo kế hoạch dựa trên dữ liệu hiện tại
  const dustLevel = environmentalData?.data?.dustLevel || 0
  const systemHealth = systemStatus?.data?.systemHealth || 85
  const panelIssues = systemStatus?.data?.panels?.issues || 0

  const steps: string[] = []
  let estimatedImprovement = "5-10%"

  // Thêm các bước dựa trên tình trạng hệ thống
  if (dustLevel > 30) {
    steps.push("Làm sạch tất cả các tấm pin để loại bỏ bụi bẩn và cặn bẩm.")
    estimatedImprovement = "10-15%"
  }

  if (panelIssues > 0) {
    steps.push("Kiểm tra và sửa chữa các tấm pin có vấn đề để khôi phục hiệu suất tối đa.")
    estimatedImprovement = "15-20%"
  }

  if (systemStatus?.data?.inverter?.status !== "optimal") {
    steps.push("Bảo trì hoặc nâng cấp bộ biến tần để cải thiện hiệu suất chuyển đổi.")
    estimatedImprovement = "10-15%"
  }

  // Thêm các bước tối ưu hóa chung
  steps.push("Điều chỉnh góc nghiêng tấm pin để tối ưu hóa cho mùa và vị trí hiện tại.")
  steps.push("Kiểm tra và tối ưu hóa kết nối dây điện để giảm tổn thất điện năng.")
  steps.push("Cập nhật phần mềm hệ thống giám sát để cải thiện độ chính xác của dữ liệu.")

  // Nếu không có bước cụ thể, thêm bước chung
  if (steps.length < 3) {
    steps.push("Thực hiện kiểm tra hệ thống toàn diện để xác định các cơ hội tối ưu hóa.")
  }

  return {
    plan: `Kế hoạch tối ưu hóa cho hệ thống năng lượng mặt trời của bạn (Hiệu suất hiện tại: ${systemHealth}%)`,
    estimatedImprovement: estimatedImprovement,
    steps: steps,
    timeToImplement: steps.length > 4 ? "2-3 ngày" : "1 ngày",
  }
}

