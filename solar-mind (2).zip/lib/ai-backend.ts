// This file simulates a backend AI service

// Sample responses for different user queries
const responseTemplates = {
  power: [
    "Your current power generation is 3.2 kW. This is 15% above average for this time of day.",
    "Right now, your system is generating 2.8 kW of power, which is slightly below expected due to some cloud cover.",
    "Your panels are currently producing 4.1 kW. This is excellent performance for this time of day!",
    "Current power output is 1.9 kW. This is lower than usual due to the weather conditions today.",
  ],
  efficiency: [
    "Your system efficiency is currently at 87%. The main factor affecting this is dust accumulation on panels 2 and 3.",
    "Panel efficiency is at 92%, which is very good. Regular maintenance has kept your system in optimal condition.",
    "System efficiency has dropped to 78% this week. I recommend scheduling a cleaning service to improve performance.",
    "Your efficiency is currently 84%. This is normal for your system's age and the current weather conditions.",
  ],
  weather: [
    "The weather forecast shows sunny conditions for the next 3 days, which should result in optimal power generation.",
    "There's rain expected tomorrow, which might reduce your power output by approximately 30-40%.",
    "Weather conditions look favorable for solar production this week, with clear skies predicted for most days.",
    "A storm system is approaching your area. I recommend checking that your system's safety protocols are active.",
  ],
  maintenance: [
    "Your next scheduled maintenance is on June 15th. Would you like me to remind you closer to the date?",
    "It's been 6 months since your last panel cleaning. Based on your dust levels, I recommend scheduling a cleaning soon.",
    "Your inverter is due for inspection next month. This is important to maintain optimal system performance.",
    "No maintenance is currently scheduled. Based on system performance, I recommend a general check-up in the next 30 days.",
  ],
  savings: [
    "You've saved approximately $127 on your electricity bill this month thanks to your solar system.",
    "Your system has offset about 0.8 tons of CO2 emissions this quarter, equivalent to planting 12 trees.",
    "Your energy savings this year are tracking 15% higher than last year, primarily due to improved system efficiency.",
    "Based on current production, you're on track to save $1,450 this year on electricity costs.",
  ],
  general: [
    "I'm here to help you monitor and optimize your solar panel system. Is there anything specific you'd like to know?",
    "Your solar system is performing within normal parameters. All components are functioning correctly.",
    "I've noticed a slight decrease in performance from panel #4. It might need attention in the coming weeks.",
    "Based on your usage patterns, you could increase your energy savings by shifting some high-consumption activities to daylight hours.",
  ],
}

// Function to determine the type of query
function categorizeQuery(query: string): string {
  query = query.toLowerCase()

  if (
    query.includes("power") ||
    query.includes("generating") ||
    query.includes("output") ||
    query.includes("production")
  ) {
    return "power"
  } else if (query.includes("efficien") || query.includes("perform")) {
    return "efficiency"
  } else if (
    query.includes("weather") ||
    query.includes("forecast") ||
    query.includes("sun") ||
    query.includes("cloud")
  ) {
    return "weather"
  } else if (
    query.includes("maintenance") ||
    query.includes("clean") ||
    query.includes("service") ||
    query.includes("schedule")
  ) {
    return "maintenance"
  } else if (
    query.includes("save") ||
    query.includes("saving") ||
    query.includes("cost") ||
    query.includes("bill") ||
    query.includes("money")
  ) {
    return "savings"
  } else {
    return "general"
  }
}

// Function to get a random response from the appropriate category
function getRandomResponse(category: string): string {
  const responses = responseTemplates[category as keyof typeof responseTemplates] || responseTemplates.general
  return responses[Math.floor(Math.random() * responses.length)]
}

// Function to check if the query is about an image
function isImageQuery(query: string): boolean {
  return (
    query.toLowerCase().includes("image") ||
    query.toLowerCase().includes("photo") ||
    query.toLowerCase().includes("picture")
  )
}

// Simulate AI response generation
export async function simulateAIResponse(query: string, previousMessages: any[]): Promise<string> {
  // Simulate processing delay
  await new Promise((resolve) => setTimeout(resolve, 500 + Math.random() * 1000))

  // Special case for image uploads
  if (query.includes("image of my solar panel")) {
    return "I can see from the image that your solar panels appear to have some dust accumulation, particularly on the edges. This can reduce efficiency by 5-10%. I recommend cleaning them with distilled water and a soft brush. Would you like me to provide more detailed cleaning instructions?"
  }

  // Check for follow-up questions
  const lastAssistantMessage = [...previousMessages].reverse().find((m) => m.role === "assistant")
  if (
    lastAssistantMessage &&
    query.length < 20 &&
    (query.toLowerCase().includes("yes") ||
      query.toLowerCase().includes("sure") ||
      query.toLowerCase().includes("please") ||
      query.toLowerCase().includes("ok"))
  ) {
    if (lastAssistantMessage.content.includes("cleaning instructions")) {
      return "Here are detailed cleaning instructions for your solar panels:\n\n1. Choose early morning or evening when panels are cool\n2. Use distilled water and a soft microfiber cloth\n3. Gently wipe in a circular motion\n4. Avoid harsh chemicals or abrasive materials\n5. Rinse with clean water\n6. Allow to air dry\n\nFor stubborn spots, a mild soap solution (1:10 ratio) can be used. Would you like me to schedule a professional cleaning service instead?"
    }

    if (lastAssistantMessage.content.includes("schedule")) {
      return "I've checked available slots for professional cleaning services. They can come on Tuesday at 10 AM or Thursday at 2 PM next week. Which would you prefer? The service costs approximately $80 and takes about 1-2 hours."
    }
  }

  // Generate a response based on the query category
  const category = categorizeQuery(query)
  return getRandomResponse(category)
}

