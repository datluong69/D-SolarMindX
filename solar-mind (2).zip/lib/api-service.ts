// Centralized API service for handling all backend requests

import { toast } from "@/components/ui/use-toast"

// Base URL for API requests
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "https://api.solarmind.example.com"

// Simulated API key - in a real app, this would be securely stored
const API_KEY = "sk_solarmind_12345678abcdefgh"

// Default headers for all requests
const defaultHeaders = {
  "Content-Type": "application/json",
  Authorization: `Bearer ${API_KEY}`,
  "Accept-Language": "en",
}

// Helper function to handle API errors
const handleApiError = (error: any, customMessage?: string) => {
  console.error("API Error:", error)

  let errorMessage = customMessage || "An unexpected error occurred"

  if (error.response) {
    // The request was made and the server responded with a status code
    // that falls out of the range of 2xx
    errorMessage = error.response.data?.message || `Error ${error.response.status}: ${error.response.statusText}`
  } else if (error.request) {
    // The request was made but no response was received
    errorMessage = "No response received from server. Please check your connection."
  } else {
    // Something happened in setting up the request that triggered an Error
    errorMessage = error.message || errorMessage
  }

  toast({
    title: "Error",
    description: errorMessage,
    variant: "destructive",
  })

  return { success: false, error: errorMessage }
}

// Generic fetch function with error handling
async function fetchApi<T>(endpoint: string, options: RequestInit = {}, language = "en"): Promise<T> {
  try {
    const headers = {
      ...defaultHeaders,
      "Accept-Language": language,
      ...options.headers,
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw {
        response: {
          status: response.status,
          statusText: response.statusText,
          data: errorData,
        },
      }
    }

    return await response.json()
  } catch (error) {
    return handleApiError(error) as T
  }
}

// Weather and environmental data API
export const environmentalService = {
  // Get current environmental data
  getCurrentData: async (language = "en") => {
    // Simulate real data with randomization
    const simulateRealData = () => {
      const now = new Date()
      const hour = now.getHours()

      // Base values that change throughout the day
      const baseTemp = 20 + Math.sin(((hour - 6) * Math.PI) / 12) * 10 // Peak at noon
      const baseHumidity = 50 + Math.sin(((hour - 12) * Math.PI) / 12) * 20 // Peak at 6pm
      const baseWindSpeed = 5 + Math.sin((hour * Math.PI) / 12) * 3 // Varies throughout day
      const baseDustLevel = 15 + Math.sin(((hour - 9) * Math.PI) / 12) * 10 // Peak at 3pm

      // Add some randomness
      return {
        temperature: Math.round((baseTemp + (Math.random() * 4 - 2)) * 10) / 10,
        humidity: Math.round(baseHumidity + (Math.random() * 10 - 5)),
        windSpeed: Math.round((baseWindSpeed + (Math.random() * 2 - 1)) * 10) / 10,
        dustLevel: Math.round(baseDustLevel + (Math.random() * 8 - 4)),
        timestamp: now.toISOString(),
      }
    }

    // In a real app, this would fetch from an actual API
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          data: simulateRealData(),
        })
      }, 300)
    })
  },

  // Get forecast data for the next few days
  getForecast: async (days = 3, language = "en") => {
    // Simulate forecast data
    const simulateForecast = (days: number) => {
      const forecast = []
      const now = new Date()

      for (let i = 0; i < days; i++) {
        const date = new Date(now)
        date.setDate(date.getDate() + i)

        // Create some weather patterns
        const isRainy = Math.random() > 0.7
        const isCloudy = Math.random() > 0.5 || isRainy
        const baseTemp = 20 + Math.sin((i * Math.PI) / 7) * 5 // Weekly temperature cycle

        forecast.push({
          date: date.toISOString().split("T")[0],
          temperature: Math.round((baseTemp + (Math.random() * 4 - 2)) * 10) / 10,
          condition: isRainy ? "rainy" : isCloudy ? "cloudy" : "sunny",
          humidity: Math.round(50 + Math.random() * 30),
          windSpeed: Math.round((5 + Math.random() * 10) * 10) / 10,
          solarRadiation: isRainy
            ? Math.round(100 + Math.random() * 200)
            : isCloudy
              ? Math.round(300 + Math.random() * 300)
              : Math.round(600 + Math.random() * 400),
        })
      }

      return forecast
    }

    // In a real app, this would fetch from a weather API
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          data: simulateForecast(days),
        })
      }, 500)
    })
  },

  // Get historical environmental data
  getHistoricalData: async (startDate: string, endDate: string, language = "en") => {
    // Simulate historical data
    const simulateHistoricalData = (startDate: string, endDate: string) => {
      const start = new Date(startDate)
      const end = new Date(endDate)
      const data = []

      const current = new Date(start)
      while (current <= end) {
        const hour = current.getHours()

        // Base values that change throughout the day
        const baseTemp = 20 + Math.sin(((hour - 6) * Math.PI) / 12) * 10
        const baseHumidity = 50 + Math.sin(((hour - 12) * Math.PI) / 12) * 20
        const baseWindSpeed = 5 + Math.sin((hour * Math.PI) / 12) * 3
        const baseDustLevel = 15 + Math.sin(((hour - 9) * Math.PI) / 12) * 10

        // Add some randomness
        data.push({
          timestamp: current.toISOString(),
          temperature: Math.round((baseTemp + (Math.random() * 4 - 2)) * 10) / 10,
          humidity: Math.round(baseHumidity + (Math.random() * 10 - 5)),
          windSpeed: Math.round((baseWindSpeed + (Math.random() * 2 - 1)) * 10) / 10,
          dustLevel: Math.round(baseDustLevel + (Math.random() * 8 - 4)),
        })

        // Increment by 1 hour
        current.setHours(current.getHours() + 1)
      }

      return data
    }

    // In a real app, this would fetch from an actual API
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          data: simulateHistoricalData(startDate, endDate),
        })
      }, 800)
    })
  },
}

// Power generation and system data API
export const powerService = {
  // Get current power generation data
  getCurrentGeneration: async (language = "en") => {
    // Simulate real-time power generation
    const simulateRealTimeGeneration = () => {
      const now = new Date()
      const hour = now.getHours()

      // Solar power generation follows a bell curve during daylight hours
      let basePower = 0
      if (hour >= 6 && hour <= 18) {
        // Peak at noon (hour 12)
        basePower = 5 * Math.sin(((hour - 6) * Math.PI) / 12)
      }

      // Add some randomness
      const currentPower = Math.max(0, basePower + (Math.random() * 0.8 - 0.4))

      // Calculate daily total based on the hour
      let dailyTotal = 0
      for (let h = 6; h <= Math.min(hour, 18); h++) {
        dailyTotal += 5 * Math.sin(((h - 6) * Math.PI) / 12) * (1 + (Math.random() * 0.2 - 0.1))
      }

      // Efficiency varies slightly throughout the day
      const efficiency = 75 + Math.sin(((hour - 9) * Math.PI) / 12) * 10 + (Math.random() * 6 - 3)

      return {
        currentPower: Math.round(currentPower * 100) / 100,
        dailyTotal: Math.round(dailyTotal * 100) / 100,
        efficiency: Math.round(efficiency * 10) / 10,
        timestamp: now.toISOString(),
      }
    }

    // In a real app, this would fetch from an actual API
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          data: simulateRealTimeGeneration(),
        })
      }, 300)
    })
  },

  // Get historical power generation data
  getHistoricalGeneration: async (period: "day" | "week" | "month" | "year", language = "en") => {
    // Simulate historical power generation data
    const simulateHistoricalGeneration = (period: "day" | "week" | "month" | "year") => {
      const now = new Date()
      const data = []

      let dataPoints = 24 // Default to 24 hours (day)
      let intervalHours = 1

      if (period === "week") {
        dataPoints = 7 * 24
        intervalHours = 1
      } else if (period === "month") {
        dataPoints = 30
        intervalHours = 24
      } else if (period === "year") {
        dataPoints = 12
        intervalHours = 24 * 30
      }

      for (let i = 0; i < dataPoints; i++) {
        const timestamp = new Date(now)
        timestamp.setHours(now.getHours() - i * intervalHours)

        const hour = timestamp.getHours()
        const month = timestamp.getMonth() // 0-11

        // Seasonal variation (more production in summer)
        const seasonalFactor = 1 + 0.3 * Math.sin(((month - 6) * Math.PI) / 6)

        // Daily variation (bell curve during daylight)
        let powerValue = 0
        if (hour >= 6 && hour <= 18) {
          powerValue = 5 * seasonalFactor * Math.sin(((hour - 6) * Math.PI) / 12)
        }

        // Add some randomness
        powerValue = Math.max(0, powerValue * (1 + (Math.random() * 0.3 - 0.15)))

        // For month and year, use average daily production
        if (period === "month" || period === "year") {
          let dailyTotal = 0
          for (let h = 6; h <= 18; h++) {
            dailyTotal += 5 * seasonalFactor * Math.sin(((h - 6) * Math.PI) / 12) * (1 + (Math.random() * 0.2 - 0.1))
          }
          powerValue = dailyTotal
        }

        data.push({
          timestamp: timestamp.toISOString(),
          power: Math.round(powerValue * 100) / 100,
        })
      }

      // Sort by timestamp ascending
      return data.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    }

    // In a real app, this would fetch from an actual API
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          data: simulateHistoricalGeneration(period),
        })
      }, 600)
    })
  },

  // Get system status and health
  getSystemStatus: async (language = "en") => {
    // Simulate system status
    const simulateSystemStatus = () => {
      const panelStatuses = []
      const totalPanels = 12

      // Generate status for each panel
      for (let i = 1; i <= totalPanels; i++) {
        const isIssue = Math.random() > 0.9
        const isDegraded = Math.random() > 0.8 && !isIssue

        panelStatuses.push({
          id: i,
          status: isIssue ? "issue" : isDegraded ? "degraded" : "optimal",
          efficiency: isIssue
            ? Math.round((60 + Math.random() * 20) * 10) / 10
            : isDegraded
              ? Math.round((75 + Math.random() * 10) * 10) / 10
              : Math.round((85 + Math.random() * 10) * 10) / 10,
          lastChecked: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
          issues: isIssue
            ? [
                {
                  type: Math.random() > 0.5 ? "connection" : "performance",
                  severity: Math.random() > 0.7 ? "high" : "medium",
                  description:
                    Math.random() > 0.5
                      ? "Intermittent connection issues detected"
                      : "Performance below expected threshold",
                },
              ]
            : [],
        })
      }

      // Inverter status
      const inverterStatus = Math.random() > 0.95 ? "issue" : Math.random() > 0.9 ? "warning" : "optimal"

      // Battery status (if applicable)
      const hasBattery = Math.random() > 0.5
      const batteryStatus = hasBattery
        ? {
            installed: true,
            chargeLevel: Math.round(Math.random() * 100),
            health: Math.round((85 + Math.random() * 15) * 10) / 10,
            status: Math.random() > 0.9 ? "warning" : "optimal",
          }
        : { installed: false }

      return {
        systemHealth: Math.round((85 + Math.random() * 10) * 10) / 10,
        lastMaintenance: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000).toISOString(),
        nextMaintenance: new Date(Date.now() + Math.random() * 60 * 24 * 60 * 60 * 1000).toISOString(),
        panels: {
          total: totalPanels,
          optimal: panelStatuses.filter((p) => p.status === "optimal").length,
          degraded: panelStatuses.filter((p) => p.status === "degraded").length,
          issues: panelStatuses.filter((p) => p.status === "issue").length,
          statuses: panelStatuses,
        },
        inverter: {
          status: inverterStatus,
          efficiency:
            inverterStatus === "issue"
              ? Math.round((70 + Math.random() * 10) * 10) / 10
              : inverterStatus === "warning"
                ? Math.round((80 + Math.random() * 10) * 10) / 10
                : Math.round((90 + Math.random() * 8) * 10) / 10,
          lastChecked: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
          issues:
            inverterStatus !== "optimal"
              ? [
                  {
                    type: inverterStatus === "issue" ? "hardware" : "performance",
                    severity: inverterStatus === "issue" ? "high" : "low",
                    description:
                      inverterStatus === "issue"
                        ? "Hardware fault detected in inverter"
                        : "Inverter efficiency below optimal levels",
                  },
                ]
              : [],
        },
        battery: batteryStatus,
      }
    }

    // In a real app, this would fetch from an actual API
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          data: simulateSystemStatus(),
        })
      }, 700)
    })
  },

  // Optimize panel position
  optimizePanels: async (autoMode = false, language = "en") => {
    // Simulate optimization process
    const simulateOptimization = (autoMode: boolean) => {
      // Get current time to determine optimal angles
      const now = new Date()
      const hour = now.getHours()
      const month = now.getMonth() // 0-11

      // Seasonal adjustment for tilt angle
      // Northern hemisphere: More vertical in winter, more horizontal in summer
      const seasonalTilt = 30 + 15 * Math.cos(((month - 6) * Math.PI) / 6)

      // Daily adjustment for rotation angle (tracking the sun)
      // 90° at sunrise (east), 180° at noon (south), 270° at sunset (west)
      let optimalRotation = 180 // Default to south
      if (hour >= 6 && hour <= 18) {
        optimalRotation = 90 + (hour - 6) * 15 // 15° per hour
      }

      // Add some randomness to make it realistic
      const optimalTilt = Math.round((seasonalTilt + (Math.random() * 4 - 2)) * 10) / 10
      const optimalRotationWithNoise = Math.round((optimalRotation + (Math.random() * 10 - 5)) * 10) / 10

      return {
        success: true,
        autoMode: autoMode,
        optimizedSettings: {
          tiltAngle: optimalTilt,
          rotationAngle: optimalRotationWithNoise,
          timestamp: now.toISOString(),
        },
        estimatedImprovement: Math.round((5 + Math.random() * 10) * 10) / 10,
      }
    }

    // In a real app, this would send commands to the actual hardware
    return new Promise((resolve) => {
      // Simulate a longer process for optimization
      setTimeout(() => {
        resolve(simulateOptimization(autoMode))
      }, 2000)
    })
  },
}

// Notifications and alerts API
export const notificationService = {
  // Get all notifications
  getNotifications: async (language = "en") => {
    return fetchApi("/api/notifications", { method: "GET" }, language)
  },

  // Mark notification as read
  markAsRead: async (notificationId: string, language = "en") => {
    return fetchApi(`/api/notifications/${notificationId}/read`, { method: "POST" }, language)
  },

  // Delete notification
  deleteNotification: async (notificationId: string, language = "en") => {
    return fetchApi(`/api/notifications/${notificationId}`, { method: "DELETE" }, language)
  },

  // Schedule service from notification
  scheduleService: async (
    notificationId: string,
    serviceDetails: { date: string; time: string; type: string },
    language = "en",
  ) => {
    return fetchApi(
      `/api/notifications/${notificationId}/schedule`,
      {
        method: "POST",
        body: JSON.stringify(serviceDetails),
      },
      language,
    )
  },
}

// Chat and support API
export const chatService = {
  // Get AI assistant response
  getAIResponse: async (message: string, history: any[], language = "en") => {
    // In a real app, this would call a real AI service
    return fetchApi(
      "/api/chat/ai",
      {
        method: "POST",
        body: JSON.stringify({ message, history }),
      },
      language,
    )
  },

  // Get expert response
  getExpertResponse: async (message: string, history: any[], expertId: string, language = "en") => {
    // In a real app, this would route to a real expert or AI service
    return fetchApi(
      `/api/chat/expert/${expertId}`,
      {
        method: "POST",
        body: JSON.stringify({ message, history }),
      },
      language,
    )
  },

  // Schedule expert consultation
  scheduleConsultation: async (
    expertId: string,
    consultationDetails: { date: string; time: string; type: string },
    language = "en",
  ) => {
    return fetchApi(
      `/api/chat/expert/${expertId}/schedule`,
      {
        method: "POST",
        body: JSON.stringify(consultationDetails),
      },
      language,
    )
  },

  // Get available experts
  getAvailableExperts: async (language = "en") => {
    return fetchApi("/api/chat/experts", { method: "GET" }, language)
  },
}

// Scheduling and maintenance API
export const scheduleService = {
  // Get available time slots
  getAvailableSlots: async (date: string, language = "en") => {
    return fetchApi(`/api/schedule/available?date=${date}`, { method: "GET" }, language)
  },

  // Schedule maintenance
  scheduleMaintenance: async (
    maintenanceDetails: {
      date: string
      time: string
      type: string
      notes?: string
    },
    language = "en",
  ) => {
    return fetchApi(
      "/api/schedule",
      {
        method: "POST",
        body: JSON.stringify(maintenanceDetails),
      },
      language,
    )
  },

  // Get scheduled maintenance
  getScheduledMaintenance: async (language = "en") => {
    return fetchApi("/api/schedule", { method: "GET" }, language)
  },

  // Cancel scheduled maintenance
  cancelMaintenance: async (scheduleId: string, language = "en") => {
    return fetchApi(`/api/schedule/${scheduleId}`, { method: "DELETE" }, language)
  },
}

// Payment API
export const paymentService = {
  // Process payment
  processPayment: async (
    paymentDetails: {
      amount: number
      currency: string
      method: string
      cardDetails?: {
        number: string
        name: string
        expiry: string
        cvc: string
      }
      description: string
    },
    language = "en",
  ) => {
    return fetchApi(
      "/api/payment",
      {
        method: "POST",
        body: JSON.stringify(paymentDetails),
      },
      language,
    )
  },

  // Get payment history
  getPaymentHistory: async (language = "en") => {
    return fetchApi("/api/payment/history", { method: "GET" }, language)
  },
}

// User settings and preferences API
export const userService = {
  // Get user profile
  getUserProfile: async (language = "en") => {
    return fetchApi("/api/user/profile", { method: "GET" }, language)
  },

  // Update user profile
  updateUserProfile: async (profileData: any, language = "en") => {
    return fetchApi(
      "/api/user/profile",
      {
        method: "PUT",
        body: JSON.stringify(profileData),
      },
      language,
    )
  },

  // Update user preferences
  updateUserPreferences: async (preferences: any, language = "en") => {
    return fetchApi(
      "/api/user/preferences",
      {
        method: "PUT",
        body: JSON.stringify(preferences),
      },
      language,
    )
  },

  // Get user notification settings
  getNotificationSettings: async (language = "en") => {
    return fetchApi("/api/user/notifications/settings", { method: "GET" }, language)
  },

  // Update notification settings
  updateNotificationSettings: async (settings: any, language = "en") => {
    return fetchApi(
      "/api/user/notifications/settings",
      {
        method: "PUT",
        body: JSON.stringify(settings),
      },
      language,
    )
  },
}

