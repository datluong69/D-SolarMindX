// This file simulates backend expert responses

// Sample expert responses for different categories
const expertResponseTemplates = {
  technical: [
    "Based on what you've described, it sounds like there might be an issue with the inverter connection. The error code E-14 typically indicates a communication failure between the panels and the inverter. I recommend checking the following:\n\n1. Inspect all wiring connections between panels and inverter\n2. Verify the inverter is receiving power\n3. Check if the inverter's firmware is up to date\n\nIf these steps don't resolve the issue, we may need to schedule a technician visit. Would you like me to arrange that for you?",

    "The symptoms you're describing suggest a potential issue with the charge controller. When the system shows intermittent power fluctuations like this, it's often related to how the controller is managing the power flow. Let's try a simple reset procedure first:\n\n1. Power down the system completely\n2. Wait 2 minutes for capacitors to discharge\n3. Power the system back up\n\nIf the issue persists after this reset, we should look at the controller settings or possibly replace the unit. I can guide you through checking the settings if you'd like.",

    "Looking at your system's error logs, I can see there have been multiple instances of voltage regulation issues. This typically happens when there's a mismatch between the panels and the battery storage system. The most common causes are:\n\n1. Battery degradation over time\n2. New panels added to an existing system without reconfiguration\n3. Weather-related stress on the system\n\nI recommend we schedule a comprehensive system diagnostic to identify the exact cause. In the meantime, you can safely continue using the system, but you might notice reduced efficiency.",
  ],

  performance: [
    "I've analyzed your recent production data, and you're right that your output is about 18% lower than expected for this time of year. There are several potential causes:\n\n1. Panel degradation (natural over time)\n2. Dust or debris accumulation\n3. Shading that wasn't present when the system was installed\n4. Inverter efficiency loss\n\nLet's start with the simplest solution - when was the last time your panels were cleaned? A professional cleaning could potentially recover 5-10% of that lost efficiency immediately.",

    "Your system's performance has indeed declined compared to last year. Looking at your data, I notice the drop began gradually about 3 months ago. This pattern is consistent with either seasonal shading changes (like trees that have grown) or gradual dust buildup. The good news is that your inverter efficiency still looks excellent, so the issue is likely with the panels themselves.\n\nWould you like me to analyze satellite  so the issue is likely with the panels themselves.\n\nWould you like me to analyze satellite imagery of your installation to check for potential shading issues? I can also remotely run a panel-by-panel diagnostic to identify any underperforming units in your array. This would help us pinpoint exactly which panels might need attention or replacement.",

    "After reviewing your energy production data for the past six months, I can confirm that your system is performing about 12% below its rated capacity. This isn't unusual for systems that are 3-5 years old, but we can definitely improve it. The data shows your peak production occurs between 11am-2pm, which is normal, but your morning and afternoon generation curves are flatter than ideal.\n\nThis suggests two possibilities: either your panel angle isn't optimized for your location, or there might be some partial shading during those times. I'd recommend we schedule a site assessment to check the panel positioning and surrounding vegetation. Would you like me to arrange this for you?",
  ],

  maintenance: [
    "Based on your system's age and the local climate conditions, I recommend the following maintenance schedule:\n\n1. Panel cleaning: Every 3-4 months (more frequently during pollen season)\n2. System inspection: Twice yearly\n3. Inverter check: Annually\n4. Full diagnostic test: Annually\n\nYour last recorded maintenance was 7 months ago, so you're due for both cleaning and inspection. Would you like me to help you schedule these services?",

    "The discoloration you've noticed on your panels is likely one of two things: either early stages of delamination or simply a buildup of environmental residue. Delamination would be concerning as it affects performance and longevity, while residue is easily addressed with cleaning.\n\nCan you send me a close-up photo of the discolored area? That would help me determine which issue we're dealing with and recommend the appropriate solution. If it's delamination, the panel might be covered under warranty depending on its age.",

    "For optimal performance, I recommend scheduling your panel cleaning just before your highest production season, which in your area is typically summer. The best times would be:\n\n1. Late spring (May) - to prepare for peak summer production\n2. Early fall (September) - to remove summer pollen and dust\n3. Mid-winter (January) - only if there's visible soiling\n\nWould you like me to set up a recurring maintenance plan for these intervals? We offer discounted rates for pre-scheduled maintenance packages.",
  ],

  general: [
    "I'd be happy to help you understand your energy consumption patterns. Looking at your data from the past month, I notice a few interesting trends:\n\n1. Your highest consumption occurs between 6-9pm on weekdays\n2. Your system produces most energy between 11am-3pm\n3. There's a gap where you're buying grid power during peak rate hours\n\nThis suggests an opportunity to shift some of your high-consumption activities (like laundry or dishwashing) to midday when your solar production is highest. This simple change could increase your self-consumption rate by about 15-20%, resulting in noticeable savings on your utility bill.",

    "Your question about battery storage is timely. Based on your current usage patterns and solar production, adding battery storage would increase your energy independence from approximately 65% to 85-90%. The economics work like this:\n\n- Current annual savings: $1,240\n- Projected savings with battery: $1,890\n- Battery system cost: $8,500 (after incentives)\n- Payback period: Approximately 13 years\n\nWhile the financial payback is relatively long, many of our customers value the energy security and independence that batteries provide, especially during grid outages. Would you like me to prepare a detailed proposal for a battery system tailored to your needs?",

    "I understand you're considering expanding your system. Based on your current energy usage and available roof space, I estimate you could add 8 more panels (approximately 3.2 kW additional capacity). This would increase your annual production by about 4,200 kWh.\n\nThe benefits would include:\n1. Increased self-consumption from 70% to 85%\n2. Additional annual savings of approximately $630\n3. Further reduction in your carbon footprint\n\nThe estimated cost would be around $6,400 after incentives, with a payback period of about 10 years. Would you like me to arrange for a detailed site assessment to confirm these estimates?",
  ],
}

// Function to determine the type of query
function categorizeExpertQuery(query: string): string {
  query = query.toLowerCase()

  if (
    query.includes("error") ||
    query.includes("issue") ||
    query.includes("problem") ||
    query.includes("not working") ||
    query.includes("code")
  ) {
    return "technical"
  } else if (
    query.includes("performance") ||
    query.includes("output") ||
    query.includes("efficiency") ||
    query.includes("production") ||
    query.includes("generating")
  ) {
    return "performance"
  } else if (
    query.includes("maintenance") ||
    query.includes("clean") ||
    query.includes("schedule") ||
    query.includes("service") ||
    query.includes("discolor")
  ) {
    return "maintenance"
  } else {
    return "general"
  }
}

// Function to get a random response from the appropriate category
function getRandomExpertResponse(category: string): string {
  const responses =
    expertResponseTemplates[category as keyof typeof expertResponseTemplates] || expertResponseTemplates.general
  return responses[Math.floor(Math.random() * responses.length)]
}

// Function to check if the query is about an image
function isImageQuery(query: string): boolean {
  return (
    query.toLowerCase().includes("image") ||
    query.toLowerCase().includes("photo") ||
    query.toLowerCase().includes("picture")
  )
}

// Simulate expert response generation
export async function simulateExpertResponse(
  query: string,
  previousMessages: any[],
  expertName: string,
  expertRole: string,
): Promise<string> {
  // Simulate processing delay
  await new Promise((resolve) => setTimeout(resolve, 800 + Math.random() * 1200))

  // Special case for image uploads
  if (query.includes("photo of the issue with my solar panel")) {
    return `Thank you for sharing this image. I can see that there appears to be some ${Math.random() > 0.5 ? "microcracks" : "hotspots"} on the panel surface. This is typically caused by ${Math.random() > 0.5 ? "thermal stress" : "physical impact"} and can reduce the panel's efficiency by 10-15% over time.\n\nBased on what I'm seeing, I recommend scheduling an in-person inspection to assess the extent of the damage. Depending on the age of your system, this might be covered under warranty. Would you like me to check your warranty status and arrange for a technician visit?`
  }

  // Check for follow-up questions
  const lastExpertMessage = [...previousMessages].reverse().find((m) => m.sender === "expert")
  if (
    lastExpertMessage &&
    query.length < 25 &&
    (query.toLowerCase().includes("yes") ||
      query.toLowerCase().includes("sure") ||
      query.toLowerCase().includes("please") ||
      query.toLowerCase().includes("ok") ||
      query.toLowerCase().includes("that would be"))
  ) {
    if (lastExpertMessage.content.includes("schedule")) {
      return `Great! I've checked our availability, and we can have a technician visit your location on ${new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString()} between 9am-12pm or ${new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toLocaleDateString()} between 1pm-4pm. Which time slot works better for you?\n\nThe inspection will take approximately 60-90 minutes, and the technician will provide a detailed report of any issues found along with recommended solutions. There's a standard inspection fee of $95, which will be credited toward any repairs if you choose to proceed with them.`
    }

    if (lastExpertMessage.content.includes("warranty")) {
      return `I've checked your warranty information, and I have good news! Your system is still under the manufacturer's warranty, which covers defects in materials and workmanship for 25 years from the installation date. The specific issue you're experiencing should be covered.\n\nI'll initiate the warranty claim process right away. We'll need to document the issue thoroughly, so I've scheduled a technician to visit your property next Tuesday at 10am to perform a comprehensive assessment and take the necessary photos for the claim. Is that date and time convenient for you?`
    }

    if (lastExpertMessage.content.includes("proposal") || lastExpertMessage.content.includes("estimate")) {
      return `I'll start working on a detailed proposal for you right away. To make sure it's tailored to your specific needs, could you confirm a few details for me?\n\n1. Are you primarily interested in maximizing savings, energy independence, or backup power during outages?\n2. Do you have any plans to add major electrical appliances or an electric vehicle in the next 2-3 years?\n3. What's your approximate budget for this upgrade?\n\nOnce I have this information, I'll prepare a comprehensive proposal with different options and their respective costs and benefits. I should have this ready for you within 2 business days.`
    }
  }

  // Generate a response based on the query category
  const category = categorizeExpertQuery(query)
  let response = getRandomExpertResponse(category)

  // Personalize with expert name occasionally
  if (Math.random() > 0.7) {
    const personalizations = [
      `As a ${expertRole}, I can tell you that `,
      `Based on my experience as a ${expertRole}, `,
      `Hi there! This is ${expertName}. `,
      `I've seen this issue many times in my work as a ${expertRole}. `,
    ]
    const personalization = personalizations[Math.floor(Math.random() * personalizations.length)]
    response = personalization + response.charAt(0).toLowerCase() + response.slice(1)
  }

  return response
}

