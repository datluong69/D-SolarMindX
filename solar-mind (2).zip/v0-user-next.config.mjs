/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone', // Tạo build độc lập có thể triển khai ở bất kỳ đâu
  images: {
    domains: ['openweathermap.org'], // Cho phép hình ảnh từ OpenWeatherMap
  },
  env: {
    NEXT_PUBLIC_APP_VERSION: '1.0.0',
    NEXT_PUBLIC_APP_NAME: 'D SOLARMIND',
  },
};

export default nextConfig;

