"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useLanguage } from "@/hooks/use-language"

export default function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const { t } = useLanguage()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate authentication
    setTimeout(() => {
      setLoading(false)
      router.push("/dashboard")
    }, 1000)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="email" className="dark:text-white">
          {t("login.email")}
        </Label>
        <Input
          id="email"
          type="email"
          placeholder="your@email.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="dark:bg-gray-700 dark:text-white dark:border-gray-600"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password" className="dark:text-white">
          {t("login.password")}
        </Label>
        <Input
          id="password"
          type="password"
          placeholder="••••••••"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="dark:bg-gray-700 dark:text-white dark:border-gray-600"
        />
      </div>
      <Button type="submit" className="w-full bg-yellow-400 hover:bg-yellow-500 text-white" disabled={loading}>
        {loading ? "Logging in..." : t("login.button")}
      </Button>
      <div className="text-center text-sm text-gray-500 dark:text-gray-400">
        <a href="#" className="hover:text-sky-600 dark:hover:text-sky-400">
          {t("login.forgot")}
        </a>
      </div>
    </form>
  )
}

