"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, RotateCw, Zap, RefreshCw } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"
import { useToast } from "@/components/ui/use-toast"
import { FINLAND_CITIES } from "@/lib/backend/config"

// Định dạng dữ liệu tối ưu hóa
type OptimizationData = {
  current: {
    tilt: number // Góc nghiêng hiện tại
    azimuth: number // Góc phương vị hiện tại
    efficiency: number // % hiệu suất hiện tại
  }
  optimal: {
    tilt: number // Góc nghiêng tối ưu
    azimuth: number // Góc phương vị tối ưu
    efficiency: number // % hiệu suất dự kiến
    gain: number // % cải thiện
  }
  recommendations: Array<{
    type: string
    description: string
    impact: number // % cải thiện
    difficulty: string
  }>
}

export default function PanelControls() {
  const { t, language } = useLanguage()
  const { theme } = useTheme()
  const { toast } = useToast()
  const [autoMode, setAutoMode] = useState(false)
  const [tiltAngle, setTiltAngle] = useState(45)
  const [rotationAngle, setRotationAngle] = useState(90)
  const [optimizing, setOptimizing] = useState(false)
  const [loading, setLoading] = useState(true)
  const [optimizationData, setOptimizationData] = useState<OptimizationData | null>(null)

  // Lấy dữ liệu tối ưu hóa
  const fetchOptimizationData = useCallback(async () => {
    try {
      setLoading(true)

      // Sử dụng tọa độ của Helsinki làm mặc định
      const response = await fetch(`/api/solar/optimization?lat=${FINLAND_CITIES[0].lat}&lon=${FINLAND_CITIES[0].lon}`)

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setOptimizationData(data.data)

        // Cập nhật góc nghiêng và góc phương vị hiện tại
        setTiltAngle(data.data.current.tilt)
        setRotationAngle(data.data.current.azimuth)
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to fetch optimization data",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching optimization data:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }, [toast])

  // Lấy dữ liệu ban đầu
  useEffect(() => {
    fetchOptimizationData()
  }, [fetchOptimizationData])

  // Xử lý tối ưu hóa
  const handleOptimize = () => {
    setOptimizing(true)

    // Mô phỏng quá trình tối ưu hóa
    setTimeout(() => {
      if (optimizationData) {
        setTiltAngle(optimizationData.optimal.tilt)
        setRotationAngle(optimizationData.optimal.azimuth)

        toast({
          title: "Optimization Complete",
          description: `Panels optimized for maximum efficiency. Expected gain: ${optimizationData.optimal.gain}%`,
        })
      }

      setOptimizing(false)
    }, 2000)
  }

  // Làm mới dữ liệu thủ công
  const handleRefresh = () => {
    fetchOptimizationData()

    toast({
      title: "Data refreshed",
      description: "Optimization data has been updated",
    })
  }

  return (
    <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
      <CardHeader className={theme === "dark" ? "bg-sky-900 pb-2" : "bg-sky-100 pb-2"}>
        <div className="flex justify-between items-center">
          <CardTitle className={theme === "dark" ? "text-sky-400" : "text-sky-700"}>{t("panel.title")}</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            className={`h-8 w-8 p-0 ${theme === "dark" ? "hover:bg-sky-800 text-sky-400" : "hover:bg-sky-200 text-sky-700"}`}
            onClick={handleRefresh}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            <span className="sr-only">Refresh</span>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        {loading && !optimizationData ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600 dark:border-sky-400"></div>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-2">
                <Switch id="auto-mode" checked={autoMode} onCheckedChange={setAutoMode} />
                <Label htmlFor="auto-mode" className="dark:text-white">
                  {t("panel.auto")}
                </Label>
              </div>
              <Button
                variant="outline"
                size="sm"
                className={
                  theme === "dark"
                    ? "bg-yellow-900/50 text-yellow-400 border-yellow-800 hover:bg-yellow-900"
                    : "bg-yellow-100 text-yellow-700 border-yellow-200 hover:bg-yellow-200"
                }
                onClick={handleOptimize}
                disabled={autoMode || optimizing}
              >
                {optimizing ? t("panel.optimizing") : t("panel.optimize")}
                <Zap className="ml-2 h-4 w-4" />
              </Button>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label className="dark:text-white">
                    {t("panel.tilt")}: {tiltAngle}°
                  </Label>
                  {optimizationData && (
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      Optimal: {optimizationData.optimal.tilt}°
                    </span>
                  )}
                </div>
                <Slider
                  value={[tiltAngle]}
                  min={0}
                  max={90}
                  step={1}
                  disabled={autoMode}
                  onValueChange={(value) => setTiltAngle(value[0])}
                  className={theme === "dark" ? "[&_[role=slider]]:bg-sky-400" : ""}
                />
                <div className="flex justify-between mt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={autoMode || tiltAngle <= 0}
                    onClick={() => setTiltAngle(Math.max(0, tiltAngle - 5))}
                    className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
                  >
                    <ArrowDown className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={autoMode || tiltAngle >= 90}
                    onClick={() => setTiltAngle(Math.min(90, tiltAngle + 5))}
                    className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
                  >
                    <ArrowUp className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label className="dark:text-white">
                    {t("panel.rotation")}: {rotationAngle}°
                  </Label>
                  {optimizationData && (
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      Optimal: {optimizationData.optimal.azimuth}°
                    </span>
                  )}
                </div>
                <Slider
                  value={[rotationAngle]}
                  min={0}
                  max={180}
                  step={1}
                  disabled={autoMode}
                  onValueChange={(value) => setRotationAngle(value[0])}
                  className={theme === "dark" ? "[&_[role=slider]]:bg-sky-400" : ""}
                />
                <div className="flex justify-between mt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={autoMode || rotationAngle <= 0}
                    onClick={() => setRotationAngle(Math.max(0, rotationAngle - 10))}
                    className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
                  >
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={autoMode}
                    onClick={() => setRotationAngle((rotationAngle + 90) % 360)}
                    className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
                  >
                    <RotateCw className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={autoMode || rotationAngle >= 180}
                    onClick={() => setRotationAngle(Math.min(180, rotationAngle + 10))}
                    className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
                  >
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div
              className={`mt-6 p-4 ${theme === "dark" ? "bg-sky-900/30 rounded-lg border border-sky-800" : "bg-sky-50 rounded-lg border border-sky-100"}`}
            >
              <p className={theme === "dark" ? "text-sm text-sky-400" : "text-sm text-sky-700"}>
                {autoMode ? t("panel.auto.message") : t("panel.manual.message")}
              </p>
            </div>

            {/* Khuyến nghị tối ưu hóa */}
            {optimizationData && optimizationData.recommendations.length > 0 && (
              <div className="mt-6">
                <h3 className="text-sm font-medium dark:text-white mb-3">Optimization Recommendations</h3>
                <div className="space-y-3">
                  {optimizationData.recommendations.map((rec, index) => (
                    <div
                      key={index}
                      className={`p-3 rounded-lg border ${
                        rec.difficulty === "easy"
                          ? theme === "dark"
                            ? "bg-green-900/20 border-green-800"
                            : "bg-green-50 border-green-100"
                          : rec.difficulty === "medium"
                            ? theme === "dark"
                              ? "bg-yellow-900/20 border-yellow-800"
                              : "bg-yellow-50 border-yellow-100"
                            : theme === "dark"
                              ? "bg-red-900/20 border-red-800"
                              : "bg-red-50 border-red-100"
                      }`}
                    >
                      <p className="text-sm font-medium dark:text-white">{rec.description}</p>
                      <div className="flex justify-between items-center mt-1">
                        <span className="text-xs text-gray-500 dark:text-gray-400">Difficulty: {rec.difficulty}</span>
                        <span className="text-xs font-medium text-green-600 dark:text-green-400">
                          +{rec.impact}% efficiency
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}

