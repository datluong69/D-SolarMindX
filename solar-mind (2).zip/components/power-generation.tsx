"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Battery, Zap, RefreshCw } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { FINLAND_CITIES } from "@/lib/backend/config"

// Định dạng dữ liệu sản xuất năng lượng mặt trời
type SolarProductionData = {
  current: {
    power: number // kW
    efficiency: number // %
    temperature: number // °C
  }
  daily: {
    total: number // kWh
    peak: number // kW
    hours: number // Số giờ sản xuất hiệu quả
  }
  monthly: {
    total: number // kWh
    average: number // kWh/ngày
    savings: number // Tiết kiệm tiền
  }
  system: {
    capacity: number // kW
    panels: number // Số lượng tấm pin
    age: number // Tuổi hệ thống (năm)
    lastMaintenance: string // Ngày bảo trì cuối cùng
    health: number // % sức khỏe hệ thống
  }
}

// Định dạng dữ liệu dự báo sản xuất
type SolarForecastData = {
  hourly: Array<{
    hour: number
    power: number // kW
    radiation: number // W/m²
  }>
  daily: Array<{
    date: string
    total: number // kWh
    peak: number // kW
    weather: string
  }>
  monthly: {
    total: number // kWh
    average: number // kWh/ngày
    comparison: number // % so với tháng trước
  }
}

export default function PowerGeneration() {
  const { t, language } = useLanguage()
  const { theme } = useTheme()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [productionData, setProductionData] = useState<SolarProductionData | null>(null)
  const [forecastData, setForecastData] = useState<SolarForecastData | null>(null)
  const [chartData, setChartData] = useState<number[]>([])
  const [refreshInterval, setRefreshInterval] = useState<NodeJS.Timeout | null>(null)

  // Lấy dữ liệu sản xuất năng lượng mặt trời hiện tại
  const fetchProductionData = useCallback(async () => {
    try {
      setLoading(true)

      // Sử dụng tọa độ của Helsinki làm mặc định
      const response = await fetch(`/api/solar/current?lat=${FINLAND_CITIES[0].lat}&lon=${FINLAND_CITIES[0].lon}`)

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setProductionData(data.data)

        // Cập nhật dữ liệu biểu đồ
        setChartData((prev) => {
          const newData = [...prev, data.data.current.power]
          if (newData.length > 24) {
            return newData.slice(-24)
          }
          return newData
        })
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to fetch production data",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching production data:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }, [toast])

  // Lấy dữ liệu dự báo sản xuất năng lượng mặt trời
  const fetchForecastData = useCallback(async () => {
    try {
      // Sử dụng tọa độ của Helsinki làm mặc định
      const response = await fetch(`/api/solar/forecast?lat=${FINLAND_CITIES[0].lat}&lon=${FINLAND_CITIES[0].lon}`)

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setForecastData(data.data)
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to fetch forecast data",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching forecast data:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    }
  }, [toast])

  // Lấy dữ liệu ban đầu
  useEffect(() => {
    fetchProductionData()
    fetchForecastData()

    // Thiết lập tự động làm mới mỗi 5 phút
    const interval = setInterval(
      () => {
        fetchProductionData()
      },
      5 * 60 * 1000,
    )

    setRefreshInterval(interval)

    return () => {
      if (refreshInterval) {
        clearInterval(refreshInterval)
      }
    }
  }, [fetchProductionData, fetchForecastData])

  // Làm mới dữ liệu thủ công
  const handleRefresh = () => {
    fetchProductionData()
    fetchForecastData()

    toast({
      title: "Data refreshed",
      description: "Power generation data has been updated",
    })
  }

  return (
    <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
      <CardHeader className={theme === "dark" ? "bg-yellow-900 pb-2" : "bg-yellow-100 pb-2"}>
        <div className="flex justify-between items-center">
          <CardTitle className={theme === "dark" ? "text-yellow-400" : "text-yellow-700"}>{t("power.title")}</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            className={`h-8 w-8 p-0 ${theme === "dark" ? "hover:bg-yellow-800 text-yellow-400" : "hover:bg-yellow-200 text-yellow-700"}`}
            onClick={handleRefresh}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            <span className="sr-only">Refresh</span>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        {loading && !productionData ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-600 dark:border-yellow-400"></div>
          </div>
        ) : productionData ? (
          <>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div
                className={`flex items-center p-3 ${theme === "dark" ? "bg-gray-700" : "bg-white"} rounded-lg shadow-sm`}
              >
                <div className="p-2 bg-yellow-100 dark:bg-yellow-900/30 rounded-full">
                  <Zap className="h-5 w-5 text-yellow-500 dark:text-yellow-400" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{t("power.current")}</p>
                  <p className="text-xl font-bold dark:text-white">{productionData.current.power.toFixed(1)} kW</p>
                </div>
              </div>

              <div
                className={`flex items-center p-3 ${theme === "dark" ? "bg-gray-700" : "bg-white"} rounded-lg shadow-sm`}
              >
                <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-full">
                  <Battery className="h-5 w-5 text-green-500 dark:text-green-400" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{t("power.today")}</p>
                  <p className="text-xl font-bold dark:text-white">{productionData.daily.total.toFixed(1)} kWh</p>
                </div>
              </div>
            </div>

            <div className="mt-4">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                {t("power.efficiency")}: {productionData.current.efficiency.toFixed(1)}%
              </p>
              <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2.5 mt-1">
                <div
                  className="bg-green-500 dark:bg-green-400 h-2.5 rounded-full"
                  style={{ width: `${productionData.current.efficiency}%` }}
                ></div>
              </div>
            </div>

            <div className="mt-6">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{t("power.chart")}</p>
              <div className="h-32 flex items-end space-x-1 mt-2">
                {chartData.map((value, index) => (
                  <div
                    key={index}
                    className="bg-yellow-400 dark:bg-yellow-500 rounded-t w-full"
                    style={{
                      height: `${(value / 5) * 100}%`,
                      maxWidth: `${100 / Math.max(24, chartData.length)}%`,
                    }}
                  ></div>
                ))}
                {Array(24 - chartData.length)
                  .fill(0)
                  .map((_, index) => (
                    <div
                      key={`empty-${index}`}
                      className="bg-gray-100 dark:bg-gray-700 rounded-t w-full"
                      style={{
                        height: "5%",
                        maxWidth: `${100 / 24}%`,
                      }}
                    ></div>
                  ))}
              </div>
            </div>

            {/* Thông tin hệ thống */}
            <div className="mt-6 p-3 bg-gray-100 dark:bg-gray-700 rounded-lg">
              <h3 className="text-sm font-medium dark:text-white mb-2">System Information</h3>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <p className="text-gray-500 dark:text-gray-400">Capacity:</p>
                  <p className="font-medium dark:text-white">{productionData.system.capacity} kW</p>
                </div>
                <div>
                  <p className="text-gray-500 dark:text-gray-400">Panels:</p>
                  <p className="font-medium dark:text-white">{productionData.system.panels}</p>
                </div>
                <div>
                  <p className="text-gray-500 dark:text-gray-400">System Age:</p>
                  <p className="font-medium dark:text-white">{productionData.system.age} years</p>
                </div>
                <div>
                  <p className="text-gray-500 dark:text-gray-400">System Health:</p>
                  <p className="font-medium dark:text-white">{productionData.system.health}%</p>
                </div>
              </div>
            </div>

            {/* Thông tin tiết kiệm */}
            <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-100 dark:border-green-800">
              <h3 className="text-sm font-medium text-green-700 dark:text-green-400 mb-1">Monthly Savings</h3>
              <p className="text-lg font-bold text-green-700 dark:text-green-400">
                €{productionData.monthly.savings.toFixed(2)}
              </p>
              <p className="text-xs text-green-600 dark:text-green-300 mt-1">
                Based on {productionData.monthly.total.toFixed(1)} kWh monthly production
              </p>
            </div>
          </>
        ) : (
          <div className="text-center p-8">
            <p className="dark:text-gray-300">No production data available. Click refresh to try again.</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

