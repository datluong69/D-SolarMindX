"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Sun, Cloud, CloudRain, RefreshCw } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"

// Định dạng dữ liệu thành phố
type CityWeather = {
  name: string
  current: {
    location: {
      name: string
      country: string
      lat: number
      lon: number
    }
    current: {
      temp: number
      weather: {
        id: number
        main: string
        description: string
        icon: string
      }
    }
  }
}

export default function WeatherMap() {
  const { t, language } = useLanguage()
  const { theme } = useTheme()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [finlandWeather, setFinlandWeather] = useState<{ cities: CityWeather[] } | null>(null)
  const [selectedCity, setSelectedCity] = useState<CityWeather | null>(null)

  // Lấy dữ liệu thời tiết cho Phần Lan
  const fetchFinlandWeather = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/weather/finland?lang=${language}`)

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setFinlandWeather(data.data)
        // Chọn thành phố đầu tiên làm mặc định
        if (data.data.cities.length > 0) {
          setSelectedCity(data.data.cities[0])
        }
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to fetch Finland weather data",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching Finland weather:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Lấy dữ liệu ban đầu
  useEffect(() => {
    fetchFinlandWeather()
  }, [language])

  // Lấy biểu tượng thời tiết từ OpenWeatherMap
  const getWeatherIcon = (iconCode: string) => {
    return `https://openweathermap.org/img/wn/${iconCode}@2x.png`
  }

  // Lấy biểu tượng thời tiết dựa trên mã thời tiết
  const getWeatherIconComponent = (weatherId: number) => {
    // Mã thời tiết OpenWeatherMap: https://openweathermap.org/weather-conditions
    if (weatherId >= 200 && weatherId < 600) {
      // Giông bão và mưa
      return <CloudRain className="h-5 w-5 text-blue-500 dark:text-blue-400" />
    } else if (weatherId >= 600 && weatherId < 700) {
      // Tuyết
      return <CloudRain className="h-5 w-5 text-blue-300 dark:text-blue-200" />
    } else if (weatherId >= 700 && weatherId < 800) {
      // Sương mù
      return <Cloud className="h-5 w-5 text-gray-400 dark:text-gray-300" />
    } else if (weatherId === 800) {
      // Trời quang
      return <Sun className="h-5 w-5 text-yellow-500 dark:text-yellow-400" />
    } else {
      // Có mây
      return <Cloud className="h-5 w-5 text-gray-500 dark:text-gray-400" />
    }
  }

  // Lấy màu cho nhiệt độ
  const getTemperatureColor = (temp: number) => {
    if (temp < 0) {
      return theme === "dark" ? "text-blue-400" : "text-blue-600"
    } else if (temp < 10) {
      return theme === "dark" ? "text-blue-300" : "text-blue-500"
    } else if (temp < 20) {
      return theme === "dark" ? "text-green-400" : "text-green-600"
    } else if (temp < 30) {
      return theme === "dark" ? "text-yellow-400" : "text-yellow-600"
    } else {
      return theme === "dark" ? "text-red-400" : "text-red-600"
    }
  }

  return (
    <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
      <CardHeader className={theme === "dark" ? "bg-sky-900 pb-2" : "bg-sky-100 pb-2"}>
        <div className="flex justify-between items-center">
          <CardTitle className={theme === "dark" ? "text-sky-400" : "text-sky-700"}>{t("weather.title")}</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            className={`h-8 w-8 p-0 ${theme === "dark" ? "hover:bg-sky-800 text-sky-400" : "hover:bg-sky-200 text-sky-700"}`}
            onClick={fetchFinlandWeather}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            <span className="sr-only">Refresh</span>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        {loading ? (
          <div className="h-64 flex items-center justify-center bg-gray-100 dark:bg-gray-700 rounded-lg">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600 dark:border-sky-400"></div>
          </div>
        ) : (
          <div className="relative h-64 bg-sky-50 dark:bg-sky-900/30 rounded-lg overflow-hidden">
            {/* Bản đồ Phần Lan */}
            <div className="absolute inset-0 bg-[url('/placeholder.svg?height=400&width=600')] bg-cover bg-center opacity-30"></div>

            {/* Lớp phủ bản đồ nhiệt */}
            <div className="absolute inset-0 bg-gradient-to-br from-yellow-300/30 via-transparent to-blue-300/30"></div>

            {/* Chỉ báo thời tiết cho các thành phố */}
            {finlandWeather?.cities.map((city, index) => {
              // Tính toán vị trí tương đối dựa trên tọa độ
              // Đây là một phép tính đơn giản, trong thực tế bạn sẽ cần một phép chiếu bản đồ thích hợp
              const minLat = 59.5 // Vĩ độ tối thiểu của Phần Lan
              const maxLat = 70.0 // Vĩ độ tối đa của Phần Lan
              const minLon = 20.0 // Kinh độ tối thiểu của Phần Lan
              const maxLon = 31.5 // Kinh độ tối đa của Phần Lan

              const x = ((city.current.location.lon - minLon) / (maxLon - minLon)) * 100
              const y = 100 - ((city.current.location.lat - minLat) / (maxLat - minLat)) * 100

              return (
                <div
                  key={city.name}
                  className="absolute p-1 bg-white dark:bg-gray-700 rounded-full shadow-md cursor-pointer transform hover:scale-110 transition-transform"
                  style={{
                    left: `${Math.max(5, Math.min(95, x))}%`,
                    top: `${Math.max(5, Math.min(95, y))}%`,
                  }}
                  onClick={() => setSelectedCity(city)}
                >
                  {getWeatherIconComponent(city.current.current.weather.id)}
                </div>
              )
            })}

            {/* Thành phố được chọn */}
            {selectedCity && (
              <div className="absolute bottom-4 left-4 right-4 bg-white/90 dark:bg-gray-800/90 p-3 rounded-lg shadow-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium dark:text-white">{selectedCity.name}, Finland</h3>
                    <p className={`text-lg font-bold ${getTemperatureColor(selectedCity.current.current.temp)}`}>
                      {Math.round(selectedCity.current.current.temp)}°C
                    </p>
                  </div>
                  <div className="flex items-center">
                    <img
                      src={getWeatherIcon(selectedCity.current.current.weather.icon) || "/placeholder.svg"}
                      alt={selectedCity.current.current.weather.description}
                      className="w-12 h-12"
                    />
                    <p className="text-sm text-gray-600 dark:text-gray-300 capitalize ml-1">
                      {selectedCity.current.current.weather.description}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Chú thích */}
            <div className="absolute top-2 right-2 flex flex-col space-y-1 bg-white/80 dark:bg-gray-800/80 p-2 rounded text-xs">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-yellow-400 rounded-full mr-1"></div>
                <span className="dark:text-white">{t("weather.high")}</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-blue-400 rounded-full mr-1"></div>
                <span className="dark:text-white">{t("weather.low")}</span>
              </div>
            </div>
          </div>
        )}

        {/* Dự báo thời tiết cho 3 ngày */}
        <div className="mt-4 grid grid-cols-3 gap-2">
          {loading ? (
            Array(3)
              .fill(0)
              .map((_, index) => (
                <div
                  key={index}
                  className={`p-2 ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"} rounded-lg shadow-sm animate-pulse h-20`}
                ></div>
              ))
          ) : finlandWeather?.cities[0]?.current ? (
            // Hiển thị dự báo cho thành phố đầu tiên (hoặc thành phố được chọn trong tương lai)
            Array(3)
              .fill(0)
              .map((_, index) => {
                // Mô phỏng dự báo đơn giản
                const baseTemp = finlandWeather.cities[0].current.current.temp
                const tempVariation = Math.random() * 6 - 3 // -3 đến +3
                const forecastTemp = baseTemp + tempVariation

                // Mô phỏng điều kiện thời tiết
                const weatherConditions = ["sunny", "partly cloudy", "cloudy"]
                const weatherIcons = [
                  <Sun key="sun" className="h-6 w-6 text-yellow-500" />,
                  <Cloud key="partly" className="h-6 w-6 text-gray-400" />,
                  <CloudRain key="cloudy" className="h-6 w-6 text-blue-400" />,
                ]

                const weatherIndex = Math.floor(Math.random() * 3)

                return (
                  <div
                    key={index}
                    className={`p-2 ${theme === "dark" ? "bg-gray-700" : "bg-white"} rounded-lg shadow-sm text-center`}
                  >
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {index === 0
                        ? t("weather.today")
                        : index === 1
                          ? t("weather.tomorrow")
                          : new Date(Date.now() + index * 24 * 60 * 60 * 1000).toLocaleDateString(language, {
                              weekday: "short",
                            })}
                    </p>
                    {weatherIcons[weatherIndex]}
                    <p className="text-sm font-bold dark:text-white">{Math.round(forecastTemp)}°C</p>
                  </div>
                )
              })
          ) : (
            <div className="col-span-3 text-center p-4">
              <p className="dark:text-gray-300">No forecast data available</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

