"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Thermometer, Droplets, Wind, Cloud, RefreshCw, MapPin } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { FINLAND_CITIES } from "@/lib/backend/config"

// Định dạng dữ liệu thời tiết
type WeatherData = {
  location: {
    name: string
    country: string
    lat: number
    lon: number
  }
  current: {
    temp: number
    humidity: number
    wind_speed: number
    weather: {
      id: number
      main: string
      description: string
      icon: string
    }
    clouds: number
  }
  solar?: {
    radiation: number
    angle: number
  }
  air_quality?: {
    aqi: number
    pm2_5: number
    pm10: number
  }
}

// Định dạng dữ liệu dự báo
type ForecastData = {
  location: {
    name: string
    country: string
  }
  daily: Array<{
    dt: number
    temp: {
      day: number
      min: number
      max: number
    }
    humidity: number
    wind_speed: number
    weather: {
      id: number
      main: string
      description: string
      icon: string
    }
    clouds: number
    solar_radiation?: number
  }>
}

export default function EnvironmentalData() {
  const { t, language } = useLanguage()
  const { theme } = useTheme()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null)
  const [forecastData, setForecastData] = useState<ForecastData | null>(null)
  const [finlandCities, setFinlandCities] = useState<Array<{ name: string; lat: number; lon: number }>>([])
  const [selectedCity, setSelectedCity] = useState<{ name: string; lat: number; lon: number }>(FINLAND_CITIES[0])
  const [activeTab, setActiveTab] = useState("current")
  const [refreshInterval, setRefreshInterval] = useState(30) // seconds
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [units, setUnits] = useState<"metric" | "imperial">("metric")
  const [dustThreshold, setDustThreshold] = useState(30)
  const [alertsEnabled, setAlertsEnabled] = useState(true)

  // Hàm để lấy dữ liệu thời tiết hiện tại
  const fetchWeatherData = useCallback(async () => {
    try {
      setLoading(true)
      const response = await fetch(
        `/api/weather/current?lat=${selectedCity.lat}&lon=${selectedCity.lon}&units=${units}&lang=${language}`,
      )

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setWeatherData(data.data)
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to fetch weather data",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching weather data:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }, [selectedCity, units, language, toast])

  // Hàm để lấy dữ liệu dự báo thời tiết
  const fetchForecastData = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/weather/forecast?lat=${selectedCity.lat}&lon=${selectedCity.lon}&units=${units}&lang=${language}&days=3`,
      )

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setForecastData(data.data)
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to fetch forecast data",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching forecast data:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    }
  }, [selectedCity, units, language, toast])

  // Hàm để lấy danh sách các thành phố ở Phần Lan
  const fetchFinlandCities = useCallback(async () => {
    try {
      // Trong trường hợp này, chúng ta sử dụng danh sách cố định từ config
      setFinlandCities(FINLAND_CITIES)
    } catch (error) {
      console.error("Error fetching Finland cities:", error)
      // Sử dụng danh sách cố định nếu có lỗi
      setFinlandCities(FINLAND_CITIES)
    }
  }, [])

  // Lấy dữ liệu ban đầu
  useEffect(() => {
    fetchFinlandCities()
  }, [fetchFinlandCities])

  // Lấy dữ liệu thời tiết khi thành phố hoặc đơn vị thay đổi
  useEffect(() => {
    fetchWeatherData()
    fetchForecastData()
  }, [fetchWeatherData, fetchForecastData, selectedCity, units])

  // Thiết lập tự động làm mới
  useEffect(() => {
    let intervalId: NodeJS.Timeout | null = null

    if (autoRefresh) {
      intervalId = setInterval(() => {
        fetchWeatherData()
        fetchForecastData()
      }, refreshInterval * 1000)
    }

    return () => {
      if (intervalId) clearInterval(intervalId)
    }
  }, [autoRefresh, refreshInterval, fetchWeatherData, fetchForecastData])

  // Giám sát mức độ bụi và hiển thị cảnh báo nếu cần
  useEffect(() => {
    if (alertsEnabled && weatherData?.air_quality && weatherData.air_quality.pm10 > dustThreshold) {
      toast({
        title: t("environmental.dustAlert"),
        description: t("environmental.dustAlertMessage", {
          level: weatherData.air_quality.pm10.toFixed(1),
          threshold: dustThreshold,
        }),
        variant: "destructive",
      })
    }
  }, [weatherData, dustThreshold, alertsEnabled, toast, t])

  // Chuyển đổi nhiệt độ dựa trên đơn vị đã chọn
  const displayTemperature = (temp: number) => {
    if (units === "imperial") {
      return `${Math.round(temp)}°F`
    }
    return `${Math.round(temp)}°C`
  }

  // Chuyển đổi tốc độ gió dựa trên đơn vị đã chọn
  const displayWindSpeed = (speed: number) => {
    if (units === "imperial") {
      return `${Math.round(speed)} mph`
    }
    return `${Math.round(speed)} km/h`
  }

  // Lấy biểu tượng thời tiết từ OpenWeatherMap
  const getWeatherIcon = (iconCode: string) => {
    return `https://openweathermap.org/img/wn/${iconCode}@2x.png`
  }

  // Lấy màu nền dựa trên điều kiện thời tiết
  const getWeatherBackground = (weatherId: number) => {
    // Mã thời tiết OpenWeatherMap: https://openweathermap.org/weather-conditions
    if (weatherId >= 200 && weatherId < 300) {
      // Giông bão
      return theme === "dark" ? "bg-gray-700" : "bg-gray-200"
    } else if (weatherId >= 300 && weatherId < 400) {
      // Mưa phùn
      return theme === "dark" ? "bg-blue-900/30" : "bg-blue-100"
    } else if (weatherId >= 500 && weatherId < 600) {
      // Mưa
      return theme === "dark" ? "bg-blue-900/30" : "bg-blue-100"
    } else if (weatherId >= 600 && weatherId < 700) {
      // Tuyết
      return theme === "dark" ? "bg-gray-700" : "bg-gray-100"
    } else if (weatherId >= 700 && weatherId < 800) {
      // Sương mù
      return theme === "dark" ? "bg-gray-700" : "bg-gray-200"
    } else if (weatherId === 800) {
      // Trời quang
      return theme === "dark" ? "bg-yellow-900/30" : "bg-yellow-100"
    } else {
      // Có mây
      return theme === "dark" ? "bg-gray-700" : "bg-gray-100"
    }
  }

  return (
    <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
      <CardHeader className={theme === "dark" ? "bg-sky-900 pb-2" : "bg-sky-100 pb-2"}>
        <div className="flex justify-between items-center">
          <CardTitle className={theme === "dark" ? "text-sky-400" : "text-sky-700"}>
            {t("environmental.title")}
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              className={`h-8 w-8 p-0 ${theme === "dark" ? "hover:bg-sky-800 text-sky-400" : "hover:bg-sky-200 text-sky-700"}`}
              onClick={() => {
                fetchWeatherData()
                fetchForecastData()
                toast({
                  title: t("environmental.refreshed"),
                  description: t("environmental.refreshedMessage"),
                })
              }}
              disabled={loading}
            >
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              <span className="sr-only">{t("environmental.refresh")}</span>
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        {/* Chọn thành phố */}
        <div className="mb-4">
          <Select
            value={selectedCity.name}
            onValueChange={(value) => {
              const city = finlandCities.find((city) => city.name === value)
              if (city) {
                setSelectedCity(city)
              }
            }}
          >
            <SelectTrigger className="w-full">
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Select city" />
              </div>
            </SelectTrigger>
            <SelectContent>
              {finlandCities.map((city) => (
                <SelectItem key={city.name} value={city.name}>
                  {city.name}, Finland
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="current" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="current">{t("environmental.current")}</TabsTrigger>
            <TabsTrigger value="forecast">{t("environmental.forecast")}</TabsTrigger>
            <TabsTrigger value="settings">{t("environmental.settings")}</TabsTrigger>
          </TabsList>

          <TabsContent value="current">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600 dark:border-sky-400"></div>
              </div>
            ) : weatherData ? (
              <>
                {/* Hiển thị thông tin thời tiết hiện tại */}
                <div className="mb-6">
                  <div
                    className={`p-4 rounded-lg ${getWeatherBackground(weatherData.current.weather.id)} flex items-center justify-between`}
                  >
                    <div>
                      <h3 className="text-lg font-medium dark:text-white">
                        {weatherData.location.name}, {weatherData.location.country}
                      </h3>
                      <p className="text-3xl font-bold dark:text-white mt-1">
                        {displayTemperature(weatherData.current.temp)}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-300 capitalize">
                        {weatherData.current.weather.description}
                      </p>
                    </div>
                    <div>
                      <img
                        src={getWeatherIcon(weatherData.current.weather.icon) || "/placeholder.svg"}
                        alt={weatherData.current.weather.description}
                        className="w-16 h-16"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div
                    className={`flex items-center p-3 ${theme === "dark" ? "bg-gray-700" : "bg-white"} rounded-lg shadow-sm`}
                  >
                    <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-full">
                      <Thermometer className="h-5 w-5 text-red-500 dark:text-red-400" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                        {t("environmental.temperature")}
                      </p>
                      <p className="text-xl font-bold dark:text-white">
                        {displayTemperature(weatherData.current.temp)}
                      </p>
                    </div>
                  </div>

                  <div
                    className={`flex items-center p-3 ${theme === "dark" ? "bg-gray-700" : "bg-white"} rounded-lg shadow-sm`}
                  >
                    <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                      <Droplets className="h-5 w-5 text-blue-500 dark:text-blue-400" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                        {t("environmental.humidity")}
                      </p>
                      <p className="text-xl font-bold dark:text-white">{weatherData.current.humidity}%</p>
                    </div>
                  </div>

                  <div
                    className={`flex items-center p-3 ${theme === "dark" ? "bg-gray-700" : "bg-white"} rounded-lg shadow-sm`}
                  >
                    <div className="p-2 bg-sky-100 dark:bg-sky-900/30 rounded-full">
                      <Wind className="h-5 w-5 text-sky-500 dark:text-sky-400" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{t("environmental.wind")}</p>
                      <p className="text-xl font-bold dark:text-white">
                        {displayWindSpeed(weatherData.current.wind_speed)}
                      </p>
                    </div>
                  </div>

                  <div
                    className={`flex items-center p-3 ${theme === "dark" ? "bg-gray-700" : "bg-white"} rounded-lg shadow-sm`}
                  >
                    <div className="p-2 bg-gray-100 dark:bg-gray-600 rounded-full">
                      <Cloud className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{t("environmental.dust")}</p>
                      <p className="text-xl font-bold dark:text-white">
                        {weatherData.air_quality ? `${weatherData.air_quality.pm10.toFixed(1)} μg/m³` : "N/A"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Hiển thị thông tin bức xạ mặt trời */}
                {weatherData.solar && (
                  <div className="mt-4">
                    <div
                      className={`p-3 rounded-lg ${theme === "dark" ? "bg-yellow-900/20 border border-yellow-800" : "bg-yellow-50 border border-yellow-100"}`}
                    >
                      <h3 className={`text-sm font-medium ${theme === "dark" ? "text-yellow-400" : "text-yellow-700"}`}>
                        Solar Radiation
                      </h3>
                      <div className="flex justify-between items-center mt-1">
                        <p className={`text-sm ${theme === "dark" ? "text-yellow-400" : "text-yellow-700"}`}>
                          {weatherData.solar.radiation.toFixed(0)} W/m²
                        </p>
                        <p className={`text-sm ${theme === "dark" ? "text-yellow-400" : "text-yellow-700"}`}>
                          Sun Angle: {weatherData.solar.angle.toFixed(1)}°
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Thời gian cập nhật cuối cùng */}
                <div className="mt-4 text-xs text-gray-500 dark:text-gray-400 text-right">
                  {t("environmental.lastUpdated")}: {new Date().toLocaleTimeString()}
                </div>
              </>
            ) : (
              <div className="text-center p-8">
                <p className="dark:text-gray-300">No weather data available. Click refresh to try again.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="forecast">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600 dark:border-sky-400"></div>
              </div>
            ) : forecastData ? (
              <div className="grid grid-cols-3 gap-4">
                {forecastData.daily.map((day, index) => (
                  <div
                    key={index}
                    className={`p-4 ${theme === "dark" ? "bg-gray-700" : "bg-white"} rounded-lg shadow-sm`}
                  >
                    <div className="flex justify-between items-center mb-3">
                      <p className="font-medium dark:text-white">
                        {index === 0
                          ? t("environmental.today")
                          : index === 1
                            ? t("environmental.tomorrow")
                            : new Date(day.dt * 1000).toLocaleDateString(language, { weekday: "long" })}
                      </p>
                      <img
                        src={getWeatherIcon(day.weather.icon) || "/placeholder.svg"}
                        alt={day.weather.description}
                        className="w-10 h-10"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {t("environmental.temperature")}
                        </span>
                        <span className="text-sm font-medium dark:text-white">
                          {displayTemperature(day.temp.day)} ({displayTemperature(day.temp.min)} -{" "}
                          {displayTemperature(day.temp.max)})
                        </span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500 dark:text-gray-400">{t("environmental.humidity")}</span>
                        <span className="text-sm font-medium dark:text-white">{day.humidity}%</span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500 dark:text-gray-400">{t("environmental.wind")}</span>
                        <span className="text-sm font-medium dark:text-white">{displayWindSpeed(day.wind_speed)}</span>
                      </div>

                      {day.solar_radiation !== undefined && (
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-500 dark:text-gray-400">
                            {t("environmental.solarRadiation")}
                          </span>
                          <span className="text-sm font-medium dark:text-white">
                            {day.solar_radiation.toFixed(0)} W/m²
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center p-8">
                <p className="dark:text-gray-300">No forecast data available. Click refresh to try again.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="settings">
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label className="dark:text-white">{t("environmental.units")}</Label>
                  <Select value={units} onValueChange={(value: "metric" | "imperial") => setUnits(value)}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder={t("environmental.selectUnits")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="metric">{t("environmental.metric")}</SelectItem>
                      <SelectItem value="imperial">{t("environmental.imperial")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label className="dark:text-white">{t("environmental.autoRefresh")}</Label>
                  <Switch checked={autoRefresh} onCheckedChange={setAutoRefresh} />
                </div>
                {autoRefresh && (
                  <div className="space-y-2">
                    <Label className="dark:text-white">
                      {t("environmental.refreshInterval")}: {refreshInterval} {t("environmental.seconds")}
                    </Label>
                    <Slider
                      value={[refreshInterval]}
                      min={10}
                      max={120}
                      step={10}
                      onValueChange={(value) => setRefreshInterval(value[0])}
                      className={theme === "dark" ? "[&_[role=slider]]:bg-sky-400" : ""}
                    />
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label className="dark:text-white">{t("environmental.dustAlerts")}</Label>
                  <Switch checked={alertsEnabled} onCheckedChange={setAlertsEnabled} />
                </div>
                {alertsEnabled && (
                  <div className="space-y-2">
                    <Label className="dark:text-white">
                      {t("environmental.dustThreshold")}: {dustThreshold} μg/m³
                    </Label>
                    <Slider
                      value={[dustThreshold]}
                      min={10}
                      max={100}
                      step={5}
                      onValueChange={(value) => setDustThreshold(value[0])}
                      className={theme === "dark" ? "[&_[role=slider]]:bg-sky-400" : ""}
                    />
                  </div>
                )}
              </div>

              <div
                className={`p-4 ${theme === "dark" ? "bg-sky-900/30 rounded-lg border border-sky-800" : "bg-sky-50 rounded-lg border border-sky-100"}`}
              >
                <p className={theme === "dark" ? "text-sm text-sky-400" : "text-sm text-sky-700"}>
                  {t("environmental.settingsInfo")}
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

