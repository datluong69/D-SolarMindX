"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Sun,
  Bell,
  MessageSquare,
  BarChart2,
  Settings,
  LogOut,
  Menu,
  X,
  PieChart,
  Moon,
  Calendar,
  Brain,
  Leaf,
} from "lucide-react"
import LanguageSwitcher from "@/components/language-switcher"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const pathname = usePathname()
  const { t } = useLanguage()
  const { theme, toggleTheme } = useTheme()

  const navItems = [
    { name: t("nav.dashboard"), href: "/dashboard", icon: BarChart2 },
    { name: t("nav.notifications"), href: "/dashboard/notifications", icon: Bell },
    { name: t("nav.chat"), href: "/dashboard/chat", icon: MessageSquare },
    { name: t("nav.analytics"), href: "/dashboard/analytics", icon: PieChart },
    { name: "AI Insights", href: "/dashboard/ai-insights", icon: Brain },
    { name: "Carbon Market", href: "/dashboard/carbon-market", icon: Leaf },
    { name: "Schedule", href: "/dashboard/schedule", icon: Calendar },
    { name: t("nav.settings"), href: "/dashboard/settings", icon: Settings },
  ]

  return (
    <div className={`min-h-screen ${theme === "dark" ? "dark bg-gray-900" : "bg-sky-50"}`}>
      {/* Mobile sidebar toggle */}
      <div
        className={`lg:hidden fixed top-0 left-0 right-0 z-30 ${theme === "dark" ? "bg-gray-800 text-white" : "bg-white"} shadow-sm p-4 flex justify-between items-center`}
      >
        <div className="flex items-center">
          <Sun className="h-6 w-6 text-yellow-400" />
          <span className={`ml-2 font-bold ${theme === "dark" ? "text-sky-400" : "text-sky-600"}`}>
            {t("app.name")}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <LanguageSwitcher />
          <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-20 w-64 ${theme === "dark" ? "bg-gray-800 text-white" : "bg-white"} shadow-lg transform transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center justify-center h-16 border-b border-gray-700">
          <Sun className="h-6 w-6 text-yellow-400" />
          <span className={`ml-2 font-bold ${theme === "dark" ? "text-sky-400" : "text-sky-600"}`}>
            {t("app.name")}
          </span>
        </div>
        <div className="flex justify-end p-2">
          <LanguageSwitcher />
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="ml-2">
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
        </div>
        <nav className="mt-4">
          <ul className="space-y-2 px-4">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = pathname === item.href
              return (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className={`flex items-center p-3 rounded-lg ${
                      isActive
                        ? theme === "dark"
                          ? "bg-sky-900 text-sky-400"
                          : "bg-sky-100 text-sky-600"
                        : theme === "dark"
                          ? "text-gray-300 hover:bg-gray-700"
                          : "text-gray-600 hover:bg-sky-50"
                    }`}
                    onClick={() => setSidebarOpen(false)}
                  >
                    <Icon className="h-5 w-5 mr-3" />
                    {item.name}
                  </Link>
                </li>
              )
            })}
          </ul>
          <div className="absolute bottom-0 w-full p-4 border-t border-gray-700">
            <Button
              variant="ghost"
              className={`w-full justify-start ${theme === "dark" ? "text-gray-300 hover:text-red-400 hover:bg-gray-700" : "text-gray-600 hover:text-red-500 hover:bg-red-50"}`}
              onClick={() => {
                // Handle logout
              }}
            >
              <LogOut className="h-5 w-5 mr-3" />
              {t("nav.logout")}
            </Button>
          </div>
        </nav>
      </div>

      {/* Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-10 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main content */}
      <div className="lg:pl-64 pt-16 lg:pt-0">
        <main className={`container mx-auto p-4 lg:p-8 ${theme === "dark" ? "text-white" : ""}`}>{children}</main>
      </div>
    </div>
  )
}

