"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { MessageSquare, X, Send, Mic, Image, Calendar } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { useTheme } from "@/hooks/use-theme"
import { useRouter } from "next/navigation"
import { chatService } from "@/lib/api-service"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ChatbotWidget() {
  const { t, language, setLanguage } = useLanguage()
  const { theme } = useTheme()
  const router = useRouter()
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<
    Array<{
      role: string
      content: string
      language?: string
    }>
  >([])
  const [input, setInput] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [chatLanguage, setChatLanguage] = useState(language)

  // Initialize greeting message when widget opens
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([{ role: "assistant", content: t("chatbot.greeting"), language: chatLanguage }])
    }
  }, [isOpen, messages.length, t, chatLanguage])

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() && !isUploading) return

    // Add user message
    const userMessage = isUploading ? "Here is an image of my solar panel." : input
    setMessages((prev) => [...prev, { role: "user", content: userMessage, language: chatLanguage }])
    setInput("")
    setIsUploading(false)
    setIsTyping(true)

    try {
      // Get AI response
      const response = await chatService.getAIResponse(userMessage, messages, chatLanguage)

      if (response.success) {
        // Add AI response after a short delay to simulate typing
        setTimeout(() => {
          setMessages((prev) => [
            ...prev,
            {
              role: "assistant",
              content: response.data.message,
              language: chatLanguage,
            },
          ])
          setIsTyping(false)
        }, 1000)
      } else {
        // Handle error
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: t("chatbot.error"),
            language: chatLanguage,
          },
        ])
        setIsTyping(false)
      }
    } catch (error) {
      console.error("Error getting AI response:", error)
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: t("chatbot.error"),
          language: chatLanguage,
        },
      ])
      setIsTyping(false)
    }
  }

  const handleVoiceInput = () => {
    setIsRecording(!isRecording)

    if (!isRecording) {
      // Simulate voice recording
      setTimeout(() => {
        const voiceCommands = [
          t("chatbot.voiceCommands.power"),
          t("chatbot.voiceCommands.efficiency"),
          t("chatbot.voiceCommands.maintenance"),
          t("chatbot.voiceCommands.weather"),
          t("chatbot.voiceCommands.savings"),
        ]
        const randomCommand = voiceCommands[Math.floor(Math.random() * voiceCommands.length)]
        setInput(randomCommand)
        setIsRecording(false)
      }, 2000)
    }
  }

  const handleImageUpload = () => {
    setIsUploading(true)
  }

  const handleScheduleMaintenance = () => {
    setIsOpen(false)
    router.push("/dashboard/schedule")
  }

  const handleLanguageChange = (newLanguage: string) => {
    setChatLanguage(newLanguage)

    // Add system message about language change
    setMessages((prev) => [
      ...prev,
      {
        role: "system",
        content: t("chatbot.languageChanged", { language: getLanguageName(newLanguage) }),
        language: newLanguage,
      },
    ])
  }

  const getLanguageName = (code: string) => {
    switch (code) {
      case "en":
        return "English"
      case "vi":
        return "Tiếng Việt"
      case "zh":
        return "中文"
      case "fr":
        return "Français"
      case "es":
        return "Español"
      default:
        return code
    }
  }

  if (!isOpen) {
    return (
      <Button
        className="fixed bottom-6 right-6 rounded-full h-14 w-14 shadow-lg bg-yellow-400 hover:bg-yellow-500 dark:bg-yellow-600 dark:hover:bg-yellow-700"
        onClick={() => setIsOpen(true)}
      >
        <MessageSquare className="h-6 w-6 text-white" />
      </Button>
    )
  }

  return (
    <Card
      className={`fixed bottom-6 right-6 w-80 sm:w-96 h-96 shadow-xl flex flex-col ${theme === "dark" ? "bg-gray-800 border-gray-700" : ""}`}
    >
      <div
        className={`flex items-center justify-between p-3 ${theme === "dark" ? "bg-sky-900" : "bg-sky-100"} rounded-t-lg`}
      >
        <div className="flex items-center">
          <MessageSquare className={`h-5 w-5 ${theme === "dark" ? "text-sky-400" : "text-sky-600"} mr-2`} />
          <h3 className={`font-medium ${theme === "dark" ? "text-sky-400" : "text-sky-700"}`}>{t("chatbot.title")}</h3>
        </div>
        <div className="flex items-center space-x-2">
          <Select value={chatLanguage} onValueChange={handleLanguageChange}>
            <SelectTrigger className="h-7 w-20 text-xs border-none bg-transparent">
              <SelectValue placeholder={chatLanguage.toUpperCase()} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="vi">Tiếng Việt</SelectItem>
              <SelectItem value="zh">中文</SelectItem>
              <SelectItem value="fr">Français</SelectItem>
              <SelectItem value="es">Español</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="ghost"
            size="icon"
            className={`h-8 w-8 rounded-full ${theme === "dark" ? "hover:bg-sky-800" : "hover:bg-sky-200"}`}
            onClick={() => setIsOpen(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex-1 p-3 overflow-y-auto flex flex-col gap-3">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`${
              message.role === "system"
                ? "self-center bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-xs px-3 py-1 rounded-full"
                : message.role === "user"
                  ? "max-w-[80%] p-3 rounded-lg ml-auto " +
                    (theme === "dark" ? "bg-yellow-800 text-yellow-100" : "bg-yellow-100 text-yellow-900")
                  : "max-w-[80%] p-3 rounded-lg " +
                    (theme === "dark" ? "bg-sky-900 text-sky-100" : "bg-sky-100 text-sky-900")
            }`}
          >
            {message.content}

            {message.role === "user" && isUploading && index === messages.length - 1 && (
              <div className="mt-2">
                <div className="relative rounded-lg overflow-hidden">
                  <img
                    src="/placeholder.svg?height=120&width=180"
                    alt="Uploaded solar panel"
                    className="w-full h-auto"
                  />
                </div>
              </div>
            )}
          </div>
        ))}

        {isTyping && (
          <div
            className={`max-w-[80%] p-3 rounded-lg ${
              theme === "dark" ? "bg-sky-900 text-sky-100" : "bg-sky-100 text-sky-900"
            }`}
          >
            <div className="flex space-x-1">
              <div className="h-2 w-2 rounded-full bg-current animate-bounce"></div>
              <div className="h-2 w-2 rounded-full bg-current animate-bounce" style={{ animationDelay: "0.2s" }}></div>
              <div className="h-2 w-2 rounded-full bg-current animate-bounce" style={{ animationDelay: "0.4s" }}></div>
            </div>
          </div>
        )}

        {isRecording && (
          <div className="self-center p-2 bg-red-100 dark:bg-red-900 rounded-lg text-red-600 dark:text-red-300 flex items-center">
            <span className="animate-pulse mr-2 h-2 w-2 rounded-full bg-red-500"></span>
            {t("chatbot.recording")}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="p-2 border-t border-gray-200 dark:border-gray-700">
        <div className="flex flex-wrap gap-1 mb-2">
          <Button
            variant="outline"
            size="sm"
            className="text-xs h-7 px-2"
            onClick={() => {
              setInput(t("chatbot.quickQuestions.power"))
              setTimeout(() => {
                const form = document.getElementById("chatbot-form") as HTMLFormElement
                form?.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }))
              }, 100)
            }}
          >
            {t("chatbot.quickButtons.power")}
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="text-xs h-7 px-2"
            onClick={() => {
              setInput(t("chatbot.quickQuestions.efficiency"))
              setTimeout(() => {
                const form = document.getElementById("chatbot-form") as HTMLFormElement
                form?.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }))
              }, 100)
            }}
          >
            {t("chatbot.quickButtons.efficiency")}
          </Button>
          <Button variant="outline" size="sm" className="text-xs h-7 px-2" onClick={handleScheduleMaintenance}>
            <Calendar className="h-3 w-3 mr-1" />
            {t("chatbot.quickButtons.schedule")}
          </Button>
        </div>

        <form id="chatbot-form" onSubmit={handleSendMessage} className="flex gap-2">
          <div className="flex gap-1">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className={`h-8 w-8 ${isUploading ? "text-yellow-500" : ""}`}
              onClick={handleImageUpload}
            >
              <Image className="h-4 w-4" />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className={`h-8 w-8 ${isRecording ? "text-red-500 animate-pulse" : ""}`}
              onClick={handleVoiceInput}
            >
              <Mic className="h-4 w-4" />
            </Button>
          </div>
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isUploading ? t("chatbot.imagePlaceholder") : t("chatbot.placeholder")}
            className={`flex-1 h-8 ${theme === "dark" ? "bg-gray-700 text-white border-gray-600" : ""}`}
          />
          <Button
            type="submit"
            size="icon"
            className="h-8 w-8 bg-yellow-400 hover:bg-yellow-500 dark:bg-yellow-600 dark:hover:bg-yellow-700"
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </Card>
  )
}

