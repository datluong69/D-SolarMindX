"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Camera, Download, RefreshCw, X } from "lucide-react"
import { useTheme } from "@/hooks/use-theme"
import { useToast } from "@/components/ui/use-toast"

export default function CameraAccess() {
  const { theme } = useTheme()
  const { toast } = useToast()
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [isActive, setIsActive] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [capturedImage, setCapturedImage] = useState<string | null>(null)

  const startCamera = async () => {
    try {
      setError(null)
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
        setStream(mediaStream)
        setIsActive(true)

        toast({
          title: "Camera activated",
          description: "Camera access granted successfully",
        })
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      setError("Could not access camera. Please check permissions and try again.")

      toast({
        title: "Camera error",
        description: "Could not access camera. Please check permissions.",
        variant: "destructive",
      })
    }
  }

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
      setIsActive(false)
      if (videoRef.current) {
        videoRef.current.srcObject = null
      }
    }
  }

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current
      const canvas = canvasRef.current

      // Set canvas dimensions to match video
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      // Draw the current video frame to the canvas
      const ctx = canvas.getContext("2d")
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

        // Convert canvas to data URL
        const imageDataUrl = canvas.toDataURL("image/png")
        setCapturedImage(imageDataUrl)

        toast({
          title: "Image captured",
          description: "Photo captured successfully",
        })
      }
    }
  }

  const downloadImage = () => {
    if (capturedImage) {
      const link = document.createElement("a")
      link.href = capturedImage
      link.download = `solar-panel-${new Date().toISOString()}.png`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    }
  }

  const resetCapture = () => {
    setCapturedImage(null)
  }

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [])

  return (
    <Card className={theme === "dark" ? "bg-gray-800 border-gray-700" : ""}>
      <CardHeader>
        <CardTitle className="dark:text-white">Camera Access</CardTitle>
        <CardDescription className="dark:text-gray-400">
          Use your camera to take photos of your solar panels
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {error && (
            <div
              className={`p-3 rounded-md ${theme === "dark" ? "bg-red-900/30 text-red-400 border border-red-800" : "bg-red-100 text-red-700 border border-red-200"}`}
            >
              {error}
            </div>
          )}

          <div
            className={`relative aspect-video rounded-lg overflow-hidden ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"}`}
          >
            {capturedImage ? (
              <img src={capturedImage || "/placeholder.svg"} alt="Captured" className="w-full h-full object-contain" />
            ) : (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className={`w-full h-full object-cover ${isActive ? "block" : "hidden"}`}
              />
            )}

            {!isActive && !capturedImage && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Camera className="h-12 w-12 text-gray-400" />
              </div>
            )}

            <canvas ref={canvasRef} className="hidden" />
          </div>

          <div className="flex flex-wrap gap-2">
            {!isActive && !capturedImage && (
              <Button
                onClick={startCamera}
                className="bg-yellow-400 hover:bg-yellow-500 text-white dark:bg-yellow-600 dark:hover:bg-yellow-700"
              >
                <Camera className="mr-2 h-4 w-4" />
                Start Camera
              </Button>
            )}

            {isActive && !capturedImage && (
              <>
                <Button onClick={captureImage} className="bg-sky-500 hover:bg-sky-600 text-white">
                  <Camera className="mr-2 h-4 w-4" />
                  Take Photo
                </Button>

                <Button
                  onClick={stopCamera}
                  variant="outline"
                  className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
                >
                  <X className="mr-2 h-4 w-4" />
                  Stop Camera
                </Button>
              </>
            )}

            {capturedImage && (
              <>
                <Button onClick={downloadImage} className="bg-green-500 hover:bg-green-600 text-white">
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>

                <Button
                  onClick={resetCapture}
                  variant="outline"
                  className={theme === "dark" ? "border-gray-600 text-gray-300" : ""}
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Reset
                </Button>

                <Button
                  onClick={startCamera}
                  className="bg-yellow-400 hover:bg-yellow-500 text-white dark:bg-yellow-600 dark:hover:bg-yellow-700"
                >
                  <Camera className="mr-2 h-4 w-4" />
                  New Photo
                </Button>
              </>
            )}
          </div>

          <div
            className={`p-3 rounded-md ${theme === "dark" ? "bg-gray-700 text-gray-300" : "bg-gray-100 text-gray-700"}`}
          >
            <h3 className="font-medium mb-2">Camera Troubleshooting:</h3>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li>Make sure your browser has permission to access the camera</li>
              <li>Try using a different browser if you're having issues</li>
              <li>On mobile devices, you may need to allow camera access in settings</li>
              <li>Ensure no other applications are currently using your camera</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

