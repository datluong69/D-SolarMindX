# D SOLARMIND - Ứng dụng Giám sát Năng lượng Mặt trời

D SOLARMIND là một ứng dụng giám sát và quản lý hệ thống năng lượng mặt trời với dữ liệu thời tiết thực tại Phần Lan.

## Tính năng

- Giám sát điều kiện môi trường thời gian thực
- Bản đồ thời tiết Phần Lan
- Theo dõi sản xuất năng lượng mặt trời
- Tối ưu hóa vị trí tấm pin
- Phân tích AI và dự báo

## Yêu cầu

- Node.js 18 trở lên
- API key từ OpenWeatherMap

## Cài đặt

1. Clone repository:

