"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type LanguageContextType = {
  language: string
  setLanguage: (lang: string) => void
  t: (key: string, params?: Record<string, any>) => string
}

const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: (key: string) => key,
})

export const translations = {
  en: {
    // Common
    "app.name": "D SOLARMIND",
    "login.title": "Login",
    "login.email": "Email",
    "login.password": "Password",
    "login.button": "Login",
    "login.forgot": "Forgot password?",

    // Dashboard
    "dashboard.title": "Dashboard",
    "environmental.title": "Environmental Conditions",
    "environmental.temperature": "Temperature",
    "environmental.humidity": "Humidity",
    "environmental.wind": "Wind Speed",
    "environmental.dust": "Dust Level",
    "environmental.current": "Current",
    "environmental.forecast": "Forecast",
    "environmental.settings": "Settings",
    "environmental.units": "Units",
    "environmental.selectUnits": "Select units",
    "environmental.metric": "Metric (°C, km/h)",
    "environmental.imperial": "Imperial (°F, mph)",
    "environmental.autoRefresh": "Auto-refresh data",
    "environmental.refreshInterval": "Refresh interval",
    "environmental.seconds": "seconds",
    "environmental.dustAlerts": "Dust level alerts",
    "environmental.dustThreshold": "Alert threshold",
    "environmental.settingsInfo":
      "These settings control how environmental data is displayed and monitored. Dust level alerts will notify you when dust levels exceed the threshold.",
    "environmental.refresh": "Refresh data",
    "environmental.refreshed": "Data refreshed",
    "environmental.refreshedMessage": "Environmental data has been updated with the latest readings.",
    "environmental.lastUpdated": "Last updated",
    "environmental.today": "Today",
    "environmental.tomorrow": "Tomorrow",
    "environmental.solarRadiation": "Solar radiation",
    "environmental.dustAlert": "High dust level detected",
    "environmental.dustAlertMessage":
      "Current dust level ({level} μg/m³) exceeds your threshold ({threshold} μg/m³). Consider cleaning your panels.",

    "power.title": "Power Generation",
    "power.current": "Current Output",
    "power.today": "Today's Total",
    "power.efficiency": "Efficiency",
    "power.chart": "24-Hour Output (kW)",

    "panel.title": "Panel Controls",
    "panel.auto": "AI Auto-Optimization",
    "panel.optimize": "Optimize Now",
    "panel.optimizing": "Optimizing...",
    "panel.tilt": "Tilt Angle",
    "panel.rotation": "Rotation Angle",
    "panel.auto.message":
      "AI is automatically optimizing panel position based on environmental conditions and sun position.",
    "panel.manual.message": "Manual control mode. Use sliders or buttons to adjust panel position.",

    "weather.title": "Weather Map",
    "weather.high": "High Sunlight",
    "weather.low": "Low Sunlight",
    "weather.today": "Today",
    "weather.tomorrow": "Tomorrow",
    "weather.panel": "Your Panel",

    // Navigation
    "nav.dashboard": "Dashboard",
    "nav.notifications": "Notifications",
    "nav.chat": "Chat",
    "nav.settings": "Settings",
    "nav.analytics": "Analytics",
    "nav.logout": "Logout",

    // Notifications
    "notifications.title": "Notifications",
    "notifications.subtitle": "Stay updated with your solar panel system",

    // Chat
    "chat.title": "Expert Chat",
    "chat.subtitle": "Connect with solar specialists for assistance",
    "chat.placeholder": "Type your message...",
    "chat.send": "Send",
    "chat.image": "Image selected. Add a message...",

    // Analytics
    "analytics.title": "Performance Analytics",
    "analytics.subtitle": "Detailed insights into your solar system",
    "analytics.daily": "Daily Production",
    "analytics.monthly": "Monthly Production",
    "analytics.yearly": "Yearly Production",
    "analytics.comparison": "Year-over-Year Comparison",
    "analytics.savings": "Cost Savings",
    "analytics.carbon": "Carbon Offset",
    "analytics.efficiency": "System Efficiency",
    "analytics.download": "Download Report",

    // Settings
    "settings.title": "Settings",
    "settings.subtitle": "Manage your account and system preferences",
    "settings.profile": "Profile Settings",
    "settings.system": "System Settings",
    "settings.notifications": "Notification Preferences",
    "settings.language": "Language",
    "settings.units": "Units",
    "settings.theme": "Theme",
    "settings.save": "Save Changes",

    // Chatbot
    "chatbot.title": "D SOLARMIND Assistant",
    "chatbot.greeting": "Hello! I'm your D SOLARMIND assistant. How can I help you with your solar panels today?",
    "chatbot.placeholder": "Type your message...",
    "chatbot.imagePlaceholder": "Image selected...",
    "chatbot.recording": "Recording...",
    "chatbot.error": "Sorry, I encountered an error processing your request. Please try again.",
    "chatbot.languageChanged": "Language changed to {language}",

    "chatbot.quickButtons": {
      power: "Current power",
      efficiency: "Improve efficiency",
      schedule: "Schedule maintenance",
    },

    "chatbot.quickQuestions": {
      power: "What's my current power generation?",
      efficiency: "How can I improve my system efficiency?",
      maintenance: "When is my next maintenance due?",
      weather: "How will the weather affect my production today?",
      savings: "How much have I saved this month?",
    },

    "chatbot.voiceCommands": {
      power: "What is my current power generation?",
      efficiency: "How efficient are my solar panels today?",
      maintenance: "When is my next maintenance scheduled?",
      weather: "What's the weather forecast for solar production?",
      savings: "How much energy have I saved this month?",
    },

    "ai.insights": "AI Insights",
    "ai.analysis": "AI Analysis",
    "ai.imageAnalysis": "Image Analysis",
    "ai.optimization": "Optimization Plan",
    "ai.uploadImage": "Upload Panel Image",
    "ai.analyzeImage": "Analyze Image",
    "ai.noIssues": "No issues detected",
    "ai.detectedIssues": "Detected Issues",
    "ai.recommendations": "Recommendations",
    "ai.regeneratePlan": "Regenerate Plan",
    "ai.applyPlan": "Apply Optimization Plan",
    "ai.estimatedImprovement": "Estimated Improvement",
    "ai.timeToImplement": "Time to Implement",
    "ai.implementationSteps": "Implementation Steps",

    // Carbon Market
    "carbon.title": "Carbon Market",
    "carbon.subtitle": "Trade carbon credits and contribute to a greener future",
    "carbon.overview": "Overview",
    "carbon.market": "Market",
    "carbon.portfolio": "My Portfolio",
    "carbon.history": "Transaction History",
    "carbon.yourCredits": "Your Carbon Credits",
    "carbon.emissionsAvoided": "CO₂ Emissions Avoided",
    "carbon.marketPrice": "Current Market Price",
    "carbon.sellCredits": "Sell Carbon Credits",
    "carbon.buyCredits": "Buy Carbon Credits",
    "carbon.whyTrade": "Why Trade Carbon Credits?",
    "carbon.whyTradeDesc":
      "By trading carbon credits, you're participating in a global effort to reduce carbon emissions. Each credit represents one ton of CO₂ emissions avoided or removed from the atmosphere.",
    "carbon.availableCredits": "Available Carbon Credits",
    "carbon.browseDesc": "Browse and purchase carbon credits from verified sellers",
    "carbon.refreshMarket": "Refresh Market",
    "carbon.yourPortfolio": "Your Carbon Portfolio",
    "carbon.currentHoldings": "Current Holdings",
    "carbon.sellAll": "Sell All Credits",
    "carbon.environmentalImpact": "Environmental Impact",
    "carbon.yourContribution": "Your Contribution",
    "carbon.treesPlanted": "Equivalent Trees Planted",
    "carbon.certificate": "Carbon Offset Certificate",
    "carbon.certificateDesc":
      "Generate an official certificate for your carbon offsets to share with others or use for reporting.",
    "carbon.generateCertificate": "Generate Certificate",
  },

  vi: {
    // Common
    "app.name": "D SOLARMIND",
    "login.title": "Đăng nhập",
    "login.email": "Email",
    "login.password": "Mật khẩu",
    "login.button": "Đăng nhập",
    "login.forgot": "Quên mật khẩu?",

    // Dashboard
    "dashboard.title": "Bảng điều khiển",
    "environmental.title": "Điều kiện môi trường",
    "environmental.temperature": "Nhiệt độ",
    "environmental.humidity": "Độ ẩm",
    "environmental.wind": "Tốc độ gió",
    "environmental.dust": "Mức độ bụi",
    "environmental.current": "Hiện tại",
    "environmental.forecast": "Dự báo",
    "environmental.settings": "Cài đặt",
    "environmental.units": "Đơn vị",
    "environmental.selectUnits": "Chọn đơn vị",
    "environmental.metric": "Hệ mét (°C, km/h)",
    "environmental.imperial": "Hệ Anh (°F, mph)",
    "environmental.autoRefresh": "Tự động làm mới dữ liệu",
    "environmental.refreshInterval": "Khoảng thời gian làm mới",
    "environmental.seconds": "giây",
    "environmental.dustAlerts": "Cảnh báo mức độ bụi",
    "environmental.dustThreshold": "Ngưỡng cảnh báo",
    "environmental.settingsInfo":
      "Các cài đặt này kiểm soát cách hiển thị và giám sát dữ liệu môi trường. Cảnh báo mức độ bụi sẽ thông báo cho bạn khi mức độ bụi vượt quá ngưỡng.",
    "environmental.refresh": "Làm mới dữ liệu",
    "environmental.refreshed": "Dữ liệu đã được làm mới",
    "environmental.refreshedMessage": "Dữ liệu môi trường đã được cập nhật với các chỉ số mới nhất.",
    "environmental.lastUpdated": "Cập nhật lần cuối",
    "environmental.today": "Hôm nay",
    "environmental.tomorrow": "Ngày mai",
    "environmental.solarRadiation": "Bức xạ mặt trời",
    "environmental.dustAlert": "Phát hiện mức độ bụi cao",
    "environmental.dustAlertMessage":
      "Mức độ bụi hiện tại ({level} μg/m³) vượt quá ngưỡng của bạn ({threshold} μg/m³). Hãy cân nhắc làm sạch tấm pin của bạn.",

    "power.title": "Sản lượng điện",
    "power.current": "Công suất hiện tại",
    "power.today": "Tổng hôm nay",
    "power.efficiency": "Hiệu suất",
    "power.chart": "Sản lượng 24 giờ (kW)",

    "panel.title": "Điều khiển tấm pin",
    "panel.auto": "Tự động tối ưu hóa AI",
    "panel.optimize": "Tối ưu ngay",
    "panel.optimizing": "Đang tối ưu...",
    "panel.tilt": "Góc nghiêng",
    "panel.rotation": "Góc xoay",
    "panel.auto.message": "AI đang tự động tối ưu hóa vị trí tấm pin dựa trên điều kiện môi trường và vị trí mặt trời.",
    "panel.manual.message": "Chế độ điều khiển thủ công. Sử dụng thanh trượt hoặc nút để điều chỉnh vị trí tấm pin.",

    "weather.title": "Bản đồ thời tiết",
    "weather.high": "Ánh sáng cao",
    "weather.low": "Ánh sáng thấp",
    "weather.today": "Hôm nay",
    "weather.tomorrow": "Ngày mai",
    "weather.panel": "Tấm pin của bạn",

    // Navigation
    "nav.dashboard": "Bảng điều khiển",
    "nav.notifications": "Thông báo",
    "nav.chat": "Trò chuyện",
    "nav.settings": "Cài đặt",
    "nav.analytics": "Phân tích",
    "nav.logout": "Đăng xuất",

    // Notifications
    "notifications.title": "Thông báo",
    "notifications.subtitle": "Cập nhật về hệ thống tấm pin mặt trời của bạn",

    // Chat
    "chat.title": "Trò chuyện với chuyên gia",
    "chat.subtitle": "Kết nối với chuyên gia năng lượng mặt trời để được hỗ trợ",
    "chat.placeholder": "Nhập tin nhắn của bạn...",
    "chat.send": "Gửi",
    "chat.image": "Đã chọn hình ảnh. Thêm tin nhắn...",

    // Analytics
    "analytics.title": "Phân tích hiệu suất",
    "analytics.subtitle": "Thông tin chi tiết về hệ thống năng lượng mặt trời của bạn",
    "analytics.daily": "Sản lượng hàng ngày",
    "analytics.monthly": "Sản lượng hàng tháng",
    "analytics.yearly": "Sản lượng hàng năm",
    "analytics.comparison": "So sánh năm qua năm",
    "analytics.savings": "Tiết kiệm chi phí",
    "analytics.carbon": "Giảm phát thải carbon",
    "analytics.efficiency": "Hiệu suất hệ thống",
    "analytics.download": "Tải báo cáo",

    // Settings
    "settings.title": "Cài đặt",
    "settings.subtitle": "Quản lý tài khoản và tùy chọn hệ thống của bạn",
    "settings.profile": "Cài đặt hồ sơ",
    "settings.system": "Cài đặt hệ thống",
    "settings.notifications": "Tùy chọn thông báo",
    "settings.language": "Ngôn ngữ",
    "settings.units": "Đơn vị",
    "settings.theme": "Giao diện",
    "settings.save": "Lưu thay đổi",

    // Chatbot
    "chatbot.title": "Trợ lý D SOLARMIND",
    "chatbot.greeting":
      "Xin chào! Tôi là trợ lý D SOLARMIND của bạn. Tôi có thể giúp gì cho bạn với tấm pin mặt trời hôm nay?",
    "chatbot.placeholder": "Nhập tin nhắn của bạn...",
    "chatbot.imagePlaceholder": "Đã chọn hình ảnh...",
    "chatbot.recording": "Đang ghi âm...",
    "chatbot.error": "Xin lỗi, tôi gặp lỗi khi xử lý yêu cầu của bạn. Vui lòng thử lại.",
    "chatbot.languageChanged": "Đã chuyển ngôn ngữ sang {language}",

    "chatbot.quickButtons": {
      power: "Công suất hiện tại",
      efficiency: "Cải thiện hiệu suất",
      schedule: "Lịch bảo trì",
    },

    "chatbot.quickQuestions": {
      power: "Công suất phát điện hiện tại của tôi là bao nhiêu?",
      efficiency: "Làm thế nào để cải thiện hiệu suất hệ thống của tôi?",
      maintenance: "Khi nào đến lịch bảo trì tiếp theo của tôi?",
      weather: "Thời tiết sẽ ảnh hưởng như thế nào đến sản lượng của tôi hôm nay?",
      savings: "Tôi đã tiết kiệm được bao nhiêu trong tháng này?",
    },

    "chatbot.voiceCommands": {
      power: "Công suất phát điện hiện tại của tôi là bao nhiêu?",
      efficiency: "Tấm pin mặt trời của tôi hiệu quả như thế nào hôm nay?",
      maintenance: "Khi nào đến lịch bảo trì tiếp theo của tôi?",
      weather: "Dự báo thời tiết cho sản xuất năng lượng mặt trời là gì?",
      savings: "Tôi đã tiết kiệm được bao nhiêu năng lượng trong tháng này?",
    },
    // Carbon Market
    "carbon.title": "Thị trường Carbon",
    "carbon.subtitle": "Giao dịch tín chỉ carbon và đóng góp cho một tương lai xanh hơn",
    "carbon.overview": "Tổng quan",
    "carbon.market": "Thị trường",
    "carbon.portfolio": "Danh mục của tôi",
    "carbon.history": "Lịch sử giao dịch",
    "carbon.yourCredits": "Tín chỉ carbon của bạn",
    "carbon.emissionsAvoided": "Lượng khí thải CO₂ đã tránh được",
    "carbon.marketPrice": "Giá thị trường hiện tại",
    "carbon.sellCredits": "Bán tín chỉ carbon",
    "carbon.buyCredits": "Mua tín chỉ carbon",
    "carbon.whyTrade": "Tại sao nên giao dịch tín chỉ carbon?",
    "carbon.whyTradeDesc":
      "Bằng cách giao dịch tín chỉ carbon, bạn đang tham gia vào nỗ lực toàn cầu để giảm lượng khí thải carbon. Mỗi tín chỉ đại diện cho một tấn khí thải CO₂ đã tránh được hoặc loại bỏ khỏi khí quyển.",
    "carbon.availableCredits": "Tín chỉ carbon có sẵn",
    "carbon.browseDesc": "Duyệt và mua tín chỉ carbon từ những người bán đã được xác minh",
    "carbon.refreshMarket": "Làm mới thị trường",
    "carbon.yourPortfolio": "Danh mục carbon của bạn",
    "carbon.currentHoldings": "Số lượng nắm giữ hiện tại",
    "carbon.sellAll": "Bán tất cả tín chỉ",
    "carbon.environmentalImpact": "Tác động môi trường",
    "carbon.yourContribution": "Đóng góp của bạn",
    "carbon.treesPlanted": "Số cây tương đương đã trồng",
    "carbon.certificate": "Chứng chỉ bù đắp carbon",
    "carbon.certificateDesc":
      "Tạo chứng chỉ chính thức cho việc bù đắp carbon của bạn để chia sẻ với người khác hoặc sử dụng để báo cáo.",
    "carbon.generateCertificate": "Tạo chứng chỉ",
  },

  zh: {
    // Common
    "app.name": "D SOLARMIND",
    "login.title": "登录",
    "login.email": "电子邮件",
    "login.password": "密码",
    "login.button": "登录",
    "login.forgot": "忘记密码？",

    // Dashboard
    "dashboard.title": "仪表板",
    "environmental.title": "环境条件",
    "environmental.temperature": "温度",
    "environmental.humidity": "湿度",
    "environmental.wind": "风速",
    "environmental.dust": "灰尘水平",
    "environmental.current": "当前",
    "environmental.forecast": "预报",
    "environmental.settings": "设置",
    "environmental.units": "单位",
    "environmental.selectUnits": "选择单位",
    "environmental.metric": "公制 (°C, km/h)",
    "environmental.imperial": "英制 (°F, mph)",
    "environmental.autoRefresh": "自动刷新数据",
    "environmental.refreshInterval": "刷新间隔",
    "environmental.seconds": "秒",
    "environmental.dustAlerts": "灰尘水平警报",
    "environmental.dustThreshold": "警报阈值",
    "environmental.settingsInfo": "这些设置控制环境数据的显示和监控方式。当灰尘水平超过阈值时，灰尘水平警报将通知您。",
    "environmental.refresh": "刷新数据",
    "environmental.refreshed": "数据已刷新",
    "environmental.refreshedMessage": "环境数据已更新为最新读数。",
    "environmental.lastUpdated": "最后更新",
    "environmental.today": "今天",
    "environmental.tomorrow": "明天",
    "environmental.solarRadiation": "太阳辐射",
    "environmental.dustAlert": "检测到高灰尘水平",
    "environmental.dustAlertMessage":
      "当前灰尘水平 ({level} μg/m³) 超过您的阈值 ({threshold} μg/m³)。考虑清洁您的面板。",

    "power.title": "发电量",
    "power.current": "当前输出",
    "power.today": "今日总计",
    "power.efficiency": "效率",
    "power.chart": "24小时输出 (kW)",

    "panel.title": "面板控制",
    "panel.auto": "AI自动优化",
    "panel.optimize": "立即优化",
    "panel.optimizing": "优化中...",
    "panel.tilt": "倾斜角度",
    "panel.rotation": "旋转角度",
    "panel.auto.message": "AI正在根据环境条件和太阳位置自动优化面板位置。",
    "panel.manual.message": "手动控制模式。使用滑块或按钮调整面板位置。",

    "weather.title": "天气地图",
    "weather.high": "高日照",
    "weather.low": "低日照",
    "weather.today": "今天",
    "weather.tomorrow": "明天",
    "weather.panel": "您的面板",

    // Navigation
    "nav.dashboard": "仪表板",
    "nav.notifications": "通知",
    "nav.chat": "聊天",
    "nav.settings": "设置",
    "nav.analytics": "分析",
    "nav.logout": "登出",

    // Notifications
    "notifications.title": "通知",
    "notifications.subtitle": "了解您的太阳能面板系统的最新情况",

    // Chat
    "chat.title": "专家聊天",
    "chat.subtitle": "与太阳能专家联系获取帮助",
    "chat.placeholder": "输入您的消息...",
    "chat.send": "发送",
    "chat.image": "已选择图片。添加消息...",

    // Analytics
    "analytics.title": "性能分析",
    "analytics.subtitle": "您的太阳能系统的详细见解",
    "analytics.daily": "日产量",
    "analytics.monthly": "月产量",
    "analytics.yearly": "年产量",
    "analytics.comparison": "年度比较",
    "analytics.savings": "成本节约",
    "analytics.carbon": "碳抵消",
    "analytics.efficiency": "系统效率",
    "analytics.download": "下载报告",

    // Settings
    "settings.title": "设置",
    "settings.subtitle": "管理您的账户和系统首选项",
    "settings.profile": "个人资料设置",
    "settings.system": "系统设置",
    "settings.notifications": "通知首选项",
    "settings.language": "语言",
    "settings.units": "单位",
    "settings.theme": "主题",
    "settings.save": "保存更改",

    // Chatbot
    "chatbot.title": "D SOLARMIND 助手",
    "chatbot.greeting": "您好！我是您的D SOLARMIND助手。今天我能为您的太阳能面板提供什么帮助？",
    "chatbot.placeholder": "输入您的消息...",
    "chatbot.imagePlaceholder": "已选择图片...",
    "chatbot.recording": "录音中...",
    "chatbot.error": "抱歉，处理您的请求时遇到错误。请重试。",
    "chatbot.languageChanged": "语言已更改为 {language}",

    "chatbot.quickButtons": {
      power: "当前功率",
      efficiency: "提高效率",
      schedule: "安排维护",
    },

    "chatbot.quickQuestions": {
      power: "我当前的发电量是多少？",
      efficiency: "如何提高我的系统效率？",
      maintenance: "我的下一次维护何时到期？",
      weather: "今天的天气将如何影响我的产量？",
      savings: "这个月我节省了多少？",
    },

    "chatbot.voiceCommands": {
      power: "我当前的发电量是多少？",
      efficiency: "我的太阳能面板今天效率如何？",
      maintenance: "我的下一次维护何时安排？",
      weather: "太阳能发电的天气预报是什么？",
      savings: "这个月我节省了多少能源？",
    },
    // Carbon Market
    "carbon.title": "碳市场",
    "carbon.subtitle": "交易碳信用额度，为更绿色的未来做出贡献",
    "carbon.overview": "概述",
    "carbon.market": "市场",
    "carbon.portfolio": "我的投资组合",
    "carbon.history": "交易历史",
    "carbon.yourCredits": "您的碳信用额度",
    "carbon.emissionsAvoided": "避免的二氧化碳排放量",
    "carbon.marketPrice": "当前市场价格",
    "carbon.sellCredits": "出售碳信用额度",
    "carbon.buyCredits": "购买碳信用额度",
    "carbon.whyTrade": "为什么要交易碳信用额度？",
    "carbon.whyTradeDesc":
      "通过交易碳信用额度，您正在参与减少碳排放的全球努力。每个信用额度代表避免或从大气中移除的一吨二氧化碳排放量。",
    "carbon.availableCredits": "可用碳信用额度",
    "carbon.browseDesc": "浏览并从经过验证的卖家处购买碳信用额度",
    "carbon.refreshMarket": "刷新市场",
    "carbon.yourPortfolio": "您的碳投资组合",
    "carbon.currentHoldings": "当前持有量",
    "carbon.sellAll": "出售所有信用额度",
    "carbon.environmentalImpact": "环境影响",
    "carbon.yourContribution": "您的贡献",
    "carbon.treesPlanted": "相当于种植的树木",
    "carbon.certificate": "碳抵消证书",
    "carbon.certificateDesc": "生成您的碳抵消的官方证书，与他人分享或用于报告。",
    "carbon.generateCertificate": "生成证书",
  },

  fr: {
    // Common
    "app.name": "D SOLARMIND",
    "login.title": "Connexion",
    "login.email": "Email",
    "login.password": "Mot de passe",
    "login.button": "Connexion",
    "login.forgot": "Mot de passe oublié?",

    // Dashboard
    "dashboard.title": "Tableau de bord",
    "environmental.title": "Conditions environnementales",
    "environmental.temperature": "Température",
    "environmental.humidity": "Humidité",
    "environmental.wind": "Vitesse du vent",
    "environmental.dust": "Niveau de poussière",
    "environmental.current": "Actuel",
    "environmental.forecast": "Prévisions",
    "environmental.settings": "Paramètres",
    "environmental.units": "Unités",
    "environmental.selectUnits": "Sélectionner les unités",
    "environmental.metric": "Métrique (°C, km/h)",
    "environmental.imperial": "Impérial (°F, mph)",
    "environmental.autoRefresh": "Actualisation automatique",
    "environmental.refreshInterval": "Intervalle d'actualisation",
    "environmental.seconds": "secondes",
    "environmental.dustAlerts": "Alertes de niveau de poussière",
    "environmental.dustThreshold": "Seuil d'alerte",
    "environmental.settingsInfo":
      "Ces paramètres contrôlent l'affichage et la surveillance des données environnementales. Les alertes de niveau de poussière vous avertiront lorsque les niveaux de poussière dépassent le seuil.",
    "environmental.refresh": "Actualiser les données",
    "environmental.refreshed": "Données actualisées",
    "environmental.refreshedMessage": "Les données environnementales ont été mises à jour avec les dernières mesures.",
    "environmental.lastUpdated": "Dernière mise à jour",
    "environmental.today": "Aujourd'hui",
    "environmental.tomorrow": "Demain",
    "environmental.solarRadiation": "Rayonnement solaire",
    "environmental.dustAlert": "Niveau élevé de poussière détecté",
    "environmental.dustAlertMessage":
      "Le niveau actuel de poussière ({level} μg/m³) dépasse votre seuil ({threshold} μg/m³). Envisagez de nettoyer vos panneaux.",

    "power.title": "Production d'énergie",
    "power.current": "Puissance actuelle",
    "power.today": "Total aujourd'hui",
    "power.efficiency": "Efficacité",
    "power.chart": "Production sur 24h (kW)",

    "panel.title": "Contrôles des panneaux",
    "panel.auto": "Optimisation IA automatique",
    "panel.optimize": "Optimiser maintenant",
    "panel.optimizing": "Optimisation...",
    "panel.tilt": "Angle d'inclinaison",
    "panel.rotation": "Angle de rotation",
    "panel.auto.message":
      "L'IA optimise automatiquement la position du panneau en fonction des conditions environnementales et de la position du soleil.",
    "panel.manual.message":
      "Mode de contrôle manuel. Utilisez les curseurs ou les boutons pour ajuster la position du panneau.",

    "weather.title": "Carte météo",
    "weather.high": "Ensoleillement élevé",
    "weather.low": "Ensoleillement faible",
    "weather.today": "Aujourd'hui",
    "weather.tomorrow": "Demain",
    "weather.panel": "Votre panneau",

    // Navigation
    "nav.dashboard": "Tableau de bord",
    "nav.notifications": "Notifications",
    "nav.chat": "Discussion",
    "nav.settings": "Paramètres",
    "nav.analytics": "Analyses",
    "nav.logout": "Déconnexion",

    // Notifications
    "notifications.title": "Notifications",
    "notifications.subtitle": "Restez informé sur votre système de panneaux solaires",

    // Chat
    "chat.title": "Discussion avec expert",
    "chat.subtitle": "Connectez-vous avec des spécialistes solaires pour obtenir de l'aide",
    "chat.placeholder": "Tapez votre message...",
    "chat.send": "Envoyer",
    "chat.image": "Image sélectionnée. Ajoutez un message...",

    // Analytics
    "analytics.title": "Analyse de performance",
    "analytics.subtitle": "Aperçus détaillés de votre système solaire",
    "analytics.daily": "Production quotidienne",
    "analytics.monthly": "Production mensuelle",
    "analytics.yearly": "Production annuelle",
    "analytics.comparison": "Comparaison d'une année à l'autre",
    "analytics.savings": "Économies de coûts",
    "analytics.carbon": "Compensation carbone",
    "analytics.efficiency": "Efficacité du système",
    "analytics.download": "Télécharger le rapport",

    // Settings
    "settings.title": "Paramètres",
    "settings.subtitle": "Gérez votre compte et les préférences du système",
    "settings.profile": "Paramètres du profil",
    "settings.system": "Paramètres du système",
    "settings.notifications": "Préférences de notification",
    "settings.language": "Langue",
    "settings.units": "Unités",
    "settings.theme": "Thème",
    "settings.save": "Enregistrer les modifications",

    // Chatbot
    "chatbot.title": "Assistant D SOLARMIND",
    "chatbot.greeting":
      "Bonjour! Je suis votre assistant D SOLARMIND. Comment puis-je vous aider avec vos panneaux solaires aujourd'hui?",
    "chatbot.placeholder": "Tapez votre message...",
    "chatbot.imagePlaceholder": "Image sélectionnée...",
    "chatbot.recording": "Enregistrement...",
    "chatbot.error": "Désolé, j'ai rencontré une erreur lors du traitement de votre demande. Veuillez réessayer.",
    "chatbot.languageChanged": "Langue changée en {language}",

    "chatbot.quickButtons": {
      power: "Puissance actuelle",
      efficiency: "Améliorer l'efficacité",
      schedule: "Planifier l'entretien",
    },

    "chatbot.quickQuestions": {
      power: "Quelle est ma production d'énergie actuelle?",
      efficiency: "Comment puis-je améliorer l'efficacité de mon système?",
      maintenance: "Quand est prévu mon prochain entretien?",
      weather: "Comment la météo affectera-t-elle ma production aujourd'hui?",
      savings: "Combien ai-je économisé ce mois-ci?",
    },

    "chatbot.voiceCommands": {
      power: "Quelle est ma production d'énergie actuelle?",
      efficiency: "Quelle est l'efficacité de mes panneaux solaires aujourd'hui?",
      maintenance: "Quand est prévu mon prochain entretien?",
      weather: "Quelles sont les prévisions météo pour la production solaire?",
      savings: "Combien d'énergie ai-je économisé ce mois-ci?",
    },
    // Carbon Market
    "carbon.title": "Marché du carbone",
    "carbon.subtitle": "Échangez des crédits carbone et contribuez à un avenir plus vert",
    "carbon.overview": "Aperçu",
    "carbon.market": "Marché",
    "carbon.portfolio": "Mon portefeuille",
    "carbon.history": "Historique des transactions",
    "carbon.yourCredits": "Vos crédits carbone",
    "carbon.emissionsAvoided": "Émissions de CO₂ évitées",
    "carbon.marketPrice": "Prix actuel du marché",
    "carbon.sellCredits": "Vendre des crédits carbone",
    "carbon.buyCredits": "Acheter des crédits carbone",
    "carbon.whyTrade": "Pourquoi échanger des crédits carbone?",
    "carbon.whyTradeDesc":
      "En échangeant des crédits carbone, vous participez à un effort mondial visant à réduire les émissions de carbone. Chaque crédit représente une tonne d'émissions de CO₂ évitées ou retirées de l'atmosphère.",
    "carbon.availableCredits": "Crédits carbone disponibles",
    "carbon.browseDesc": "Parcourez et achetez des crédits carbone auprès de vendeurs vérifiés",
    "carbon.refreshMarket": "Actualiser le marché",
    "carbon.yourPortfolio": "Votre portefeuille carbone",
    "carbon.currentHoldings": "Participations actuelles",
    "carbon.sellAll": "Vendre tous les crédits",
    "carbon.environmentalImpact": "Impact environnemental",
    "carbon.yourContribution": "Votre contribution",
    "carbon.treesPlanted": "Arbres équivalents plantés",
    "carbon.certificate": "Certificat de compensation carbone",
    "carbon.certificateDesc":
      "Générez un certificat officiel pour vos compensations carbone à partager avec d'autres ou à utiliser pour la production de rapports.",
    "carbon.generateCertificate": "Générer un certificat",
  },

  es: {
    // Common
    "app.name": "D SOLARMIND",
    "login.title": "Iniciar sesión",
    "login.email": "Correo electrónico",
    "login.password": "Contraseña",
    "login.button": "Iniciar sesión",
    "login.forgot": "¿Olvidó su contraseña?",

    // Dashboard
    "dashboard.title": "Panel de control",
    "environmental.title": "Condiciones ambientales",
    "environmental.temperature": "Temperatura",
    "environmental.humidity": "Humedad",
    "environmental.wind": "Velocidad del viento",
    "environmental.dust": "Nivel de polvo",
    "environmental.current": "Actual",
    "environmental.forecast": "Pronóstico",
    "environmental.settings": "Configuración",
    "environmental.units": "Unidades",
    "environmental.selectUnits": "Seleccionar unidades",
    "environmental.metric": "Métrico (°C, km/h)",
    "environmental.imperial": "Imperial (°F, mph)",
    "environmental.autoRefresh": "Actualización automática",
    "environmental.refreshInterval": "Intervalo de actualización",
    "environmental.seconds": "segundos",
    "environmental.dustAlerts": "Alertas de nivel de polvo",
    "environmental.dustThreshold": "Umbral de alerta",
    "environmental.settingsInfo":
      "Estos ajustes controlan cómo se muestran y monitorizan los datos ambientales. Las alertas de nivel de polvo le notificarán cuando los niveles de polvo excedan el umbral.",
    "environmental.refresh": "Actualizar datos",
    "environmental.refreshed": "Datos actualizados",
    "environmental.refreshedMessage": "Los datos ambientales se han actualizado con las últimas lecturas.",
    "environmental.lastUpdated": "Última actualización",
    "environmental.today": "Hoy",
    "environmental.tomorrow": "Mañana",
    "environmental.solarRadiation": "Radiación solar",
    "environmental.dustAlert": "Nivel alto de polvo detectado",
    "environmental.dustAlertMessage":
      "El nivel actual de polvo ({level} μg/m³) excede su umbral ({threshold} μg/m³). Considere limpiar sus paneles.",

    "power.title": "Generación de energía",
    "power.current": "Salida actual",
    "power.today": "Total de hoy",
    "power.efficiency": "Eficiencia",
    "power.chart": "Producción de 24 horas (kW)",

    "panel.title": "Controles del panel",
    "panel.auto": "Optimización automática IA",
    "panel.optimize": "Optimizar ahora",
    "panel.optimizing": "Optimizando...",
    "panel.tilt": "Ángulo de inclinación",
    "panel.rotation": "Ángulo de rotación",
    "panel.auto.message":
      "La IA está optimizando automáticamente la posición del panel según las condiciones ambientales y la posición del sol.",
    "panel.manual.message":
      "Modo de control manual. Use los deslizadores o botones para ajustar la posición del panel.",

    "weather.title": "Mapa del tiempo",
    "weather.high": "Alta luz solar",
    "weather.low": "Baja luz solar",
    "weather.today": "Hoy",
    "weather.tomorrow": "Mañana",
    "weather.panel": "Su panel",

    // Navigation
    "nav.dashboard": "Panel de control",
    "nav.notifications": "Notificaciones",
    "nav.chat": "Chat",
    "nav.settings": "Configuración",
    "nav.analytics": "Análisis",
    "nav.logout": "Cerrar sesión",

    // Notifications
    "notifications.title": "Notificaciones",
    "notifications.subtitle": "Manténgase actualizado con su sistema de paneles solares",

    // Chat
    "chat.title": "Chat con expertos",
    "chat.subtitle": "Conéctese con especialistas solares para obtener asistencia",
    "chat.placeholder": "Escriba su mensaje...",
    "chat.send": "Enviar",
    "chat.image": "Imagen seleccionada. Añada un mensaje...",

    // Analytics
    "analytics.title": "Análisis de rendimiento",
    "analytics.subtitle": "Información detallada sobre su sistema solar",
    "analytics.daily": "Producción diaria",
    "analytics.monthly": "Producción mensual",
    "analytics.yearly": "Producción anual",
    "analytics.comparison": "Comparación año tras año",
    "analytics.savings": "Ahorro de costes",
    "analytics.carbon": "Compensación de carbono",
    "analytics.efficiency": "Eficiencia del sistema",
    "analytics.download": "Descargar informe",

    // Settings
    "settings.title": "Configuración",
    "settings.subtitle": "Administre su cuenta y las preferencias del sistema",
    "settings.profile": "Configuración de perfil",
    "settings.system": "Configuración del sistema",
    "settings.notifications": "Preferencias de notificación",
    "settings.language": "Idioma",
    "settings.units": "Unidades",
    "settings.theme": "Tema",
    "settings.save": "Guardar cambios",

    // Chatbot
    "chatbot.title": "Asistente D SOLARMIND",
    "chatbot.greeting": "¡Hola! Soy su asistente D SOLARMIND. ¿Cómo puedo ayudarle con sus paneles solares hoy?",
    "chatbot.placeholder": "Escriba su mensaje...",
    "chatbot.imagePlaceholder": "Imagen seleccionada...",
    "chatbot.recording": "Grabando...",
    "chatbot.error": "Lo siento, encontré un error al procesar su solicitud. Por favor, inténtelo de nuevo.",
    "chatbot.languageChanged": "Idioma cambiado a {language}",

    "chatbot.quickButtons": {
      power: "Potencia actual",
      efficiency: "Mejorar eficiencia",
      schedule: "Programar mantenimiento",
    },

    "chatbot.quickQuestions": {
      power: "¿Cuál es mi generación de energía actual?",
      efficiency: "¿Cómo puedo mejorar la eficiencia de mi sistema?",
      maintenance: "¿Cuándo está programado mi próximo mantenimiento?",
      weather: "¿Cómo afectará el clima a mi producción hoy?",
      savings: "¿Cuánto he ahorrado este mes?",
    },

    "chatbot.voiceCommands": {
      power: "¿Cuál es mi generación de energía actual?",
      efficiency: "¿Qué tan eficientes son mis paneles solares hoy?",
      maintenance: "¿Cuándo está programado mi próximo mantenimiento?",
      weather: "¿Cuál es el pronóstico del tiempo para la producción solar?",
      savings: "¿Cuánta energía he ahorrado este mes?",
    },
    // Carbon Market
    "carbon.title": "Mercado de Carbono",
    "carbon.subtitle": "Comercie créditos de carbono y contribuya a un futuro más verde",
    "carbon.overview": "Visión general",
    "carbon.market": "Mercado",
    "carbon.portfolio": "Mi portafolio",
    "carbon.history": "Historial de transacciones",
    "carbon.yourCredits": "Sus créditos de carbono",
    "carbon.emissionsAvoided": "Emisiones de CO₂ evitadas",
    "carbon.marketPrice": "Precio actual del mercado",
    "carbon.sellCredits": "Vender créditos de carbono",
    "carbon.buyCredits": "Comprar créditos de carbono",
    "carbon.whyTrade": "¿Por qué comerciar créditos de carbono?",
    "carbon.whyTradeDesc":
      "Al comerciar créditos de carbono, está participando en un esfuerzo global para reducir las emisiones de carbono. Cada crédito representa una tonelada de emisiones de CO₂ evitadas o eliminadas de la atmósfera.",
    "carbon.availableCredits": "Créditos de carbono disponibles",
    "carbon.browseDesc": "Explore y compre créditos de carbono de vendedores verificados",
    "carbon.refreshMarket": "Actualizar mercado",
    "carbon.yourPortfolio": "Su cartera de carbono",
    "carbon.currentHoldings": "Tenencias actuales",
    "carbon.sellAll": "Vender todos los créditos",
    "carbon.environmentalImpact": "Impacto ambiental",
    "carbon.yourContribution": "Su contribución",
    "carbon.treesPlanted": "Árboles equivalentes plantados",
    "carbon.certificate": "Certificado de compensación de carbono",
    "carbon.certificateDesc":
      "Genere un certificado oficial para sus compensaciones de carbono para compartir con otros o utilizar para la presentación de informes.",
    "carbon.generateCertificate": "Generar certificado",
  },
}

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState("en")

  useEffect(() => {
    const savedLanguage = localStorage.getItem("language")
    if (savedLanguage) {
      setLanguage(savedLanguage)
    } else {
      // Try to detect browser language
      const browserLang = navigator.language.split("-")[0]
      if (translations[browserLang as keyof typeof translations]) {
        setLanguage(browserLang)
      }
    }
  }, [])

  const handleSetLanguage = (lang: string) => {
    setLanguage(lang)
    localStorage.setItem("language", lang)
  }

  const t = (key: string, params?: Record<string, any>): string => {
    const langDict = translations[language as keyof typeof translations] || translations.en
    let text = langDict[key as keyof typeof langDict] || key

    // Handle nested keys (e.g., "chatbot.quickButtons.power")
    if (text === key && key.includes(".")) {
      const parts = key.split(".")
      let current: any = langDict

      for (const part of parts) {
        if (current && typeof current === "object" && part in current) {
          current = current[part]
        } else {
          current = key
          break
        }
      }

      text = typeof current === "string" ? current : key
    }

    // Replace parameters in the text
    if (params && typeof text === "string") {
      Object.entries(params).forEach(([key, value]) => {
        text = text.replace(new RegExp(`{${key}}`, "g"), String(value))
      })
    }

    return text
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export const useLanguage = () => useContext(LanguageContext)

